﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['$location', 'AuthenticationService', 'FlashService'];
    function LoginController($location, AuthenticationService, FlashService) {
        var vm = this;

        vm.login = login;

        (function initController() {
            // reset login status
        	$("#top-menu").hide();
            AuthenticationService.ClearCredentials();
        })();

        function login() {
            vm.dataLoading = true;
            AuthenticationService.Login(vm.username, vm.password, function (response) {
                if (response.success) {
                	$("#top-menu").show();
                	if(vm.username=="C20081")
                		{
                		$("#active-user-management").show();
                		$("#active-register-counterparty").show();
                		}
                	else
                		{
                		$("#active-user-management").hide();
                		$("#active-register-counterparty").hide();
                		}
                	  $("#active-home").addClass("active");
         			  $("#active-user-management").removeClass("active");
         			 $("#active-register-counterparty").removeClass("active");
                    AuthenticationService.SetCredentials(vm.username, vm.password);
                    $location.path('/');
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        };
    }

})();
