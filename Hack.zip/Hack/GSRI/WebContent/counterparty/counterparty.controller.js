﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('CounterpartyController', CounterpartyController);

    CounterpartyController.$inject = ['UserService', '$location', '$rootScope', 'FlashService'];
    function CounterpartyController(UserService, $location, $rootScope, FlashService) {
        var vm = this;

        vm.registerCounterparty = registerCounterparty;
        
          (function initController() {
            // reset login status
        	  $("#active-register-counterparty").addClass("active");
 			  $("#active-user-management").removeClass("active");
 			 $("#active-home").removeClass("active");
 			 $("#active-rating").removeClass("active");
 			
        })();


        function registerCounterparty() {
            vm.dataLoading = true;
            UserService.RegisterCounterparty(vm.counterparty)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Registration successful', true);
                        vm.counterparty=null;
                        vm.dataLoading = false;
                        $location.path('/counterparty');
                    } else {
                        FlashService.Error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }
    }

})();
