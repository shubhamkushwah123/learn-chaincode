﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('RatingController', RatingController);

    RatingController.$inject = ['UserService', '$location', '$rootScope', 'FlashService'];
    function RatingController(UserService, $location, $rootScope, FlashService) {
        var vm = this;

        vm.createRating = createRating;
        
          (function initController() {
            // reset login status
        	  $("#active-rating").addClass("active");
 			  $("#active-user-management").removeClass("active");
 			 $("#active-home").removeClass("active");
 			 $("#active-register-counterparty").removeClass("active");
 			 $("#questionnaireForm").hide();
 			 UserService.GetAllCounterparties()
             .then(function (response) {
            	 vm.counterparties=response;
             });
 			 
        })();


        function createRating() {
        	 $("#selectionForm").hide();
        	 var jj={
        			 "CounterpartyID": "904",
        			 "AGIC": "",
        			 "Country": "",
        			 "ModifiedDate": "",
        			 "Status": "",
        			  "Categories": [
        			  	{
        			  		 "Name": "Compliance",
        			  		 "Questions":[
        						{
        							"QuestionID": "1",
        							 "QuestionText": "1. Does the client confirm that it complies with all relevant (social and environmental) legislation and regulations?",
        							 "Answers":[
        							 	{
        							 	"ID":"1",
        							 	"Score":"1",
        							 	"Text":"Yes"
        							 	},
        							 	{
        							 	"ID":"2",
        							 	"Score":"0",
        							 	"Text":"No"
        							 	}
        							 ]
        						}	  		 
        			  		 
        			  		 ]
        			  	},
        				{
       			  		 "Name": "Commitment",
       			  		 "Questions":[
       						{
       							"QuestionID": "1",
       							 "QuestionText": "1. Does the client have written sustainability commitments in place specifying how it deals with chemicals, water and waste? ",
       							 "Answers":[
       							 	{
       							 	"ID":"1",
       							 	"Score":"1",
       							 	"Text":"Yes, the client has an environmental policy specifying how the client deals with chemicals, water and waste"
       							 	},
       							 	{
       							 	"ID":"2",
       							 	"Score":"0",
       							 	"Text":"No, the client has not a written environmental policy specifying how the client deals with either chemicals, water or waste ",
       							 	"Proof":"Yes",
       							 	"Link":""
       							 	}
       							 ]
       						}	,
       						{
       							"QuestionID": "2",
       							 "QuestionText": "2. Does the client have written sustainability commitments (i.e. policy, code-of-conduct) in place addressing the following social sustainability subjects: working times, forced and child labour and the right to collective bargaining?",
       							 "Answers":[
       							 	{
       							 	"ID":"1",
       							 	"Score":"1",
       							 	"Text":"Yes, the client has a specific code of conduct (addressing working times, forced and child labour and the right to collective bargaining)",
       							 	"Proof":"Yes",
    							 	"Link":""
       							 	},
       							 	{
       							 	"ID":"2",
       							 	"Score":"0.5",
       							 	"Text":"No, the client does not have a specific code of conduct (addressing working times, forced and child labour and the right to collective bargaining) but is in the process of developing it"
       							 	},
       							 	{
           							 	"ID":"3",
           							 	"Score":"0.25",
           							 	"Text":"No, the client does not have a specific code of conduct (addressing working times, forced and child labour and the right to collective bargaining) and is not in the process of developing it "
       							 	},
       							 	{
           							 	"ID":"4",
           							 	"Score":"0",
           							 	"Text":"No, the client does not have a code of conduct "
       							 	}
       							 ]
       						}
       			  		 
       			  		 ]
       			  		},
				  		{
		   			  		 "Name": "Capacity",
		   			  		 "Questions":[
		   						{
		   							"QuestionID": "1",
		   							 "QuestionText": "1. Does the client have a complaint mechanism in place for all employees?",
		   							 "Answers":[
		   							 	{
		   							 	"ID":"1",
		   							 	"Score":"1",
		   							 	"Text":"Yes, the client has a complaint mechanism in place for all employees within its own company",
		   							 	"Proof":"Yes",
	       							 	"Link":""
		   							 	},
		   							 	{
		   							 	"ID":"2",
		   							 	"Score":"0",
		   							 	"Text":"No, the client does not have any complaint mechanism in place "
		   							 	}
		   							 ]
		   						}	,
		   						{
		   							"QuestionID": "2",
		   							 "QuestionText": "2. Does the client have a structured approach to implement its sustainability policies and standards? ",
		   							 "Answers":[
		   							 	{
		   							 	"ID":"1",
		   							 	"Score":"1",
		   							 	"Text":"Yes, the client has a sector-specific and certified management system with specific reference to sustainability issues (e.g. ISO14001. OHSAS18001 or SA8000)",
		   							 	"Proof":"Yes",
	       							 	"Link":""
		   							 	},
		   							 	{
		   							 	"ID":"2",
		   							 	"Score":"0.75",
		   							 	"Text":"Yes, the client has a general management system which includes sustainability issues but is not certified yet, but is in the process of obtaining certifications"
		   							 	},
		   							 	{
			   							 	"ID":"3",
			   							 	"Score":"0.5",
			   							 	"Text":"Yes, the client has a general management system which includes sustainability issues but is not certified"
		   							 	},
		   							 	{
			   							 	"ID":"4",
			   							 	"Score":"0",
			   							 	"Text":"No, the client does not have a systematic approach"
		   							 	}
		   							 ]
		   						}
		   			  		 
		   			  		 ]
		   			  	},
			   			 {
	       			  		 "Name": "Track Record",
	       			  		 "Questions":[
	       						{
	       							"QuestionID": "1",
	       							 "QuestionText": "1. Has the company, its sector or supply chain been publicly discredited (media campaigns, public debate, social unrest)? - and if so, how has the client responded?",
	       							 "Answers":[
	       							 	{
	       							 	"ID":"1",
	       							 	"Score":"1",
	       							 	"Text":"No, the company, its sector or supply chain has not been publicly discredited "
	       							 	},
	       							 	{
	       							 	"ID":"2",
	       							 	"Score":"0.75",
	       							 	"Text":"Yes, but any adverse NGO, media campaigns or boycotts were not material and have been appropriately addressed through management action."
	       							 	},
	       							 	{
		       							 	"ID":"3",
		       							 	"Score":"0.50",
		       							 	"Text":"Yes, there is evidence of adverse NGO, media campaigns or boycotts against the client (for example due to accidents, spill, explosion, labour union, local communities protests) and the management response is largely reactive."
	       							 	},
	       							 	{
		       							 	"ID":"4",
		       							 	"Score":"0",
		       							 	"Text":"Yes, and the client has not taken any measures to reduce its reputational risk."
	       							 	}
	       							 ]
	       						}	  		 
	       			  		 
	       			  		 ]
	       			  	}
        			  ]
        		  };
        	 vm.questionnaire=jj;
        	 UserService.GetByCounterpartyId(vm.counterpartyId)
             .then(function (response) {
            	 vm.questionnaire.CounterpartyID=response.counterpartyId;
            	 vm.questionnaire.AGIC=response.agic;
            	 vm.questionnaire.Country=response.country;
            	 $("#questionnaireForm").show();
                vm.dataLoading = false;
             });
       
        }
    }
    
    function finaliseRating() {
    	
    }

})();
