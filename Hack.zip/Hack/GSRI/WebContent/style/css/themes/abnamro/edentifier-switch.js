define('component/ui/edentifier-switch/edentifier-switch', ['angular'], function(angular) {

    'use strict';

    angular
        .module('ui.edentifierSwitch', [])
        /**
         * @ngdoc directive
         * @name ui.edentifierSwitch:edentifierSwitch
         * @restrict E
         * @param {scope/context variable} ng-model value is binded to this
         * @param {element/html element} refers to the html level element
         * @param {attrs/context variable} Accepts the parameters as a attributes
         * @param {ngModel/context variable} ng-model value is binded to this
         * @description
         * Switches to eDentifier1 or eDentifier2.
         */
        .directive('aabEdentifierSwitch', [function() {

            return {
                restrict: 'E',
                require: '?ngModel',
                scope: {
                    ngModel: '=ngModel',
                    disabled: '=',
                    actionOnSelectEdentifier: '&'
                },
                link: function(scope, element, attrs, ngModel) {
                    if (!attrs.enableEdentifier) {
                        attrs.enableEdentifier = 'true';
                    }

                    var selectedEdentfier = {};

                    /**
                     * @ngdoc method
                     * @name updatePreference
                     * @methodOf ui.edentifierSwitch:edentifierSwitch
                     * @description
                     * Bind the click event to the div
                     * Based on the passed parameter it switches to eDentifier1 or eDentifier2
                     */
                    scope.updatePreference = function(edentifier) {
                        if (attrs.enableEdentifier === 'false') {
                            return;
                        }

                        angular.forEach(scope.edentifiers, function(edt) {
                            edt.selected = false;
                        });
                        edentifier.selected = true;

                        selectedEdentfier = edentifier;

                        if (ngModel && selectedEdentfier.id && scope.ngModel !== selectedEdentfier.id) {
                            ngModel.$setViewValue(selectedEdentfier.id);
                        }

                        if (scope.actionOnSelectEdentifier && typeof scope.actionOnSelectEdentifier === 'function') {
                            scope.actionOnSelectEdentifier();
                        }
                    };

                    // Definition of the available edentifiers
                    scope.edentifiers = [
                        {
                            id: 'eDentifier2',
                            name: 'E.dentifier2',
                            selected: false
                        },
                        {
                            id: 'eDentifier1',
                            name: 'E.dentifier1',
                            selected: false
                        }
                    ];

                    //check the selectedEdentfier and navigates to eDentifier1 or eDentifier2
                    if (attrs.selectedEdentfier ||
                        (scope.ngModel === 'eDentifier2' || scope.ngModel === 'eDentifier1')) {

                        if ((attrs.selectedEdentfier.toUpperCase() === 'EDENTIFIER2'.toUpperCase()) ||
                            (scope.ngModel === 'eDentifier2')) {
                            angular.forEach(scope.edentifiers, function(edt) {
                                if (edt.id === 'eDentifier2' ) {
                                    scope.updatePreference(edt);
                                }
                            });
                        } else {
                            angular.forEach(scope.edentifiers, function(edt) {
                                if (edt.id === 'eDentifier1' ) {
                                    scope.updatePreference(edt);
                                }
                            });
                        }
                    }
                },
                templateUrl: 'oca/app/components/ui/edentifier-switch/edentifier-switch.html',
                replace: true
            };

        }]);
});
