/**
 * @description
 * Creates an update loader that is shown after a submit. There should be a delay before showing the loader.
 * This is a feedback to the user to let him know that the process is in progress and that it is taking some time.
 * If the process takes longer than 3 seconds, the user may be shown a second feedback.
 *
 * @author Rogier Konings
 */

define('component/ui/update-loader/update-loader', ['angular', 'angular-spinner'], function(angular) {

    /**
     * @name ui.updateLoader.updateLoaderActivator:updateLoaderActivator
     * @ngdoc service
     * @description updateLoaderActivator is used to trigger a updateLoader message
     */
    function updateLoaderActivator() {

        var showUpdateLoaderHandler;

        /**
         * @name addHandler
         * @ngdoc method
         * @methodOf ui.updateLoader.updateLoaderActivator:updateLoaderActivator
         * @description
         * Sets the handler to be called when ShowUpdateLoader is called
         *
         * @param {function} the handler
         **/
        this.addHandler = function(handler) {
            showUpdateLoaderHandler = handler;
        };

        /**
         * @name removeHandler
         * @ngdoc method
         * @methodOf ui.updateLoader.updateLoaderActivator:updateLoaderActivator
         * @description
         * Removes the handler that is called when ShowUpdateLoader is called
         *
         * @param {function} the handler
         **/
        this.removeHandler = function() {
            showUpdateLoaderHandler = undefined;
        };


        /**
         * @name handleUpdateLoader
         * @ngdoc method
         * @methodOf ui.updateLoader.updateLoaderActivator:updateLoaderActivator
         * @description
         * Activates the handleUpdateLoader when it is set
         *
         * @param {object} options Json structure with {
         *   information: text to display,
         *   endAfterMiliseconds: time in milliseconds
         *   successIcon: boolean
         * }
         **/
        this.handleUpdateLoader = function(options) {
            if (showUpdateLoaderHandler && typeof(showUpdateLoaderHandler) === 'function') {
                showUpdateLoaderHandler(options);
            }
        };
    }

    function updateLoaderController($scope, usSpinnerService, $timeout, updateLoaderActivator) {
        /* jshint validthis:true */
        var vm = this;

        // configuration settings of spinner
        vm.opts = {
            // The number of lines to draw
            lines: 12,
            // The length of each line
            length: 6,
             // The line thickness
            width: 3,
            // The radius of the inner circle
            radius: 8,
            // #rgb or #rrggbb
            color: '#fff',
             // Rounds per second
            speed: 1.0,
            // Afterglow percentage
            trail: 100,
            shadow: false,
            left: '20px',
            top: '50%'
        };

        vm.initialize = function(options) {

            angular.extend(vm, {

                information: options.information,
                loader: options.loader,
                showSpinner: options.showSpinner,
                successIcon: options.loader,
                endAfterMilliseconds: options.endAfterMilliseconds,
                delayMilliseconds: options.delayMilliseconds

            });

            // Checks whether it needs to start or stop the loader
            if (vm.loader) {
                vm.delay(options);
            } else {
                vm.deactivate();
            }
        };

        // Function responsible for both the initial delay and total time of the update-loader
        vm.delay = function(options) {

            $timeout(function() {
                vm.activate(options);
            }, (vm.delayMilliseconds));

            $timeout(function() {
                vm.deactivate();
            }, (isNaN(vm.delayMilliseconds) ?
                vm.endAfterMilliseconds : vm.delayMilliseconds + vm.endAfterMilliseconds));
        };

        // Function responsible for disabling the update-loader
        vm.deactivate = function() {

            usSpinnerService.stop('spinner-wrapper');

            vm.successIcon = false;
            vm.information = undefined;
            vm.loaderclass = undefined;
            vm.show = false;
        };

        // Function responsible for enabling the update-loader
        vm.activate = function(options) {

            angular.extend(vm, {

                information: options.information,
                successIcon: options.successIcon,
                showSpinner: options.showSpinner
            });

            // CSS class for styling of the update-loader - shows/ hides the update-loader
            var CSSCLASS = 'ocf-update-loader';
            vm.loaderclass = CSSCLASS;
            vm.show = true;

            // Starts the Spinner
            if(vm.showSpinner){
                usSpinnerService.spin('spinner-wrapper');
            }else{
                usSpinnerService.stop('spinner-wrapper');
            }
        };

        updateLoaderActivator.addHandler(vm.initialize);
    }

    /**
     * @name ui.updateLoader.aabUpdateLoader:aabUpdateLoader
     * @ngdoc directive
     * @module ui.updateLoader
     * @restrict EA
     *
     * @description
     * A directive to provide UpdateLoader/overview message based on initialization
     *
     * @requires {$rootScope} $rootScope An angular application scope reference
     * @requires {$timeout} $timeout An angular timeout function reference
     * @param {boolean @} successIcon, Dependency to show/hide success icon.
     * @param {string @} information, information displayed in Component.
     * @param {number @} endAfterMiliseconds, specifies the time in milliseconds for UpdateLoader display.
     * @param {number @} delayMilliseconds, specifices the time in miliseconds
     * @param {string @} componentType, uses to display specific type of component view,
     *                                  supports[overview, updateloader].
     * @param {boolean @} revert, displays revert icon at the right end.
     * @param {function @} revertAction, triggers event to parent scope when revert icon is pressed.
     * @param {expression | boolean @} overviewTrigger, show/hides overviewComponent.
     * @param {boolean @} showSpinner, show/hides spinner.
     * @param {boolean @} loader, this will disable the timeout function.
     *                            The updateLoader will be shown until endLoader is true
     *                            In combination with showSpinner = 'true' this will create an endless loader
     * @param {boolean @} endLoader, this will end the loader
     *
     * @example
     *  <pre>
     *      <aab-update-loader component-type='updateLoader' success-icon='true'
     *          info-text='A simple Update Loader message' revert='true' timeout-limit='3000'></aab-update-loader>
     *  </pre>
     */
    function aabUpdateLoader() {

        var directive = {

            restrict: 'EA',
            replace: false,
            scope: {
                successIcon: '@',
                information: '@infoText',
                endAfterMilliseconds: '@',
                delayMilliseconds: '@',
                showSpinner: '@',
                loader: '@'
            },
            templateUrl: 'oca/app/components/ui/update-loader/update-loader.html',
            controller: updateLoaderController,
            controllerAs: 'vm'
        };

        return directive;
    }

    angular
        .module('ui.updateLoader', ['angularSpinner'])
        .service('updateLoaderActivator', updateLoaderActivator)
        .directive('aabUpdateLoader', aabUpdateLoader)
        .controller('updateLoaderController', updateLoaderController);
});
