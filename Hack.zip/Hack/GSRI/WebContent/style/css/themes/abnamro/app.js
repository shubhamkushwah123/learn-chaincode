define('../app', [
    'angular',
    'angular-bootstrap',
    'uiRouter',
    'angular-translate',
    'angular-sanitize',
    'foundation/widget/widget-bundle',
    'component/ui/step-counter/step-counter',
    'component/ui/update-loader/update-loader',
    'component/ui/modal/modal',
    'component/ui/date-picker/date-picker',
    'component/ui/mask/date-mask/date-mask',
    'component/ui/loading-spinner/loading-spinner',
    'component/ui/accordion/accordion',
    'component/ui/edentifier-switch/edentifier-switch',
    'component/ui/pin5/pin5',
    'component/ui/numeric-input/numeric-input',
    //'foundation/common/init-menu',
    'component/ui/dropdown-list/dropdown-list',
    'component/ui/mask/aab-iban-mask/aab-iban-mask',
    'component/ui/mask/iban-mask/iban-mask',
    'component/ui/mask/currency-mask/currency-mask',
    'component/ui/alert/alert'
], function(angular) {

    //Load the angular module dependency
    angular.module('newApp', [
        'ui.bootstrap',
        'ui.router',
        'pascalprecht.translate',
        'widget.bundle',
        'uiComponent.stepCounter',
        'ui.updateLoader',
        'service.modal',
        'ui.datePicker',
        'ui.dateMask',
        'ui.loadingSpinner',
        'ui.accordion',
        'ui.edentifierSwitch',
        'ui.pin5',
        'ngSanitize',
        'ui.numericInput',
        'ui.dropDownList',
        'ui.aabiBanMask',
        'ui.ibanMask',
        'ui.currencyMask',
        'ui.alert'
    ])

    .run(
        ['$rootScope', '$state', '$stateParams',
            function($rootScope, $state, $stateParams) {

                // It's very handy to add references to $state and $stateParams to the $rootScope
                // so that you can access them from any scope within your applications.For example,
                // <li ng-class="{ active: $state.includes('contacts.list') }"> will set the <li>
                // to active whenever 'contacts.list' or one of its decendents is active.
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
            }
        ]
    )


    .config(
            ['$stateProvider', '$urlRouterProvider', '$translateProvider',
                function($stateProvider, $urlRouterProvider, $translateProvider) {

                    //Sanitize strategy has been implemented that sanitizes HTML in the translation text using $sanitize
                    $translateProvider.useSanitizeValueStrategy('sanitize');

                    /////////////////////////////
                    // Redirects and Otherwise //
                    /////////////////////////////

                    // Use $urlRouterProvider to configure any redirects (when) and invalid urls (otherwise).
                    $urlRouterProvider

                    // The `when` method says if the url is ever the 1st param, then redirect to the 2nd param
                    // Here we are just setting up some convenience urls.
                    //.when('/c?id', '/contacts/:id')
                    //.when('/user/:id', '/contacts/:id')

                    // If the url is ever invalid, e.g. '/asdf', then redirect to '/' aka the home state
                        .otherwise('/');



                    // State Configurations


                    // Use $stateProvider to configure your states.
                    $stateProvider


                    // Home
                        .state("about", {

                        // Use a url of "/" to set a state as the "index".
                        url: "/",
                        templateUrl: "templates/about.html"
                            // Example of an inline template string. By default, templates
                            // will populate the ui-view within the parent state's template.
                            // For top level states, like this one, the parent template is
                            // the index.html file. So this template will be inserted into the
                            // ui-view within index.html.
                            /*               template: '<p class="lead">Welcome to the UI-Router Demo</p>' +
                             '<p>Use the menu above to navigate. ' +
                             'Pay attention to the <code>$state</code> and <code>$stateParams</code> values below.</p>' +
                             '<p>Click these links—<a href="#/c?id=1">Alice</a> or ' +
                             '<a href="#/user/42">Bob</a>—to see a url redirect in action.</p>'
                             */
                    })

                    .state('grid', {
                        url: '/grid',
                        templateUrl: "templates/grid.html"
                    })

                    .state('typography', {
                        url: '/typography',
                        templateUrl: "templates/typography.html"
                    })

                    .state('icons', {
                        url: '/icons',
                        templateUrl: "templates/icons.html"
                    })

                    .state("navigation", {
                        url: "/navigation",
                        templateUrl: "templates/navigation.html",
                        controller: "navigationController"
                    })

                    .state("alerts", {
                        url: "/alerts",
                        templateUrl: "templates/alerts.html"
                    })

                    .state("forms", {
                        url: "/forms",
                        templateUrl: "templates/forms.html"
                    })

                    .state("layout", {
                        url: "/layout",
                        templateUrl: "templates/layout.html"
                    })

                    .state("overviews", {
                        url: "/overviews",
                        templateUrl: "templates/overviews.html"
                    })

                    .state("custom", {
                        url: "/custom",
                        templateUrl: "templates/custom.html"
                    })

                    .state("header", {
                        templateUrl: "templates/header.html"
                    })

                    .state("footer", {
                        templateUrl: "templates/footer.html"
                    })

                    .state('neutralheader', {
                        url: '/neutralheader',
                        templateUrl: "templates/neutral-header.html",
                        controller: "menuController",
                        params: {
                            menu: false
                        }
                    })

                }

            ]
        )
        .controller('ThemeSelectionController', function($scope) {
            $scope.changeTheme = function(changeThemeSelectedModel) {

                angular.element(document.querySelector('#themeSelected')).attr('href', changeThemeSelectedModel + 'core.css');
                angular.element(document.querySelector('#themeSelectedStyleGuide')).attr('href', changeThemeSelectedModel + 'styleguide.css');
            };
        })

    .controller('HeaderController', function($scope) {
        // $scope.expandMenu = function(){

        //     angular.element(document.querySelector("html")).addClass('navbar-hamburger-expanded');
        //     setHamburgerMenuHeight();
        // }

        //  $scope.closeMenu = function(){
        //     angular.element(document.querySelector("html")).removeClass('navbar-hamburger-expanded');
        // }

    })

    .controller('navigationController', ['$scope', '$window',
        function($scope, $window) {
            //console.log($window.initializeMenu);
            $window.initializeMenu._initialize();
        }

    ])

    // All controllers are now central. check if we can cut this into pieces
    .controller('CollapseDemoCtrl', function($scope) {
        $scope.isCollapsed = false;
    })

    .controller('ConfirmationCtrl', function($scope) {
        $scope.steps = [{
            name: 'select-account-holder',
            url: 'select-account-holder',
            step: 1,
            title: 'H3, Stepcounter'
        }, {
            name: 'savings-assemble-account',
            url: 'savings-assemble-account',
            step: 2,
            title: 'H3, Stepcounter'
        }, {
            name: 'savings-verify-send',
            url: 'savings-verify-send',
            step: 3,
            title: 'H3, Stepcounter'
        }, {
            name: 'savings-confirmation',
            url: 'savings-confirmation',
            step: 4,
            title: 'H3, Stepcounter'
        }];
    })

    .controller('ModalStyleguideCtrl', function($scope, $modal, $log) {

        $scope.openSourceModal = function(size) {
            var modalInstance = $modal.open({
                animation: $scope.animationsEnabled,
                controller: 'ModalSourcecodeInstanceCtrl',
                templateUrl: 'viewSource.html',
                windowClass: 'sg-modal-dialog',
                size: size,
                resolve: {
                    sourceCode: function() {
                        return event.currentTarget.parentElement.parentElement.parentElement;
                    }
                }
            });
        };

    })

    .controller('ModalSourcecodeInstanceCtrl', function($scope, $modalInstance, sourceCode) {

        $scope.sourceCode = angular.element(sourceCode).html();

        $scope.ok = function() {
            $modalInstance.close();
        };
    })

    // TODO use angular module instead of jquery
    .controller('PopoverDemoCtrl', function($scope) {
        $scope.dynamicPopover = {
            content: 'Hello, World!',
            templateUrl: 'myPopoverTemplate.html',
            title: 'Title'
        };
    })


    // iText controller
    .controller('iTextController', ['$scope',
        function($scope) {
            $scope.collapse = {};
            $scope.hideIText = function() {
                $scope.collapse = true;
            };

            $scope.showIText = function() {
                $scope.collapse = false;
            };
            $scope.toggleIText = function() {
                if ($scope.collapse) {
                    $scope.collapse = false;
                } else {
                    $scope.collapse = true;
                }
            };

        }

    ])

    // Custom onBlur function for elements which don't have a focus or blur state
    // For instance: i-Text
    .directive('outsideClick', ['$document', '$parse', function($document, $parse) {

        // Callback will determine which function to call on blur
        // TriggerId will exclude the click outside of the element (similar to e.preventDefault)

        //USAGE example
        //<div collapse="collapse" outside-click outside-click-trigger-id="enableTooltip1" outside-click-callback="hideTooltip()"> TEST </div>
        //
        // <button type="button" id="enableTooltip1" ng-click="toggleTooltip()" />

        return {
            link: function($scope, $element, $attributes) {
                onClick = function(event) {
                    var isChild = $element.find(event.target).length > 0;
                    var callback = $attributes.outsideClickCallback;
                    var triggerId = $attributes.outsideClickTriggerId;
                    var elementId = event.target.id;

                    if (!isChild && (elementId !== triggerId)) {
                        $scope.$apply(callback);
                    }
                };

                $document.on('click', onClick);

                $element.on('$destroy', function() {
                    $document.off('click', onClick);
                });
            }
        };
    }])

    .controller('AccordionDemoCtrl', function($scope) {
        $scope.oneAtATime = true;

        $scope.groups = [{
            title: 'Dynamic Group Header - 1',
            content: 'Dynamic Group Body - 1'
        }, {
            title: 'Dynamic Group Header - 2',
            content: 'Dynamic Group Body - 2'
        }];

        $scope.items = ['Item 1', 'Item 2', 'Item 3'];

        $scope.addItem = function() {
            var newItemNo = $scope.items.length + 1;
            $scope.items.push('Item ' + newItemNo);
        };

        $scope.status = {
            isFirstOpen: true,
            isFirstDisabled: false
        };
    })

    .controller('modalController', ['$scope', 'modal', function($scope, modal) {

        $scope.openInfoModal = function(content) {
            modal.openModal('INFO', content);

        };

        $scope.openConfirmationModal = function(content) {
            modal.openModal('CONFIRM', content);

        };

        $scope.openModalLoader = function(content) {
            modal.openModal('LOADER', content);
        };

    }])

    .controller('aabUpdateLoaderController', ['$scope', 'updateLoaderActivator',
        function($scope, updateLoaderActivator) {

            $scope.showUpdateLoader = function() {
                updateLoaderActivator.handleUpdateLoader({
                    information: 'This is an update loader with sooo much information, it has two lines (please wait)',
                    loader: true,
                    showSpinner: true,
                    delayMilliseconds: 2000
                });
            };

            $scope.hideUpdateLoader = function() {
                updateLoaderActivator.handleUpdateLoader({
                    loader: false
                });
            };

            $scope.succesUpdateLoader = function() {
                updateLoaderActivator.handleUpdateLoader({
                    endAfterMilliseconds: 2000,
                    information: 'Succes',
                    successIcon: true,
                    loader: true
                });
            };

        }
    ])

    // directive to show source button ('view source') on hover
    .directive('showSourceBtn', function($compile) {
        return {
            replace: true,
            scope: {},
            link: function(scope, element) {
                // append the sourcebutton
                var html = '<div ng-controller="ModalStyleguideCtrl"><div class="sg-view-source"> \
                         <div id="source-button" class="btn btn-primary btn-xs" ng-click="openSourceModal(\'lg\')"> \
                        View source</div></div></div>';
                var compiledHtml = $compile(html)(scope);
                element.append(compiledHtml);

                //var sourceBtnChildren = element.children();
                //sourceBtnChildren.eq(length-1).hide();
                // show the source button on hover
                element.bind('mouseenter', function() {
                    //sourceBtnChildren.eq(length-1).show();
                });
                element.bind('mouseleave', function() {
                    //sourceBtnChildren.eq(length-1).hide();
                });
            }

        };
    })

    .controller('aabDateField', ['$scope', 'deviceDetector',
        function($scope, deviceDetector) {
            $scope.dateTitle = "Date Picker For Mobile";
            $scope.dateDetector = deviceDetector;
        }
    ])

    .controller('datePickerController', ['$scope',
        function($scope) {
            //Max date value, from today to max date.
            var todayDate = new Date();
            var nextWeek = new Date(todayDate.getTime() + 7 * 24 * 60 * 60 * 1000);
            $scope.options = {
                minDate: todayDate,
                maxDate: nextWeek,
                format: 'dd-MM-yyyy',
                regex: /^(0[1-9]|[12][0-9]|3[01])[\/\-](0[1-9]|1[012])[\/\-]\d{4}$/, // enforce use of double digits; with single digits datepicker mixes up day/month
                blindDateSelectionText: 'Please select date value.'
            };

        }
    ])

    .controller('DateMaskController', ['$scope',
        function($scope) {
            $scope.options = {
                placeholder: 'dd-mm-jjjj',
                maskConfig: '99-99-9999',
            };
        }
    ])

    //Angular loading spinner
    .controller('loadingSpinnerController', ['$scope', 'loadingSpinnerActivator',
        function($scope, loadingSpinnerActivator) {

            $scope.showSpinner = function() {
                loadingSpinnerActivator.handleLoader({
                    delayMilliseconds: 1000
                });
            };

            $scope.hideSpinner = function() {
                loadingSpinnerActivator.handleLoader({
                    endAfterMilliseconds: 0
                });
            };
        }
    ])

    /*.controller('aabAccordionController', ['$scope', 'aabAccordionActivator',
        function ($scope, aabAccordionActivator) {

            $scope.oneAtATime = true;

            $scope.groups = [{
                title: ' Vivamus iaculis nulla non turpis tincidunt',
                content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus iaculis nulla non turpis tincidunt, ornare rhoncus nisi aliquet. Nulla vestibulum scelerisque euismod. Interdum et malesuada fames ac ante ipsum primis in faucibus. Proin nec auctor lacus. Sed lobortis nisl vitae massa condimentum, ut feugiat felis rutrum. Pellentesque sem libero, cursus ac vehicula at, vestibulum vel ligula. Nam cursus arcu id urna scelerisque varius sit amet non orci.',
                isOpen: true,
                disabled: false
            }, {
                title: 'Lorem ipsum dolor sit amet',
                content: 'Pellentesque volutpat nisi quam, sit amet lacinia nulla ullamcorper sit amet. Aliquam ultrices vulputate egestas. Ut commodo efficitur nisl at aliquam. Nunc ultrices elit quis tellus molestie, ornare pulvinar ipsum rutrum. Duis ut semper dui. Etiam et faucibus est, nec tempus erat. Phasellus cursus, leo eu imperdiet fringilla, erat ipsum tempus odio, vel tempor metus sem vitae velit. Nam aliquam velit et neque dapibus laoreet.',
                isOpen: false,
                disabled: false
            }, {
                title: 'Aliquam ultrices vulputate egestas',
                content: 'Pellentesque volutpat nisi quam, sit amet lacinia nulla ullamcorper sit amet. Aliquam ultrices vulputate egestas. Ut commodo efficitur nisl at aliquam.',
                isOpen: false,
                disabled: false
            }, {
                title: 'Ut commodo efficitur nisl at aliquam.',
                content: 'Dynamic Group Body - 4',
                isOpen: false,
                disabled: false
            }, {
                title: 'Pellentesque volutpat nisi quam',
                content: 'Dynamic Group Body - 5',
                isOpen: false,
                disabled: false
            }];

        }

    ])*/
    .controller('aabAccordionController', ['$scope', function($scope) {

                $scope.oneAtATime = true;

                $scope.groups = [{
                    title: ' Vivamus iaculis nulla non turpis tincidunt',
                    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus iaculis nulla non turpis tincidunt, ornare rhoncus nisi aliquet. Nulla vestibulum scelerisque euismod. Interdum et malesuada fames ac ante ipsum primis in faucibus. Proin nec auctor lacus. Sed lobortis nisl vitae massa condimentum, ut feugiat felis rutrum. Pellentesque sem libero, cursus ac vehicula at, vestibulum vel ligula. Nam cursus arcu id urna scelerisque varius sit amet non orci.',
                    isOpen: true,
                    disabled: false
                }, {
                    title: 'Lorem ipsum dolor sit amet',
                    content: 'Pellentesque volutpat nisi quam, sit amet lacinia nulla ullamcorper sit amet. Aliquam ultrices vulputate egestas. Ut commodo efficitur nisl at aliquam. Nunc ultrices elit quis tellus molestie, ornare pulvinar ipsum rutrum. Duis ut semper dui. Etiam et faucibus est, nec tempus erat. Phasellus cursus, leo eu imperdiet fringilla, erat ipsum tempus odio, vel tempor metus sem vitae velit. Nam aliquam velit et neque dapibus laoreet.',
                    isOpen: false,
                    disabled: false
                }, {
                    title: 'Aliquam ultrices vulputate egestas',
                    content: 'Pellentesque volutpat nisi quam, sit amet lacinia nulla ullamcorper sit amet. Aliquam ultrices vulputate egestas. Ut commodo efficitur nisl at aliquam.',
                    isOpen: false,
                    disabled: false
                }, {
                    title: 'Ut commodo efficitur nisl at aliquam.',
                    content: 'Dynamic Group Body - 4',
                    isOpen: false,
                    disabled: false
                }, {
                    title: 'Pellentesque volutpat nisi quam',
                    content: 'Dynamic Group Body - 5',
                    isOpen: false,
                    disabled: false
                }];

            }

        ])
    //show header with or without menu/navigation
    .controller('menuController', function($scope, $rootScope, $stateParams) {

        var aabHeader = document.getElementById('header');
        var aabFooter = document.getElementById('footer');
        $scope.menu = $stateParams.menu;

        $scope.$on('$stateChangeStart', function() {
            aabHeader.setAttribute('data-ng-include', "'templates/header.html'");
            aabFooter.setAttribute('data-ng-include', "'templates/footer.html'");
        });

        if (!$scope.menu) {
            aabHeader.setAttribute('data-ng-include', "'templates/header-without-menu.html'");
            aabFooter.setAttribute('data-ng-include', "'templates/footer-without-links.html'");
        }

        compile(aabHeader);
        compile(aabFooter);

    })

    .controller('NeutralHeaderController', ['$scope', '$window',
        function($scope, $window) {
            $scope.openNeutralHeader = function() {
                $window.open('#/neutralheader');
            };

        }

    ])

    .controller('tileEditableController', ['$scope', '$window',
        function($scope, $window) {
            $scope.editForm = false;
            $scope.tileData = true;
            $scope.editTextForm = function() {
                $scope.editForm = true;
                $scope.tileData = false;
            };

            $scope.submitTileForm = function() {
                $scope.editForm = false;
                $scope.tileData = true;
            };
        }

    ])

    .controller('accountDropdownController', ['$scope',
        function($scope) {
            var accountListData = {
                "accountsList": {
                    "account": [{
                        "accountNumber": "bonington",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1962.00,
                        "currency": "GBP",
                        "accountHolderName": "Chris Bonington's Spaarrekening",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873111"
                    }, {
                        "accountNumber": "honnold",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1985.00,
                        "currency": "USD",
                        "accountHolderName": "Alex Honnold",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873112"
                    }, {
                        "accountNumber": "hill",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1961.00,
                        "currency": "USD",
                        "accountHolderName": "Lynn Hill",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873112"
                    }, {
                        "accountNumber": "verhoeven",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1985.00,
                        "currency": "EUR",
                        "accountHolderName": "Jorg Verhoeven",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873113"
                    }, {
                        "accountNumber": "hillary",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1919.00,
                        "currency": "NZD",
                        "accountHolderName": "Sir Edmund Hillary",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873112"
                    }, {
                        "accountNumber": "norgay",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1914.00,
                        "currency": "NPR",
                        "accountHolderName": "Tenzing Norgay",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873113"
                    }, {
                        "accountNumber": "sharma",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1981.00,
                        "currency": "USD",
                        "accountHolderName": "Chris Sharma",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873113"
                    }, {
                        "accountNumber": "scott",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1941.00,
                        "currency": "GBP",
                        "accountHolderName": "Doug Scott",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873112"
                    }, {
                        "accountNumber": "harrer",
                        "externalName": "Vermogens Spaarrekening",
                        "currentBalance": 1912.00,
                        "currency": "EUR",
                        "accountHolderName": "Heinrich Harrer",
                        "overdraftLimit": 0,
                        "transferAllwdFlag": false,
                        "standingOrderFlag": true,
                        "ibanNumber": "NL11ABNA0603873113"
                    }],
                    "messages": {
                        "message": [{
                            "messageKey": "MESSAGE_GENSRV_0000",
                            "messageType": "INFO",
                            "fullText": ""
                        }]
                    }
                }
            };
            $scope.items = accountListData.accountsList.account;
            $scope.toggleList = false;
            $scope.toggleDropdown = function(event) {
                if (!$scope.toggleList) {
                    $scope.toggleList = true;
                } else {
                    $scope.toggleList = false;
                }

            };
        }

    ])

    .controller('alertController', ['$scope',
        function($scope) {
            $scope.isCollapsed = false;
            $scope.options = {

                title: 'Berichttitel (optioneel)', // will be filtered with "translate" and "aabTrustedHtml"
                text:  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid enim?'+
                       'Sed quot homines, tot sententiae; Bonum valitudo: miser morbus.'+
                       'Duo Reges: constructio interrete.', // will be filtered with "translate" and "aabTrustedHtml"
                options: {
                    info: true, // will hide error icon, and will make the alert appear as a warning
                    button:[{
                       text:'close',
                       styles:'glyphicon glyphicon-warning-sign',
                       action: function(){}
                    }]
                }

            };

        }

    ])
    // start of plunker styling of pin5 active/inactive
    .controller('countController', ['$scope',
        function($scope) {

            // $scope.pin = '';

            // $scope.boxes = [{
            //     state: false
            // }, {
            //     state: false
            // }, {
            //     state: false
            // }, {
            //     state: false
            // }, {
            //     state: false
            // }];


            // // start of watch function

            // $scope.$watch(function() {

            //     return $scope.pin;

            // }, function(newValue, oldValue) {

            //     $scope.elements = [];

            //     var ticked = $scope.pin.length;

            //     for (i = 0; i < $scope.boxes.length; i++) {

            //         if (i < ticked) {
            //             $scope.boxes[i].state = true;
            //         } else {
            //             $scope.boxes[i].state = false;
            //         }
            //     }

            // }); // end of watch function

        }
    ]);


    // end of plunker

    angular.element(document).ready(function() {
        angular.bootstrap(document, ['newApp']);
        //setHamburgerMenuHeight();
    });

    //funciton to compile DOM element
    function compile(element) {
        var el = angular.element(element);
        $scope = el.scope();
        $injector = el.injector();

        $injector.invoke(function($compile) {
            $compile(el)($scope)
        });
    }

    // set the height of the hamburger menu to the scrollHeight of the content
    // function setHamburgerMenuHeight() {
    //     var availableHeight;
    //     // get the scrollHeight of the document and set the minimum-height of the navbar to it.
    //     if(document.querySelector(".navbar-hamburger"))
    //     {
    //         availableHeight = 'calc(' + angular.element(document.querySelector("body")).prop("scrollHeight") + 'px - ' + document.querySelector(".navbar-hamburger").offsetHeight+'px' + ')';
    //         angular.element(document.querySelector(".navbar-main ")).css('min-height', angular.element(document.querySelector("body")).prop("scrollHeight"));
    //         angular.element(document.querySelector(".navbar-main .navbar-nav")).css('min-height', availableHeight);
    //     }

    // }

});
