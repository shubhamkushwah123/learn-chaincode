define('foundation/widget/state-manager', ['angular',
        'uiRouter',
        'foundation/widget/widget-utils'
    ],

    function(angular) {
        'use strict';

        angular
            .module('widget.stateManager', ['ui.router', 'widget.widgetUtilities'])

        /**
         * @ngdoc service
         * @name widget.stateManager.stateService:stateService
         * @description
         * StatesService is a provider that provides various utility functions around widget states
         * StatesService also allows for the dynamic addition of states to the ui-router state configuration.
         **/

        .provider('statesService', function statesService($stateProvider) {
            this.$get = function($state, $http, widgetUtils, $log) {
                return {

                    priv: {
                        /**
                         * @name getStateName
                         * @ngdoc method
                         * @methodOf widget.stateManager.stateService:stateService
                         * @description
                         * Retrieves the state name from the state description
                         *
                         * @param {String} name State name
                         * @param {Object} stateDescription Object that contain names of all widget states
                         * @returns {String} name of the state
                         */

                        getStateName: function(name, stateDescription) {
                            if (stateDescription && stateDescription[name]) {
                                return stateDescription[name] || '';
                            }
                            return '';
                        },

                        /**
                         * @ngdoc method
                         * @methodOf widget.stateManager.stateService:stateService
                         * @name isArrayElement
                         * @description
                         * It checks if element elem is part of the array
                         *
                         * @param {Array} array Widget states array
                         * @param {String} elem State name
                         * @returns {Boolean} false
                         */
                        isArrayElement: function(array, elem) {
                            for (var i = 0, len = array.length; i < len; i++) {
                                if (array[i] === elem) {
                                    return true;
                                }
                            }
                            return false;
                        },

                        /**
                         * @name normalizeUrl
                         * @ngdoc method
                         * @methodOf widget.stateManager.stateService:stateService
                         * @description
                         * Function for normalizing the url, it removes any leading slashes (/)
                         *
                         * @param {String} url State url
                         * @returns {String} url Returns sliced url
                         */
                        normalizeUrl: function(url) {
                            if (url.slice(0, 1) === '/') {
                                return url.slice(1, url.length);
                            } else {
                                return url;
                            }
                        }
                    },

                    /**
                     * @name goToState
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * Function that uses ui-router transitionTo method
                     * for navigation from one state to another one
                     
                     * @Deprecated
                     * @param {String} state State name
                     */
                    goToState: function(state, stateObject) {
                        this.transferToState(state, stateObject);
                    },

                    /**
                     * @name transferToSubState
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * This function handles state changes that involve a substate
                     *
                     * @param {String} name substate .substate
                     * @param {Object} stateDescription Object that contain names of all widget states
                     * @param {Object} stateObject State object
                     */
                    transferToSubState: function(substate, stateObject) {
                        var state = $state.current;
                        if (state) {
                            if (state.views) {
                                this.transferToState(state.parentModule + '.' + substate, stateObject);
                            } else {
                                this.transferToState(state.name + '.' + substate , stateObject);
                            }
                        } else {
                            $log.error('transferTo does not define state \'' + name + '\'');
                        }
                    },


                    /**
                     * @name transferToState
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * This function handles state changes that involve a state
                     *
                     * @param {String} name substate .substate
                     * @param {Object} stateObject State object
                     */
                    transferToState: function(stateName, stateObject) {
                        //console.log('transitionTo...');
                        $state.transitionTo(
                            stateName, 
                            { 
                                stateObj: stateObject
                            }, {
                                location: false,
                                reload: stateName
                            }
                        );
                    },


                    /**
                     * @name goToExitPath
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * Translates the exitpath in a destination that is relevant for the current state
                     *
                     * @param {String} exitPath Is the exitpath as it is known by the widget module
                     * @param {Object} stateObject State object
                     */

                    goToExitPath: function(exitPath, stateObject) {
                        var stateDescription = this.getCurrentStateDescription();
                        var state = this.priv.getStateName(exitPath, stateDescription);
                        if (stateDescription) {
                            var splitPath = exitPath.split('.');
                            if (splitPath.length === 2) {
                                if (splitPath[0].length === 0) {
                                    // we have a substate: .substate
                                    this.transferToSubState(splitPath[1], stateDescription, stateObject);
                                } else {
                                    //we have a full exiptath and substate: : state.substate
                                }
                            } else if (splitPath.length === 1 && state !== '') {
                                // we have a substate: state
                                this.transferToState(state, stateObject);
                            } else {
                                $log.error('transferTo does not define state \'' + name + '\'', stateDescription);
                            }
                        }
                    },

                    /**
                    * @name handleExitPath
                    * @ngdoc method
                    * @methodOf widget.stateManager.stateService:stateService
                    * @description
                    * Adds name and state to widget $stateProvider. State contain information regarding all
                    * widget's states including name, templateUrl, resolve functions.
                    *
                    * @param {String}  name State name
                    *
                    * @returns {Boolean} boolean to indicate if the exit path was handled succesfully
                    State object that contain states data
                    */

                    handleExitPath: function(exitPath, currentState) {

                        var stateDescription =this.getCurrentStateDescription();
                        currentState = currentState || $state.current || {};
                        var stateObj = $state.params.stateObj;
                        var view = undefined;

                        /* this will get the first property of the views object. 
                        If the views object would have been an array, we would have used views[0] instead */
                        if (currentState.views) {
                            for (var viewName in currentState.views) {
                                view = currentState.views[viewName];
                                break;
                            }
                        }
                        var stateObj = $state.params.stateObj;

                        //we are inside a subview of a widget module
                        if (typeof(currentState.parentModule) !== 'undefined' && currentState.views && view && view[exitPath] && view[exitPath].length > 0) {

                            //the target has a . name which means that target is the NAME of a substate
                            if (view[exitPath].indexOf('.') !== -1) {
                                this.goToExitPath(view[exitPath], stateObj);

                            //the target does not have a dot in the name which means that it is an actual exitpath
                            } else {
                                this.transferToState(view[exitPath], stateObj);
                            }
                            return true;

                        //we are inside a widget module. from here we can only refer to exitpaths
                        } else if (currentState && currentState.data && currentState.data.states && currentState.data.states[exitPath]) {
                            this.goToExitPath(exitPath, stateObj);
                            return true;
                        } else {
                            return false;
                        }
                    },

                    /**
                     * @name handleGoBack
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     *
                     * @description
                     * Utility function around handleExitPath('back')
                     * @returns {Boolean} true or
                     */
                    handleGoBack: function() {
                        //if service calls are in progress; then disable back
                        if ($http.pendingRequests.length > 0) {
                            return true;
                        }
                        return this.handleExitPath('back');
                    },


                    /**
                     * @name stateExists
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     *
                     * @description
                     * This function checks if the state is already part of the UI-router state configuration
                     *
                     * @param {String} name State name
                     * @returns {Boolean} false
                     */
                    stateExists: function(name) {
                        var states = $state.get();
                        for (var i = 0, len = states.length; i < len; i++) {
                            if (states[i].name === name) {
                                return true;
                            }
                        }
                        return false;
                    },


                    /**
                     * @name getStateByName
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * This function goes through the states and looks for the right one state by Name.
                     * @param {String} name State name
                     * @returns {Object} full state description
                     */
                    getStateByName: function(name) {
                        /** checks if ulr is defined, if not - returns undefined */
                        var states = $state.get();

                        /**
                         * @description
                         * Goes through the states and checks that state name and requested name are the same
                         *
                         * @returns {Object} state object If state.name the same as name,
                         * it returns state name
                         */

                        for (var i = 0, len = states.length; i < len; i++) {
                            if (states[i].name === name) {
                                return states[i];
                            }
                        }
                        return undefined;
                    },


                    /**
                     * @name getStateByUrl
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * This function goes through the states and looks for the right one state by Url.
                     * @param {String} url State url
                     * @returns {String} stateName
                     */
                    getStateByUrl: function(url) {
                        /** checks if ulr is defined, if not - returns undefined */
                        if (!url) {
                            return undefined;
                        }
                        url = this.priv.normalizeUrl(url);
                        var states = $state.get();
                        /**
                         * @description
                         * Goes through the states and checks that state url and requested url are the same
                         *
                         * @returns {Object} state.name If state.url the same as url, it returns state name
                         */
                        for (var i = 0, len = states.length; i < len; i++) {
                            if (states[i].url === url) {
                                return states[i].name;
                            }
                        }
                        return undefined;
                    },

                    /**
                     * @name getStateByTrigger
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     
                     * @description
                     * This function goes through the states and looks for the right one by templateUrl.
                     *
                     * @param {String} path Current state file path
                     * @returns {String} stateName
                     */
                    getStateByTrigger: function(trigger) {
                        if (!trigger) {
                            return undefined;
                        }
                        trigger = this.priv.normalizeUrl(trigger);
                        var states = $state.get();
                        for (var i = 0, len = states.length; i < len; i++) {
                            if (states[i].trigger === trigger) {
                                return states[i].name;
                            }
                        }
                        return undefined;
                    },


                    /**
                     * @name triggerExists
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * [Description goes here]
                     * @param {String} trigger trigger
                     * @returns {Boolean} triggerExists
                     */

                    triggerExists: function(trigger) {
                        var uiState = this.getStateByTrigger(trigger);
                        return angular.isDefined(uiState);
                    },



                    /**
                     * @name getCurrentStateDescription
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * Gets the state description [{exitpath: state}]
                     *
                     * @returns {Object} full mapping of exitpaths and states for this state
                     */

                    getCurrentStateDescription: function() {
                        var state = $state.current;

                        //console.log("--- state", state);
                        if (state && state.data && state.data.states) {
                            return state.data.states;
                        }
                        return undefined;
                    },




                    /**
                     * @name getStateDescriptionByPath
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * Gets the state description [{exitpath: state}]
                     *
                     * @param {String} path Current state file path
                     * @returns {Object} full mapping of exitpaths and states for this state
                     */

                    getStateDescriptionByPath: function(path) {
                        var states = $state.get();

                        /**
                         * @description
                         * Goes through the states and checks that state templateUrl the same as path.
                         *
                         * @returns {Object} state.data.states Object that contain information regarding
                         * states of current widgetModule
                         */
                        for (var i = 0, len = states.length; i < len; i++) {
                            var state = states[i];

                            /**
                             * @description
                             * If state templateUrl the same as path, returns matched state
                             *
                             * @returns {Object} state.data.states Returns matched state
                             */
                            if (state.templateUrl && state.templateUrl === path && state.data && state.data.states) {
                                return state.data.states;
                            }
                        }
                        return undefined;
                    },

                    /**
                     *
                     * @name stateIsValid
                     * @ngdoc
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * This function checks that stateObj is defined or empty string
                     * and checks if state is part of the metaData.states array.
                     *
                     * @param {Object} stateObj Object that contain information
                     * regarding states of current widgetModule
                     * @param {Object} metaData Object that contain information
                     * regarding states, name and localPath
                     * @returns {Object} { isvalid:true|false, message: 'error message'}
                     * Object containing both result and error message
                     */
                    stateIsValid: function(stateObj, metaData) {

                        /**
                         * @description
                         * This function checks that stateObj is defined or empty string
                         * and checks if state is part of the metaData.states array.
                         *
                         * @returns {Boolean} isValid Flag means that states are not defined
                         * @returns {String} message Error message
                         */

                        for (var i = 0, len = metaData.states.length; i < len; i++) {
                            var path = metaData.states[i];
                            if (!stateObj[path] || stateObj[path] === '') {
                                return {
                                    isValid: false,
                                    message: 'State config does not define state from exit path \'' + path + '\''
                                };
                            }
                        }

                        /**
                         * @description
                         * It checks if element elem is part of the array
                         * Goes through state in stateObj and checks if state
                         * is part of the metaData.states array.
                         *
                         * @returns {Boolean} isValid Flag means that states are not defined
                         * @returns {String} message Error message
                         */
                        for (var state in stateObj) {
                            if (!this.priv.isArrayElement(metaData.states, state)) {
                                return {
                                    isValid: false,
                                    message: 'UI router definition \'' + state + '\' is not an existing exit path'
                                };
                            }
                        }
                        return {
                            isValid: true,
                            message: ''
                        };
                    },

                    /**
                     * @name handleGoToState
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     *
                     *
                     * @param {String}  State State name
                     * @returns {Boolean} handled
                     */
                    handleGoToState: function(state) {
                        var uiState = this.getStateByTrigger(state);
                        if (uiState) {
                            this.goToState(uiState);
                            return true;
                        } else {
                            return false;
                        }
                    },

                    /**
                     * @name addState
                     * @ngdoc method
                     * @methodOf widget.stateManager.stateService:stateService
                     * @description
                     * Adds name and state to widget $stateProvider. State contain information regarding all
                     * widget's states including name, templateUrl, resolve functions.
                     *
                     * @param {String}  name State name
                     * @returns {Object} state State object that contain states data
                     */
                    addState: function(name, state) {
                        $stateProvider.state(name, state);
                    },




                    hideBackButton: function() {
                        var current = $state.current;

                        if (current && current.hideBackButton) {
                            return true;
                        } else {
                            return false;
                        }
                    }

                };
            };
        });
    });
