define('component/ui/modal/modal-instance-info-controller', ['angular'], function(angular) {

    angular
        .module('service.modalInstanceInfo', ['ui.bootstrap'])
        .controller('modalInstanceInfoController', modalInstanceInfoController);

    // Controller responsible for the logic inside the modal template - content can be passed for example in the form of a JSON file from Tridion/ Backbase
    function modalInstanceInfoController($scope, $modalInstance, content) {

        $scope.title = content.title;
        $scope.text = content.text;

        $scope.ok = function() {
            $modalInstance.close();
        };
    }
});
