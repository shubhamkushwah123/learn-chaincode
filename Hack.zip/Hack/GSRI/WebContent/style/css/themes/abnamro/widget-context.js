/** TODO
 * - check with Satija if this covers his requirements
 * - add callable functions to the header config
 * - allow to navigatie to widget sub module from the header
 * - remove widgetnextback.html and .js
 * - make title editable, bothg literal and as translation key
 *
 * - make change log:
 * widgetnextback has been replaced with widget level changes, widget module level changes
 * back and next buttons are now left and righ to indicate their position rather
 * then their default function(which can change)
 * change headersetting from the widget/widget-module and widget module meta-data
 */
define('foundation/widget/widget-context', ['angular'], function () {

    'use strict';

    angular
        .module('widget.widgetContext', ['preferences.manager'])

    /**
     * @name widget.widgetContext.widgetContext:widgetContext
     * @ngdoc service
     * @description
     * widgetContext is a state and helper service for the widget directive.
     */
        .provider('widgetContext', function () {

            // refer to this as self
            var self = this;

            // TODO is this necessary?
            self.name = 'widgetContext';

            /**
             * define the properties structure inside the provider
             * also I moved the changeHeaderSettings function out of the defaultHeaderSettings block
             */

            self.defaultHeaderSettings = {
                leftButton: {},
                rightButton: {},
                general: {}
            };

            self.defaultHeaderSettings.leftButton = {
                text: 'Button-Back',
                show: false,
                exitPath: 'back',
                class: 'btn btn-default ocf-btn-back'
            };

            self.defaultHeaderSettings.rightButton = {
                text: 'Button-Cancel',
                show: false,
                exitPath: 'next',
                class: 'btn btn-default ocf-btn-cancel'
             },

             self.general = {
                title : ''
             }


            self.headerSettings = JSON.parse(JSON.stringify(self.defaultHeaderSettings));

            /**
             * @ngdoc method
             * @name changeDefaultHeaderSettings
             * @methodOf widget.widgetContext.widgetContext:widgetContext
             * @description
             * Changes the default header setting for the widget. This means that all widgets will use this new setting
             *
             * @param {object} changedSettings an object with the new values for the header
             *
             * @example
             * The default header settings are as shown below:
                    <pre>
                    {
                        leftButton = {
                    //the translation key for the text of the button
                            text: 'Button-Back',

                    //show or hide the button
                            show: false,
                            
                    //exitPath with a state or substate
                            exitPath: 'back', 
                            class: 'btn btn-default ocf-btn-back'
                        },
                    //the translation key for the text of the button
                        rightButton = {
                    //the translation key for the text of the button
                            text: 'Button-Cancel',

                    //show or hide the button
                            show: false,

                    //exitPath with a state or substate OR a function inside the controller of the current widget module
                            exitPath: 'next',
                            class: 'btn btn-default ocf-btn-cancel'
                         }
                    }
                    </pre>

             */
            self.changeDefaultHeaderSettings = function (changedSettings) {
                if (changedSettings) {
                    angular.extend(self.defaultHeaderSettings.leftButton, changedSettings.leftButton);
                    angular.extend(self.defaultHeaderSettings.rightButton, changedSettings.rightButton);
                }
            };

            /**
             * @ngdoc method
             * @name changeHeaderSettings
             * @methodOf widget.widgetContext.widgetContext:widgetContext
             * @description
             * Changes the header setting for the widget
             *
             * @param {object} changedSettings an object with the new values for the header
             *
             * @example
             * The default header settings are as shown below:
                    <pre>
                    {
                        leftButton = {
                    //the translation key for the text of the button
                            text: 'Button-Back',

                    //show or hide the button
                            show: false,
                            
                    //exitPath with a state or substate OR a function inside the controller of the current widget module
                            exitPath: 'back', OR
                            exitFunction: {
                                function: 'cancel',
                                controller: this,
                                params : ['cancelled']
                            },
                            class: 'btn btn-default ocf-btn-back'
                        },
                    //the translation key for the text of the button
                        rightButton = {
                    //the translation key for the text of the button
                            text: 'Button-Cancel',

                    //show or hide the button
                            show: false,

                    //exitPath with a state or substate OR a function inside the controller of the current widget module
                            exitPath: 'next', OR
                            exitFunction: {
                                function: 'cancel',
                                controller: this, 
                                params : ['cancelled']
                            },
                            
                            class: 'btn btn-default ocf-btn-cancel'
                         },
                         general = {
                    //sets the literal value of the title
                            title : '',
                    //provides a translation key to the title so it can be displayed in multiple languages
                            titleKey: 'widget-title'
                         }
                    }
                    </pre>
             */
            self.changeHeaderSettings = function (changedSettings) {
                if (changedSettings) {

                    if(changedSettings.general){

                        if(changedSettings.general.title){
                            changedSettings.general.titleKey =  undefined;
                        } else if (changedSettings.general.titleKey) {
                            changedSettings.general.title =  undefined;
                        }
                    }
                    angular.extend(self.headerSettings.general, changedSettings.general);
                    angular.extend(self.headerSettings.leftButton, changedSettings.leftButton);
                    angular.extend(self.headerSettings.rightButton, changedSettings.rightButton);
                }
            };


            /**
             * @ngdoc method
             * @name resetHeaderSettings
             * @methodOf widget.widgetContext.widgetContext:widgetContext
             * @description
             * Reset the header settings to the default values
             */
            self.resetHeaderSettings = function () {
                self.headerSettings.leftButton = JSON.parse(JSON.stringify(self.defaultHeaderSettings.leftButton));
                self.headerSettings.rightButton = JSON.parse(JSON.stringify(self.defaultHeaderSettings.rightButton));
            };

            self.widgetModuleStateObject = undefined;

            /**
             * @ngdoc method
             * @name clearWidgetModuleStateObject
             * @methodOf widget.widgetContext.widgetContext:widgetContext
             *
             * @param {object} stateObject the reference to the stateObject to store
             *
             * @description
             * Stores a reference to the widget modules stateObject with the widget to make
             * it accessible at the widget level
             *
             */
            self.setWidgetModuleStateObject = function (stateObject) {
                self.widgetModuleStateObject = stateObject;
            };


            /**
             * @ngdoc method
             * @name clearWidgetModuleStateObject
             * @methodOf widget.widgetContext.widgetContext:widgetContext
             * @description
             * Clears the reference to the widget modules stateObject with the widget
             */
            self.clearWidgetModuleStateObject = function () {
                self.widgetModuleStateObject = undefined;
            };

            self.widgetModuleController = undefined;

            self.setWidgetModuleController = function (controller) {
                self.widgetModuleController = controller;
            };

            self.clearWidgetModuleController = function () {
                self.widgetModuleController = undefined;
            };

            self.getHeaderSettings = function () {
                return self.headerSettings;
            };

            /**
             * @name $get method
             * @description
             *
             * @returns {Array} stateConfig
             * @returns {Undefined} handleStateChange
             */
            this.$get = function () {
                return {
                    stateConfig: [],

                    /**
                     * @ngdoc method
                     * @name handleStateChange
                     * @methodOf widget.widgetContext.widgetContext:widgetContext
                     *
                     * @param {object} fromState the name of the previous state
                     * @param {object} toState the name of the next state
                     * @param {object} stateObject the stateObject being passed into the next widget module
                     *
                     * @description
                     * this is a callback that CAN be implemented in the widget
                     * for example to convert stateObject structure
                     */
                    handleStateChange: undefined,

                    getHeaderSettings: self.getHeaderSettings,

                    changeHeaderSettings: self.changeHeaderSettings,
                    changeDefaultHeaderSettings: self.changeDefaultHeaderSettings,
                    resetHeaderSettings: self.resetHeaderSettings,

                    setWidgetModuleStateObject: self.setWidgetModuleStateObject,
                    clearWidgetModuleStateObject: self.clearWidgetModuleStateObject,

                    setWidgetModuleController: self.setWidgetModuleController,
                    clearWidgetModuleController: self.clearWidgetModuleController,
                    _private_: self
                };
            };
        });
});