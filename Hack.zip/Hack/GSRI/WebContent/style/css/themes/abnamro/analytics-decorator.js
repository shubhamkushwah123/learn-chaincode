define('foundation/widget/analytics-decorator',
    ['angular',
        'angulartics',
        'component/device/device-detector'
    ],

    function(angular){
        'use strict';

        function widgetConfiguration($provide){

            $provide.decorator('$analytics', function($delegate, $injector, deviceDetector, $window){

                var service = $delegate;
                var oldEventTrack = service.eventTrack;
                var oldPageTrack = service.pageTrack;

                var tagplan = {
                    timeStamp: undefined,
                    device: 'desktop',
                    portal: undefined,
                    page: undefined,
                    widgetName: undefined,
                    widgetTitle: undefined,
                    widgetModule: undefined,
                    state: undefined
                };

                var validateEventName = function validateEventName(str){
                    if (!/^(click|change|focus|submit|init|process|update):[a-z\-]{1,32}$/.test(str)) {
                        console.warn('Analytics error: invalid event name', str);
                    }
                };

                service.eventTrack = function(eventName, trackingData){

                    validateEventName(eventName);
                    trackingData = service.mapTrackingData(trackingData);
                    oldEventTrack.apply(this, [eventName, trackingData]);
                };

                service.pageTrack = function(eventName, trackingData){

                    validateEventName(eventName);
                    trackingData = service.mapTrackingData(trackingData);
                    oldPageTrack.apply(this, [eventName, trackingData]);
                };

                service.stateTrack = function(eventName, state){
                    validateEventName(eventName);

                    var trackingData = service.mapTrackingData(undefined, state);
                    oldPageTrack.apply(this, [eventName, trackingData]);

                };


                service.mapTrackingData = function(trackingData, state){

                    tagplan.timeStamp = new Date();


                    //define the current state
                    var currentState;
                    if (state) {
                        currentState = state;
                    } else {
                        state = $injector.get('$state');
                        if (state) {
                            currentState = state.current;
                        }
                    }

                    //get the proper state
                    if (currentState) {
                        if (currentState.parentModule) {
                            tagplan.state = currentState.parentModule;
                            tagplan.substate = currentState.name;
                        } else {
                            tagplan.state = currentState.name;
                            tagplan.substate = '';
                        }
                        tagplan.widgetModule = currentState.templateUrl;
                    }

                    //get the device
                    if (deviceDetector.isMobile()) {
                        tagplan.device = 'mobile';
                    }

                    //
                    if (b$ && b$.portal && b$.portal.getCurrentPage) {
                        tagplan.page = b$.portal.getCurrentPage().name;
                    }

                    var w = $injector.get('widgetModel');
                    if (w) {
                        tagplan.portal = w.contextItemName;
                        tagplan.widgetName = w.extendedItemName;
                        tagplan.widgetTitle = w.attributes && w.attributes.title && w.attributes.title.nodeValue;
                    }

                    trackingData = trackingData || {};
                    angular.extend(tagplan, trackingData);
                    return tagplan;
                };

                return $delegate;
            });

        }

        angular
            .module('analytics.decorator', ['deviceDetection', 'angulartics'])
            .config(widgetConfiguration);


    });
