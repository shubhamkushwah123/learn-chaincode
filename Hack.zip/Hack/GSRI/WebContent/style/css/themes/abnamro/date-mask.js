/**
 * @description
 * Displays date mask field based on device detection.
 * If it is mobile user will see HTML5 input type date and it will invoke native date picker in mobile.
 * If it is desktop, user will see input field with masking.
 * @author Karthik Devaraj
 */
define('component/ui/mask/date-mask/date-mask', ['angular', 'angular-ui-mask', 'component/device/device-detector'], function(angular) {
    'use strict';

    function dateMaskController($scope){
        var vm = this;
        vm.options = $scope.options;
    }

    function getTemplateUrl(isMobile){
        if(isMobile){
            return 'oca/app/components/ui/date-picker/device-date-picker.html';
        }else{
            return 'oca/app/components/ui/mask/date-mask/date-mask.html';
        }
    }

    function aabDateMask(deviceDetector){
        var isMobile = deviceDetector.isMobile();
        var templateUrl = getTemplateUrl(isMobile);
        var dateMaskDirective = {
            replace: true,
            restrict: 'EA',
            scope: {
                ngModel: '=',
                options: '=',
                disabled: '='
            },
            templateUrl: templateUrl,
            controller: dateMaskController,
            controllerAs: 'vm'
        };
        return dateMaskDirective;
    }

    angular.module('ui.dateMask', ['ui.mask', 'deviceDetection'])

    /**
     * @ngdoc directive
     * @module ui.dateMask
     * @name ui.dateMask.aabDateMask:aabDateMask
     * @description
     * Creates an elements HTML5 type date for mobile and type "text" for desktop browser.
     * @restrict EA
     * @scope
     **/
    .directive('aabDateMask', aabDateMask)
    .controller('DateMaskController', dateMaskController);
});
