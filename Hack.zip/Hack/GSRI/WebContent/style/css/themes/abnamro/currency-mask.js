define('component/ui/mask/currency-mask/currency-mask', ['angular', 'component/filters/currency-locale'], function(angular) {
    'use strict';

    angular.module('ui.currencyMask', ['filter.currencyLocale'])
        /**
         * @ngdoc directive
         * @name ui.currencyMask.aabCurrencyMask:aabCurrencyMask
         * @restrict EA
         * @requires $timeout
         * @requires $parse
         * @param {scope/context variable} ng-model Input value is binded to this
         * @param {Number=} limit defines maximum number of characters allowed into Input
         * @param {Number} tabindex defines taxindex for Input field
         * @param {scope/context variable =} active-status If this attribute is defined then component attaches
         * focus/blur events to input field and updates given scope/context variable
         * @description
         * Creates a Input box of numeric type which accepts only numeric input and
         * Escapes Alphabets and special characters
         */
        .directive('aabCurrencyMask', ['$timeout', '$parse', '$filter', function($timeout, $parse, $filter) {

            return {
                restrict: 'EA',
                require: '^ngModel',
                scope: {
                    balance: '='
                },
                templateUrl: 'oca/app/components/ui/mask/currency-mask/currency-mask.html',
                replace: true,
                link: function(scope, element, attrs, ngModel) {

                    // check for sufficient balance
                    if (attrs.hasOwnProperty('balance')) {
                        scope.$watch(function(newvalue) {
                            return newvalue.balance;
                        }, function(newBalance, oldBalance) {
                            //only validate when and amount is entered and account or entered date changes
                            if (angular.isDefined(newBalance.enteredAmount) &&
                                (!angular.equals(newBalance.allowedAmount, oldBalance.allowedAmount) ||
                                    !angular.equals(newBalance.enteredDate, oldBalance.enteredDate))) {
                                ngModel.$setValidity('balance', insufficientBalance(scope.balance) ? false : true);
                            }
                        }, true);
                    }

                    element.on('blur', function() {

                        var value = element.val(),
                            isValidInput = /^\d*(\,\d{2})?$/;

                        // if contains alphabets don't convert it

                        if (isValidInput.test(value)) {
                            element.val($filter('currencyLocale')(value, 'locale'));
                        }

                        // if entered value is not a number
                        ngModel.$setValidity('isValidInput', isValidInput.test(value) ? true : false);

                        var tmpValue = value.replace(/,([^,]*)$/, '.$1');
                        tmpValue = parseFloat(tmpValue).toFixed(2);

                        // if entered value is not a number
                        ngModel.$setValidity('isnan', tmpValue === 'NaN' ? false : true);

                        //if balance is set; then validate when scope changes
                        if (attrs.hasOwnProperty('balance')) {
                            ngModel.$setValidity('balance', insufficientBalance(scope.balance) ? false : true);
                        }

                        // if maxValue attribute is set; then validate this
                        if (attrs.hasOwnProperty('maxvalue')) {
                            ngModel.$setValidity('maxvalue', tmpValue > parseFloat(attrs.maxvalue) ? false : true);
                        }

                        // if minValue attribute is set; then validate this
                        if (attrs.hasOwnProperty('minvalue')) {
                            ngModel.$setValidity('minvalue', tmpValue < parseFloat(attrs.minvalue) ? false : true);
                        }

                        // apply the changes in ngModel so that element.$valid is updated
                        scope.$apply();

                    });

                    element.on('paste', function() {
                        return false;
                    });

                    function insufficientBalance(balance) {

                        var initial = (new Date(balance.enteredDate)).setHours(0, 0, 0, 0),
                            defaultDate = (new Date(balance.todayDate)).setHours(0, 0, 0, 0),
                            enteredAmount = parseFloat($filter('currencyLocale')(balance.enteredAmount, 'decimals')),
                            allowedAmount = parseFloat(balance.allowedAmount).toFixed(2);


                        if (initial === defaultDate && enteredAmount > allowedAmount) {
                            return true;
                        }

                    };
                }
            };
        }]);



});
