define('foundation/widget/widget-directive', ['angular',
    'foundation/widget/widget-constants',
    'foundation/widget/analytics-decorator',
    'foundation/widget/cookie-decorator',
    'foundation/widget/widget-bundle',
    'component/ui/alert/alert'
],
function(angular) {
    'use strict';
    angular.module('widget.widget', [
        'ui.router',
        'widget.bundle',
        'analytics.decorator',
        'widget.cookie-decorator',
        'ui.alert'
    ]).constant('WIDGET_TEMPLATE', {
        application: 'application',
        content: 'content',
        header: 'header'
    }).controller('widgetDirectiveController', widgetDirectiveController)
        .directive('aabWidget', widgetDirective);

    /**
     * @ngdoc directive
     * @module widget.widget
     * @name widget.widget.widget:widget
     * @restrict E
     * @param {string} ng-controller Controller to be executed for this widget.
     * @description
     * The widget is directive that initializes BB widget, maps it to widget controller.
     * It adds all widget's states to ui-router configuration and registers listener for states changes.
     * Contain even listeners and cancels them on widget layer/level, so widget events can't go upper to page layer.
     */
    function widgetDirective(WIDGET_TEMPLATE) {
        return {
            restrict: 'E',
            controller: widgetDirectiveController,
            controllerAs: 'widget',
            templateUrl: function($node, attr) {
                switch (attr.widgetTemplate) {
                    case WIDGET_TEMPLATE.header:
                        return 'oca/app/foundation/widget/widget-template-header.html';
                    case WIDGET_TEMPLATE.content:
                        return 'oca/app/foundation/widget/widget-template-content.html';
                    case WIDGET_TEMPLATE.application:
                    default:
                        return 'oca/app/foundation/widget/widget-template-application.html'
                }
            },
            scope: false
        };
    }

    function widgetDirectiveController($rootScope, $scope, $location, $state, $urlRouter, widgetContext, $timeout, widget, widgetUtils, statesService, eventService, widgetPreferences, $log, $analytics, bridge, $sanitize) {
        var self = this;
        var priv = {
            initScopeListeners: function() {
                $scope.$on('aab-widget-change-title', function(event, title) {
                    priv.setTitle(title);
                });
                $scope.$on('aab-widget-handle-error', function (event, errorTitle, errorText, isRecoverable, isWarning, buttons) {
                    priv.setWidgetError(errorTitle, errorText, isRecoverable, isWarning, buttons);
                });
                $rootScope.$on('aab-widget-resthandler-error', function(event, errorTitle, errorText) {
                    priv.setWidgetError(errorTitle, errorText);
                });
                $scope.$on('aab-widget-reset-error', function() {
                    priv.resetWidgetError();
                });
            },
            setTitle: function(title) {
                //widgetContext.title = title;
                widgetContext.changeHeaderSettings({
                    general: {
                        title: title
                    }
                });
                eventService.sendSetTitle(widgetContext, title);
            },
            resetWidgetError: function() {
                widgetContext.error = undefined;
            },
            setWidgetError: function (errorTitle, errorText, isRecoverable, isWarning, buttons) {
                widgetContext.error = {
                    title: errorTitle,
                    text: errorText,
                    isRecoverable: isRecoverable,
                    options: {
                        info: isWarning,
                        button: buttons
                    }
                };
            },
            processStateConfig: function() {
                // Process the widget's state configuration and add them to ui-router
                for (var i = 0, len = widgetContext.stateConfig.length; i < len; i++) {
                    var c = widgetContext.stateConfig[i];
                    statesService.addState(c.name, {
                        params: {
                            stateObj: {}
                        },
                        /**
                         * widgets are not supposed to modify the url so we
                         * add the url property to a custom property
                         * called trigger. We use the value in trigger to check
                         * if it matches with state changes in the URL
                         */
                        trigger: c.url,
                        templateUrl: widgetUtils.resolvePath(widget.model, c.templateUrl),
                        data: c.data,
                        eventName: c.eventName,
                        controller: c.controller,
                        resolve: c.resolve,
                        hideBackButton: (typeof c.hideBackButton === 'boolean') ? c.hideBackButton : false
                    });
                }
            },
            initEventListeners: function(vm) {
                // Add a listener to the widget model to handle state change events
                jQuery(widget.model).on('navigation.goToState', function(e, state) {
                    statesService.handleGoToState(state);
                });
                // Add a listener to the widget model to handle state change events
                jQuery(widget.model).on('navigation.goBack', function() {
                    vm.handleGoBackEvent();
                });

                /**
                 * @description
                 * Adds a.onclick listener to the widget.
                 * If the click reaches this point then we must prevent it from propagating any further
                 *
                 * @returns {Function} event.stopPropagation Function for stopping the bubbling
                 * @returns {Boolean} true Flag that stops bubbling for IE
                 */
                jQuery(widget.body).on('click', 'a', function(event) {
                    event = event || window.event;
                    // cross-browser event
                    if (event.stopPropagation) {
                        event.stopPropagation();
                    } else {
                        // IE variant
                        event.cancelBubble = true;
                    }
                });
            },
            initSteps: function() {
                var steps = [];
                for (var i in widgetContext.stateConfig) {
                    if (widgetContext.stateConfig[i].hasOwnProperty('step')) {
                        steps.push(widgetContext.stateConfig[i]);
                    }
                }
                widgetContext.steps = steps;
            },
            initSdm: function() {
                if (widgetPreferences.getProperty('sdmKey')) {
                    widgetContext.sdmKey = widget.getPreference('sdmKey');
                }
            },
            initHeaderButtons: function() {
                widgetContext.hideHeader = widgetContext.hideHeader || false;
                /**
                 * Why checking if it returns a proper value or true and then a switch? Can't the switch be executed
                 * anyhow? The switch will deal with the returned property right? Even if it is undefined?
                 */
                var hideHeader = widgetPreferences.getProperty('hideHeader');
                switch (hideHeader) {
                    case 'masterpage':
                        widgetContext.hideHeader = widgetPreferences.getProperty('hideHeader', true);
                        break;
                    case true:
                    case false:
                        widgetContext.hideHeader = hideHeader;
                        break;
                    default:
                        widgetContext.hideHeader = false;
                }
            },
            /**
             * @name processDeepLinking
             * @param widgetStateName {String}, urlParameters {Object}
             * @description This function set-up the deep linking parameters and state to the widget
             */
            processDeepLinking: function(widgetStateName, urlParameters) {
                // If the deep link has widget-state-name
                if (widgetStateName && statesService.stateExists(widgetStateName)) {
                    widget.hasDeepLink = true;
                    widget.tranferToState = widgetStateName;
                    // Get the parameters from the deep link URL
                    if (urlParameters) {
                        urlParameters = $sanitize(urlParameters);
                        var paramsFromUrl = widgetUtils.getUrlParameters(urlParameters);
                        $state.transitionTo(widget.tranferToState, {
                            stateObj: {
                                'deepLinkURLParams': paramsFromUrl
                            }
                        }, {
                            location: false
                        });
                    }
                } else {
                    $scope.$emit('aab-widget-handle-error', 'errorCodeTechnicalErrorTitle', 'errorCodeTechnicalError');
                }
            },
            initDeepLinking: function() {
                // Check if the deep linking is enabled.
                if (widget.model.deepLinkWidgetStateName || widget.model.deepLinkURLParams) {
                    priv.processDeepLinking(widget.model.deepLinkWidgetStateName, widget.model.deepLinkURLParams);
                }
                jQuery(widget.model).on('navigation.goToUrl', function(e, widgetStateName, urlParameters) {
                    priv.processDeepLinking(widgetStateName, urlParameters);
                });
            }
        };
        self.name = 'widgetDirectiveController';
        priv.initSteps();
        priv.initHeaderButtons();
        priv.initSdm();
        priv.processStateConfig();
        // pass the controller (self) rather then the $scope
        priv.initEventListeners(self);
        priv.initDeepLinking();
        widgetContext.componentType = 'toast';
        // initialize the default header values
        widgetContext.changeHeaderSettings(undefined);
        $rootScope.$on('$stateChangeError', function() {
            $scope.$emit('aab-widget-handle-error', 'errorCodeTechnicalErrorTitle', 'errorCodeTechnicalError');
        });
        $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
            priv.resetWidgetError();
            // merge the incoming params into the outgoing params
            var tmpStateObject = angular.extend({}, fromParams.stateObj, toParams.stateObj);
            var showBack = widgetUtils.hasBackState(toState);
            if (!toState.parentModule) {
                $analytics.stateTrack('init:state', toState);
            } else {
                $analytics.stateTrack('init:substate', toState);
            }
            // check to see if this state is of type event
            if (toState.eventName && toState.eventName.length > 0) {
                event.preventDefault();
                var tmpPreference = widget.getPreference(toState.eventName);

                if (tmpPreference.trim() === '@close@') {
                    eventService.sendBackStateNotAvailable(widget, statesService.hideBackButton());
                } else {
                    eventService.sendExitStateEvent(toState, tmpStateObject, widget);
                    return false;
                }

            }

            if (widgetContext.widgetInitialized) {
                eventService.sendStateChanged(widget, showBack);
            } else {
                widgetContext.widgetInitialized = true;
            }

            /**
             * @ngdoc event
             * @name widget.widget.widget#widgetContext.handleStateChange
             * @eventOf widget.widget.widget:widget
             * @eventType broadcast
             * @description
             * Called when the widget transitions from one state to the next
             *
             * @param {string} fromState The name of the originating state.
             * @param {string} toState The name of the destination state.
             * @param {Object} stateObject The object being passed between the two states. The object
             * in its current state is how it exited the originating state
             *
             * @param {Object} returnValue. Returned by handleStateChange.
             * The stateObject after some manipulation by the the handleStateChange handler in the controller
             * The object in its current state is how it will enter the destination state
             *
             * @example
             *<pre>
             * widgetContext.handleStateChange = function (fromState, toState, stateObject) {
             *       if (fromState == "entry" && toState == "transfer-money") {
             *       stateObject.fullname = stateObject.name;
             *       stateObject.bankCardNumber = stateObject.cardNumber;
             *    }
             *    return stateObject;
             *};
             *</pre>
             */
            if (typeof(widgetContext.handleStateChange) === 'function') {
                tmpStateObject = widgetContext.handleStateChange(fromState.name, toState.name, tmpStateObject);
            }
            toParams.stateObj = tmpStateObject;
        });
        widget.model.inited = true;
        $analytics.stateTrack('init:widget');
        priv.initScopeListeners();
        /**
         * @description
         * Check to see if an initial state has been set on the widget directly (most likely by the PAGE)
         * If that is the case then try to handle it
         */
        if (widget.model.urlState && statesService.triggerExists(widget.model.urlState.hash)) {
            statesService.handleGoToState(widget.model.urlState.hash);
        } else {
            if (widgetContext.stateInit && widgetContext.stateInit.name !== '' && !widget.hasDeepLink) {
                $state.transitionTo(widgetContext.stateInit.name, {
                    stateObj: widgetContext.stateInit.stateObj
                }, {
                    location: false
                });
            }
        }

        self.handleGoBackClick = function() {
            self.handleClick(widgetContext.getHeaderSettings().leftButton);
        };

        /**
         * pass widgetContext.activeWidgetModuleStateObject instead of $state.params.stateObject
         * use the stateService to handle the state transfer
         */
        self.handleGoNextClick = function() {
            self.handleClick(widgetContext.getHeaderSettings().rightButton);
        };
        self.handleClick = function(button) {
            var exitFunc = button.exitFunction;
            if (exitFunc) {
                if (exitFunc.controller && typeof exitFunc.controller[exitFunc.function] === 'function') {
                    exitFunc.controller[exitFunc.function].apply(exitFunc.controller, exitFunc.params);
                } else {
                    console.error(exitFunc.function, 'is not a function');
                }
            } else {
                statesService.goToExitPath(button.exitPath, widgetContext.activeWidgetModuleStateObject);
            }
        };
        self.handleGoBackEvent = function() {
            if (statesService.handleGoBack('back') === false) {
                eventService.sendBackStateNotAvailable(widget, statesService.hideBackButton());
            }
        };
        self.context = widgetContext;
        /**
         * @ngdoc event
         * @name widget.widget.widget#widgetActivated
         * @eventOf widget.widget.widget:widget
         * @eventType broadcast
         * @description
         * Emits the event named <strong>widget.initialized</strong><br/>
         * Called when the widget directive controller is done.
         * Implement this function in the widget controller to return back control over the controller
         */
        eventService.sendWidgetActivated(widget);
        /**
         * @ngdoc event
         * @name widget.widget.widget#widgetContext.onWidgetLoaded
         * @eventOf widget.widget.widget:widget
         * @eventType emit
         * @description
         * Called internally when the widget directive controller is done.
         * Implement this function in the widget controller to return back control over the controller
         *
         * @example
         *<pre>
         * widgetContext.handleStateChange = function (fromState, toState, stateObject) {
         *       if (fromState == "entry" && toState == "transfer-money") {
         *       stateObject.fullname = stateObject.name;
         *       stateObject.bankCardNumber = stateObject.cardNumber;
         *    }
         *    return stateObject;
         *};
         *</pre>
         */
        if (typeof(widgetContext.onWidgetLoaded) === 'function' && !widget.hasDeepLink) {
            widgetContext.onWidgetLoaded();
        }
        self._private_ = priv;
    }
});
