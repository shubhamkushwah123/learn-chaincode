define('foundation/widget/event-manager', ['angular'], function (angular) {

    'use strict';

    angular.module('widget.eventManager', [])

    /**
     * @name eventService
     * @module widget.eventManager
     * @description
     * eventService is an interface between the widget and native javascript services
     */
        .provider('eventService', function () {

            this.$get = function ($interpolate, $timeout) {

                var constants = {
                    EXITSTATEEVENT: 'widget.exitState',
                    BACKSTATENOTAVAILABLE: 'widget.backStateNotAvailable',
                    WIDGETACTIVATED: 'widget.initialized',
                    STATECHANGED: 'widget.stateChanged',
                    SETTITLE: 'widget.setTitle'
                };

                var priv = {

                    /**
                     * @name getIntent
                     * @param {Object} toState Expects the ui-router state object for this state
                     * @param {Object} stateObject Internal stateObject
                     * @returns {string} url where the placeholders are resolved
                     */
                    getIntent: function (toState, stateObject) {
                        return $interpolate(toState)(stateObject);
                    },

                    getAttribute: function (widget, attributeName) {
                        return (widget.attributes[attributeName]) ?
                            (widget.attributes[attributeName]).nodeValue : '';
                    }
                };

                return {

                    /**
                     * @name sendExitStateEvent
                     * @param {Object} toState Expects the ui-router state object for this state
                     * @param {Object} stateObject Hold properties that can be mapped to the intent template that
                     * is mapped to the exitstateevent
                     * @param {Object} widget The internal BB widget object for this widget instance
                     */
                    sendExitStateEvent: function (toState, stateObject, widget) {
                        $timeout(function () {
                            jQuery(document).trigger(constants.EXITSTATEEVENT, {
                                widgetId: widget.id,
                                widgetTitle: priv.getAttribute(widget, 'title'),
                                widgetDescription: priv.getAttribute(widget, 'description'),
                                event: toState.eventName,
                                intent: widget.getPreference(toState.eventName),
                                stateObject: stateObject
                            });
                        }, 1);
                    },

                    /**
                     * @name sendBackStateNotAvailable
                     * @param {Object} widget The internal BB widget object for this widget instance
                     */
                    sendBackStateNotAvailable: function (widget, hide) {
                        $timeout(function () {
                            jQuery(document).trigger(constants.BACKSTATENOTAVAILABLE, {
                                widgetId: widget.id,
                                widgetTitle: priv.getAttribute(widget, 'title'),
                                widgetDescription: priv.getAttribute(widget, 'description'),
                                hideBackButton: hide
                            });
                        }, 1);
                    },

                    /**
                     * @name sendWidgetActivated
                     * @param {Object} widget The internal BB widget object for this widget instance
                     */
                    sendWidgetActivated: function (widget) {
                        $timeout(function () {
                            jQuery(document).trigger(constants.WIDGETACTIVATED, {
                                widgetId: widget.id,
                                widgetTitle: priv.getAttribute(widget, 'title'),
                                widgetDescription: priv.getAttribute(widget, 'description')
                            });
                        }, 1);
                    },

                    /**
                     * @name sendstateChanged
                     * @param {Object} widget The internal BB widget object for this widget instance
                     */
                    sendStateChanged: function (widget, toState) {
                        $timeout(function () {
                            jQuery(document).trigger(constants.STATECHANGED, {
                                widgetId: widget.id,
                                widgetTitle: priv.getAttribute(widget, 'title'),
                                widgetDescription: priv.getAttribute(widget, 'description'),
                                hideBackButton: toState.hideBackButton
                            });
                        }, 1);
                    },

                    /**
                     * @name sendSetTitle
                     * @param {Object} widget The internal BB widget object for this widget instance
                     * @param {String} title The title that must be set
                     */
                    sendSetTitle: function (widget, title) {
                        $timeout(function () {
                            jQuery(document).trigger(constants.SETTITLE, {
                                widgetId: widget.id,
                                widgetTitle: title
                            });
                        }, 1);
                    },

                    _private_: priv
                };
            };
        });
});