define('foundation/widget/cookie-decorator',
    ['angular',
    'angular-cookies'
    ],

    function (angular) {
        'use strict';
        angular
            .module('widget.cookie-decorator', ['ngCookies'])
            .config(cookieDecorator);

        function cookieDecorator($provide, $cookieStoreProvider) {
            $provide.decorator('$cookieStore', function($delegate, $injector){

                var cookies = $injector.get('$cookies');

                $delegate.getAsString = function(key){
                    return decodeURIComponent(cookies[key]);
                };
                
                $delegate.putAsString = function(key, value){
                    cookies[key] = encodeURIComponent(value);
                }
                
                return $delegate;
            });
        }
    });
