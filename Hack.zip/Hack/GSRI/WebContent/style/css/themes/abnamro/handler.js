/**
 * @description
 * This file is responsible for logging all the HTTP error messages.
 */
define("component/rest-response-handler/handler", ["angular", "component/rest-response-handler/processor"], function(angular, exceptionHandlerMessageProcessor) {
    angular.module("restResponseHandler", []).constant('restType', {
        bpm: 'bpm',
        mcs: 'mcs',
        other: 'other'
    }).service('exceptionHandlerMessageProcessor', ['restType', exceptionHandlerMessageProcessor]).factory('genericErrorHandler', genericErrorHandler);

    function genericErrorHandler($q, exceptionHandlerMessageProcessor, $rootScope) {
        return function(response, functions) {
            //create a promise
            var deferred = $q.defer();
            //check of we have an http error (this is the same range a ngResource uses)
            var isError = !(response.status >= 200 && response.status <= 299);
            //unify and process the response
            var response = exceptionHandlerMessageProcessor.handleResponse(response, isError);
            //determine if we reject or resolve this promise
            if (!response.handleAsError) {
                //create a copy of the data
                var data = angular.copy(response.data);
               // console.log(data)
                //go through the responseHandler functions and execute them
                if (functions) {
                    for (var i = 0, len = functions.length; i < len; i++) {
                        data = functions[i](data, response);
                    }
                }
              
                if (typeof data.status === 'undefined' && !(response.status >= 200 && response.status <= 299) ) {
                    var modifiedRes = {};
                    modifiedRes = data;
                    modifiedRes.status = response.status;
                    deferred.resolve(modifiedRes);
                } else {
                    deferred.resolve(data);
                }
            } else {
                if (response.messageKey.indexOf("UNKNOWN") > -1) {
                    $rootScope.$emit('aab-widget-resthandler-error', 'errorCodeTechnicalErrorTitle', 'errorCodeTechnicalError');
                } else {
                    $rootScope.$emit('aab-widget-resthandler-error', response.messageKey + "Title", response.messageKey);
                }
                deferred.reject(response);
            }
            return deferred.promise;
        };
    };
});