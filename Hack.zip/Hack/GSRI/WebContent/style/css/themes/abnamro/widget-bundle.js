/**
 * @description
 * widgetBundle - is bundle that combine shared components that each widget can/should use.
 * Such as widgetModule and widget directives, and orchestrator service.
 * The main goal of this file it's to keep all related components and dependencies in one place.
 */

define('foundation/widget/widget-bundle',
    [   'angular',
        'angular-resource',
        'angular-sanitize',
        'angular-cache',
        'angular-resource',
        'angular-cache',
        'foundation/widget/translation-manager',
        'foundation/widget/configuration-manager',
        'foundation/widget/analytics-manager',
        'foundation/widget/widget-module-directive',
        'foundation/widget/widget-directive',
        'foundation/widget/state-manager',
        'foundation/widget/event-manager',
        'foundation/widget/preferences-manager',
        'foundation/widget/widget-context',
        'foundation/widget/widget-module-context',
        'foundation/widget/widget-utils',
        'component/rest-response-handler/handler',
        'angular-translate',
        'angular-spinner',
        'angulartics',
        'foundation/widget/widget-analytics',
        'angular-bootstrap'

    ], function (angular) {
        'use strict';
            return angular.module('widget.bundle', [
                "ngResource",
                "ngSanitize",
                "angular-cache",
                'widget.translationManager',
                'widget.configurationManager',
                'widget.analyticsManager',
                "widget.widget",
                "widget.widgetModule",
                "widget.widgetContext",
                "widget.widgetModuleContext",
                "widget.stateManager",
                "widget.eventManager",
                "widget.widgetUtilities",
                "restResponseHandler",
                'pascalprecht.translate',
                'angularSpinner',
                'angulartics',
                'widget.analytics',
                'ui.bootstrap'
            ]);
    });
