define('foundation/widget/widget-constants',
    ['angular'],
    function(angular){
        'use strict';

        angular
            .module('widget.constants', [])
            .constant('WIDGET_TEMPLATE', {
                application: 'application',
                content: 'content',
                header: 'header'
            });
    }
);
