/**
 * @description
 * Creates a loading spinner that is shown after a submit. There should be a delay before showing the spinner.
 * This is a feedback to the user to let him know that the process is in progress and that it is taking some time.
 * If the process takes longer than 2 seconds, the user may be shown a second feedback.
 *
 * @author Arvind Pal
 */

define('component/ui/loading-spinner/loading-spinner', ['angular', 'angular-spinner'], function(angular) {
    'use strict';

    function loadingSpinnerActivator() {

        var loadingHandler = undefined;

        /**
         * @name addHandler
         * @methodOf ui.loadingSpinner.loadingSpinnerActivator:loadingSpinnerActivator
         * @ngdoc method
         * @description
         * Sets the handler to be called when showSpinner is called
         *
         * @param {function} the handler
         **/
        this.addHandler = function(handler) {
            loadingHandler = handler;
        };

        /**
         * @name removeHandler
         * @methodOf ui.loadingSpinner.loadingSpinnerActivator:loadingSpinnerActivator
         * @ngdoc method
         * @description
         * Removes the handler that is called when removeSpinner is called
         *
         * @param {function} the handler
         **/
        this.removeHandler = function() {
            loadingHandler = undefined;
        };

        /**
         * @name handleLoader
         * @methodOf ui.loadingSpinner.loadingSpinnerActivator:loadingSpinnerActivator
         * @ngdoc method
         * @description
         * Activates the handleLoader when it is set
         *
         * @param {object} options Json structure with {
         *   information: text to display,
         *   endAfterMiliseconds: time in milliseconds
         *   successIcon: boolean
         * }
         **/
        this.handleLoader = function(options) {
            if (loadingHandler && angular.isFunction(loadingHandler)) {
                loadingHandler(options);
            }
        };
    }

    function loadingSpinnerController($scope, usSpinnerService, $timeout, loadingSpinnerActivator) {

        var vm = this;

        //To make reusable spinner component providing unique key to spinner object
        vm.scopeId = $scope.$id;
        vm.spinnerKey = 'spinner-' + vm.scopeId;

        // configuration settings of spinner
        vm.opts = {
            // The number of lines to draw
            // The length of each line
            // The line thickness
            // The radius of the inner circle
            // #rgb or #rrggbb
            // Rounds per second
            // Afterglow percentage
            lines: 12,
            length: 6,
            width: 3,
            radius: 8,
            color: '#ccc',
            speed: 1.0,
            trail: 100,
            shadow: false,
            position: 'relative',
            top: '50%',
            left: '50%'

        };

        vm.initialize = function(options) {
            angular.extend(vm, {
                endAfterMilliseconds: options.endAfterMilliseconds,
                delayMilliseconds: options.delayMilliseconds
            });

            // Invoke activate funciton to start the loader
            if (vm.endAfterMilliseconds <= 0) {
                vm.deactivate();
            } else {
                vm.activate(options);
            }

        };

        // Function responsible for disabling the spinner
        vm.deactivate = function() {
            // Stops the Spinner
            usSpinnerService.stop(vm.spinnerKey);
        };

        // Function responsible for enabling the spinner with both initial delay and total time of the spinner
        vm.activate = function() {
            $timeout(function() {
                // Stars the Spinner
                usSpinnerService.spin(vm.spinnerKey);

            }, (vm.delayMilliseconds));

            $timeout(function() {
                vm.deactivate();
            }, (isNaN(vm.delayMilliseconds) ?
                vm.endAfterMilliseconds : vm.delayMilliseconds + vm.endAfterMilliseconds));

        };

        loadingSpinnerActivator.addHandler(vm.initialize);
    }

    /**
     * @name ui.loadingSpinner.aabSpinnerLoader:aabSpinnerLoader
     * @ngdoc directive
     * @module ui.loadingSpinner
     * @restrict EA
     *
     * @description
     * A directive to provide loading Spinner based on initialization
     *
     * @requires {$rootScope} $rootScope An angular application scope reference
     * @requires {$timeout} $timeout An angular timeout function reference
     * @param {number @} endAfterMiliseconds, specifies the time in milliseconds for UpdateLoader display.
     * @param {number @} delayMilliseconds, specifices the time in miliseconds

     * @example
    <pre>
    <aab-spinner-loader></aab-spinner-loader>
    </pre>
     */
    function aabSpinnerLoader() {

        var directive = {
            restrict: 'EA',
            replace: false,
            scope: {
                endAfterMilliseconds: '@',
                delayMilliseconds: '@'
            },
            templateUrl:
                'oca/app/components/ui/loading-spinner/loading-spinner.html',
            controller: loadingSpinnerController,
            controllerAs: 'vm'
        };

        return directive;

    }

    angular
        .module('ui.loadingSpinner', ['angularSpinner'])
         /**
         * @name ui.loadingSpinner.loadingSpinnerActivator:loadingSpinnerActivator
         * @ngdoc service
         * @module ui.loadingSpinner
         * @description
         * loadingSpinnerActivator is used to trigger a updateLoader message
         */
        .service('loadingSpinnerActivator', loadingSpinnerActivator)
        .directive('aabSpinnerLoader', aabSpinnerLoader)
        .controller('loadingSpinnerController', loadingSpinnerController);
});
