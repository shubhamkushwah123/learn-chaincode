/**
 * @description
 * This file is the bootstrapper of RequireJS and therefore of the entire frontend.
 * It should only act as a bootstrapper, any logic should be deferred to other files.
 */

var require = {

    /** project folder url */
    baseUrl: 'oca/',

    /** paths to libraries and components */
    paths: {
        'widget': 'app/widgets',
        'widget-module': 'app/widget-modules',
        'component': 'app/components',
        'foundation': 'app/foundation',
        'angular': 'vendor/angular',
        'uiRouter': 'vendor/angular-ui-router',
        'angular-translate': 'vendor/angular-translate',
        'angular-mocks': 'vendor/angular-mocks',
        'angular-bootstrap': 'vendor/ui-bootstrap-tpls',
        'mustache': 'vendor/mustache',
        'iso-e2e': 'vendor/iso-e2e',
        'angular-resource': 'vendor/angular-resource',
        'angular-sanitize': 'vendor/angular-sanitize',
        'angular-cache': 'vendor/angular-cache',
        'angular-toastr': 'vendor/angular-toastr',
        'angulartics': 'vendor/angulartics',
        'angulartics-debug':'vendor/angulartics-debug',
        'angulartics-adobe':'vendor/angulartics-adobe',
        'angular-dynamic-locale' : 'vendor/tmhDynamicLocale',
        'angular-spinner': 'vendor/angular-spinner',
        'spin': 'vendor/spin',
        'i18n' : 'vendor/ngLocale',
        'angular-cookies': 'vendor/angular-cookies',
        'angular-ui-mask': 'vendor/mask',
        'iban': 'vendor/iban'
    },
    shim: {
        'angular': {'exports': 'angular'},
        'uiRouter': {deps: ['angular'], 'exports': 'angular'},
        'angular-resource': {deps: ['angular'], 'exports': 'angular-resource'},
        'angular-cache': {deps: ['angular'], 'exports': 'angular-cache'},
        'angular-toastr': {deps: ['angular'], 'exports': 'angular-toastr'},
        'spin': { 'exports': 'spin' },
        'angular-spinner': {deps: ['angular', 'spin'], 'export': 'angular-spinner' },
        'angular-translate': { deps: ['angular'], 'exports': 'angular-translate' },
        'angular-sanitize': { deps: ['angular'], 'exports': 'angular-sanitize' },
        'angular-bootstrap': {deps: ['angular'], 'exports': 'angular-bootstrap'},
        'angular-dynamic-locale': {deps: ['angular'], 'exports': 'angular-dynamic-locale'},
        'iso-e2e': {'exports': 'mcf'},
        'angular-mocks': {deps: ['angular'], 'exports': 'angular.mock'},
        'exception-handler':{deps: ['angular'],'exports': 'exception-handler'},
        'angulartics':{deps: ['angular'],'exports': 'angulartics'},
        'angulartics-debug':{deps: ['angular', 'angulartics'],'exports': 'angulartics-debug'},
        'angulartics-adobe':{deps: ['angular', 'angulartics'],'exports': 'angulartics-adobe'},
        'angular-cookies': {deps: ['angular'], 'exports': 'angular-cookies'},
        'angular-ui-mask': {deps: ['angular'],'exports': 'mask'},
        'iban': {'exports': 'iban'}
    }
};