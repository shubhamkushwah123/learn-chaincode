define('foundation/widget/translation-manager', ['angular',
        'angular-dynamic-locale',
        'angular-translate',
        'foundation/widget/translation-manager-generic-messages',
        'foundation/widget/widget-utils'
    ],

    function (angular) {
        'use strict';

        angular.module('widget.translationManager',
            [   'tmh.dynamicLocale',
                'pascalprecht.translate',
                'widget.translationManager.genericMessages',
                'widget.widgetUtilities'])

            .config(function($translateProvider, tmhDynamicLocaleProvider, widgetUtilsProvider) {
                //add the custom interpolation provider
                $translateProvider.useInterpolation('stringFormatInterpolation');

                tmhDynamicLocaleProvider.localeLocationPattern(widgetUtilsProvider.fullPath('vendor/angular-locale_{{locale}}.js'));
            })

            .factory('translationCustomLoader', translateCustomLoaderFunc)
            .provider('translationManager', translationManager)
            .factory('stringFormatInterpolation', stringFormatInterpolation);
    });


/**
 * @ngDoc service
 * @name widget.translationManager.translationManager:translationManager
 * @descript_optision
 * This really is a wrapper around $translateProvider in order to make for easier and quicker language
 * configuration inside the widget
 */
function translationManager($translateProvider, widgetUtilsProvider, errorMessages, $windowProvider, tmhDynamicLocaleProvider) {

    'use strict';
    this.initTranslations = function (options, widgetModel) {

        //set some default in case the options we receive are empty or nonsense
        var defaults = {
            files: []
        };

        //merge the options with the defaults
        var _opts = angular.extend({}, defaults, options);

        //determine the language
        var lang = _opts.language || (location.search.split('language=')[1]);

        if (!lang) {
            lang = this.getConfiguredLanguage();
        }


        var defaultTranslationFolder = widgetUtilsProvider.getTranslationsFolder(widgetModel);

        //set the i18n  language
        tmhDynamicLocaleProvider.defaultLocale(lang);

        $translateProvider.useLoader('translationCustomLoader', {
            files : _opts.files,
            continueOnError: true,
            'en' : errorMessages.en,
            'nl': errorMessages.nl
        });

        /**
         * Add the default translations to the beginning of the array. That way they are processed first.
         * Any consecutive translation definitions will override the default ones
         */
        _opts.files.unshift({prefix: defaultTranslationFolder, suffix: '.json'});

        /**
         * Define the way the translation files are loaded. The static loader use the following pattern:
         *  /path/to/files/{LANGUAGE}.json
         * In this case: /path/to/files/ is the prefix .json is the suffix. {LANGUAGE} is the desired language
         * So the translation are found at /path/to/files/nl.json and /path/to/files/en.json
         */
        $translateProvider.useLoader('translationCustomLoader', {
            files: _opts.files,
            continueOnError: true,
            'en': errorMessages.en,
            'nl': errorMessages.nl
        });

        // Clean out certain html tags / attributes
        $translateProvider.useSanitizeValueStrategy('sanitize');

        $translateProvider.preferredLanguage(lang);
    };

    this.getConfiguredLanguage = function () {

        var $window = $windowProvider.$get();

        if ($window.AAB && $window.AAB.portal && $window.AAB.portal.locale) {
            return $window.AAB.portal.locale;
        }

        if ($window.AAB && $window.AAB.config && $window.AAB.config.tcm && $window.AAB.config.tcm.locale) {
            return $window.AAB.config.tcm.locale;
        }

        return 'nl';
    };

    /**
     * @name $get method
     * @description
     *
     * @returns {void} use
     */
    this.$get = function ($translate) {
        return {
            /**
             *
             * @param language, takes a language (en, nl, es) and tries to load the language bundle for it
             */
            use: function (language) {
                $translate.use(language);
            }
        };
    };

    /**
     * @name setName
     * @description
     * Sets name to widgetContext.
     *
     * @param {String}  name widgetContext name
     */
    this.setName = function (name) {
        this.name = name;
    };
}


/**
 * @ngDoc service
 * @name widget.translationManager.translationCustomLoader:translationCustomLoader
 * @description
 * Provides a custom loader for translation files. It is based on the staticFiles loaders. This load provides the option
 * to force to resolve a http promise even if it the http call return a 404.
 *
 * The service expects an options object, whit at least one 1 bundle location specified. A location is specified by
 * giving a prefix and a suffix. Based on the prefix, the suffix, and of course the specified language, an http call
 * will be done to retrieve the requested bundle.
 *
 * EG:
 *
 * var getTranslationBundle = {
 *     files: [{
 *         prefix: '/',
 *         suffix: '/widgetcontent/ib2/savings/oc-savings/savings.json'
 *     }],
 *     'key': 'nl'
 * };
 *
 * translateCustomLoaderFunc(getTranslationBundle)
 */
function translateCustomLoaderFunc($q, $http) {

    'use strict';

    return function (options) {

        /**
         * Check if the options object is set with a files array that has at least one bundle location specified by a
         * prefix and a suffix. Also make sure that a key is given within the options object. This key stands for the
         * language bundle that needs to be retrieved. If not, throw an error.
         */
        if (!options
            || (!angular.isArray(options.files) || options.files.length == 0)
            || (!options.files[0].prefix || !options.files[0].suffix)
        ) {

            throw new Error('Couldn\'t load static files, no files array with at least one object containing a prefix and suffix is specified!');
        }

        /**
         * Get a requested translation bundle through http GET call
         *
         * @param file
         * @returns {*}
         */
        var getTranslationFile = function getTranslationFile(file) {

            /**
             * Make sure that the file object given has a prefix and a suffix in order to build op de requested url for
             * the translation bundle.
             */
            if (!file || (!angular.isString(file.prefix) || !angular.isString(file.suffix) || !angular.isString(file.key))) {
                throw new Error('Couldn\'t load static file, no prefix, suffix, or key specified!');
            }

            var deferred = $q.defer();

            // Define the location of the translation bundle
            var url = file.prefix + file.key + file.suffix;

            // Define the http GET request for retrieving the translation bundle
            var conf = angular.extend({
                url: url,
                method: 'GET',
                params: ''
            }, options.$http);

            /**
             * Perform the get call. When something goes wrong, reject the deferred so that the translateCustomLoader
             * knows something went wrong
             */
            $http(conf).success(function (data) {

                // The bundle has been retrieved successful, resolve the promise and return the data
                deferred.resolve(data);

            }).error(function (err) {

                // Check whether to continue on error or not, it could be expected that a bundle can't be found
                if (options.continueOnError) {
                        deferred.resolve({});
                    } else {
                        deferred.reject(file.key);
                    }
                });

            return deferred.promise;
        };

        var deferred = $q.defer(),
            promises = [];

        // Iterate over all the files given to the translate custom loader and retrieve them by performing a http GET
        for (var i = 0; i < options.files.length; i++) {

            // Store all the returned promises in order to continue when all the files are retrieved
            promises.push(getTranslationFile({
                prefix: options.files[i].prefix,
                key: options.key,
                suffix: options.files[i].suffix
            }));
        }

        /**
         * When all the files are requested, and a response has been received, check whether all the calls succeeded or
         * not.
         */
        $q.all(promises).then(function (data) {

            var mergedData = options[options.key] || {};

            for (var i = 0; i < data.length; i++) {
                for (var key in data[i]) {
                    mergedData[key] = data[i][key];
                }
            }
            deferred.resolve(mergedData);
        }, function (data) {
            deferred.reject(data);
        });

        return deferred.promise;
    };
}


/**
 * @ngDoc service
 * @name widget.translationManager.$translateDefaultInterpolation:$translateDefaultInterpolation
 * @description
 * This service provides a formatting option comparable to C#'s string.format
 *
 * TODO better description - what about the parameters? what does it return?
 * why are the $interpolate and the $translateSanitization parameters?
 */
function stringFormatInterpolation($interpolate, $translateSanitization) {

    'use strict';

    var $translateInterpolator = {},
        $locale,
        $identifier = 'stringFormatInterpolation';

    /**
     * @description
     * Sets current locale (this is currently not use in this interpolation).
     * @param {string} locale Language key or locale.
     */
    $translateInterpolator.setLocale = function (locale) {
        $locale = locale;
    };

    /**
     * @description
     * Returns an identifier for this interpolation service.
     *
     * @returns {string} $identifier
     */
    $translateInterpolator.getInterpolationIdentifier = function () {
        return $identifier;
    };

    /**
     * @deprecated will be removed in 3.0
     * @see {@link pascalprecht.translate.$translateSanitization}
     */
    $translateInterpolator.useSanitizeValueStrategy = function (value) {
        $translateSanitization.useStrategy(value);
        return this;
    };

    /**
     * @ngdoc function
     * @name widget.translationManager.stringFormatInterpolation:stringFormatInterpolation
     *
     * @description
     * Interpolates given string agains given interpolate params using angulars
     * `$interpolate` service.
     *
     * @returns {string} interpolated string.
     */
    $translateInterpolator.interpolate = function (string, interpolationParams) {

        interpolationParams = interpolationParams || {};

        interpolationParams = $translateSanitization.sanitize(interpolationParams, 'params');

        var args = Array.prototype.slice.call(interpolationParams);

        // TODO - What does this do/is it needed for?
        var interpolatedText = string.replace(/{(\d+)}/g, function (match, number) {

            return args[number] || match;
        });

        interpolatedText = $interpolate(interpolatedText)(interpolationParams);
        interpolatedText = $translateSanitization.sanitize(interpolatedText, 'text');

        return interpolatedText;
    };

    return $translateInterpolator;
}


stringFormatInterpolation.displayName = 'stringFormatInterpolation';


