define('component/ui/numeric-input/numeric-input', ['angular', 'component/device/device-detector'], function(angular) {
    'use strict';

    angular.module('ui.numericInput', ['deviceDetection'])
        /**
         * @ngdoc directive
         * @name ui.numericInput:aabNumericInput
         * @restrict EA
         * @requires $timeout
         * @requires $parse
         * @param {scope/context variable} ng-model Input value is binded to this
         * @param {Number=} limit defines maximum number of characters allowed into Input
         * @param {Number} tabindex defines taxindex for Input field
         * @param {scope/context variable =} active-status If this attribute is defined then component attaches
         * focus/blur events to input field and updates given scope/context variable
         * @description
         * Creates a Input box of numeric type which accepts only numeric input and
         * Escapes Alphabets and special characters
         */
        .directive('aabNumericInput', ['$timeout', '$parse', 'deviceDetector', function($timeout, $parse, deviceDetector) {
            return {
                restrict: 'EA',
                require: '^ngModel',
                scope: {
                    align: '@',
                    activeStatus: '=',
                    verified: '='
                },
                templateUrl: 'oca/app/components/ui/numeric-input/numeric-input.html',
                replace: true,
                link: function(scope, element, attrs, ngModel) {

                    // Finding  input element within component
                    var inputElem = element[0],
                        isElementFocused = false,
                        isElementTextSelected = false,
                        status = '',
                        eventData = {},
                        mask = '';
                    // Checking if element have length limit defined.
                    // If not giving default length limit
                    var limit = (Number(attrs.limit) + '') !== 'NaN' ? Number(attrs.limit) : 1000;
                    var minLength = (Number(attrs.minlength) + '') !== 'NaN' ? Number(attrs.minlength) : 0;

                    //Check elment have mask attribute and android version less than 4.4 with android browser
                    if (attrs.mask !== undefined && !(parseFloat(deviceDetector.getAndroidVersion()) < 4.4) && !(deviceDetector.checkAndroidNativeBrowser())) {
                        mask = attrs.mask;
                    }
                    if (attrs.mask !== undefined) {
                        limit = (attrs.mask).length;
                        //Set the mask limit based on mask attribute length
                        if (parseFloat(deviceDetector.getAndroidVersion()) < 4.4 && deviceDetector.checkAndroidNativeBrowser()) {
                            limit = ((attrs.mask).replace(/ /g, '')).length;
                        }
                    }
                    inputElem.setAttribute('type', 'tel');

                    // check if the input element should be auto focused and focus it.
                    if (attrs.hasOwnProperty('autoFocus')) {
                        status = '';
                        isElementFocused = true;
                        $timeout(function() {
                            inputElem.focus();
                        }, 0, false);
                        if (attrs.activeStatus) {
                            status = $parse(attrs.activeStatus);
                            status.assign(scope, true);
                            scope.activeStatus = true;
                        }
                    }

                    // Assigning tab-index to directive input field
                    // Removing tab-index from directive initializer
                    if (attrs.tabindex) {
                        inputElem.setAttribute('tabindex', attrs.tabindex);
                        element[0].setAttribute('tabindex', '');
                    }
                    // Watching for changes in model value
                    scope.$watch(
                        function() {
                            return ngModel.$modelValue;
                        },
                        function(newValue) {

                            var regExp;
                            if (!isElementFocused && newValue !== '' && newValue + '' !== 'undefined') {
                                ngModel.$setValidity('inputDataModified', true);
                            }
                            
                            if(angular.isDefined(attrs.verified)){
                                ngModel.$setValidity('verified', true); // if verified is set, then default valid
                                if(angular.isDefined(scope.verified)){
                                    ngModel.$setValidity('verified', scope.verified ? true : false);
                                    scope.verified = undefined; //skip this error next time until it is set again
                                }
                            }
                            
                            if (mask.length > 0) {
                                regExp = /^0[0-9 ].*$/;
                            } else {
                                regExp = /^0[0-9].*$/;
                            }
                            if (attrs.type === 'number' && regExp.test(ngModel.$viewValue)) {
                                inputElem = element[0];
                                newValue = inputElem.value;
                            }

                            updateViewValue(newValue);
                        }, true);

                    /**
                     * @ngdoc method
                     * @name updateModelValue
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Updates ng-model value
                     * @param {Number} value Value of Input
                     */
                    function updateModelValue(value) {

                        if (mask.length > 0 && value !== '' && value !== undefined) {
                            ngModel.$setViewValue(value.replace(/ /g, ''));
                        } else {
                            ngModel.$setViewValue(value);
                        }

                        if (value === undefined) {

                        }
                    }


                    /**
                     * @ngdoc method
                     * @name stopPropagation
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * If pressed key is Backspace/Enter/Tab/arrows/Delete/non
                     * numeric/exceeding the limit then returns false else returns true
                     * @param {Number} key keyCode of input key
                     * @param {Object} event keyDown event object
                     * @param {Boolean} isDigitInput Specifies entered key is numeric or not
                     *
                     * @returns {Boolean} returns condition result
                     */
                    function stopPropagation(key, event, isDigitInput) {
                        var validity1 = key !== 8 && key !== 13 && key !== 9,
                            validity2 = key !== 37 && key !== 46 && key !== 39,
                            digitAndCtrlValidity = !event.ctrlKey && ((!isDigitInput || (inputElem.value + '').length >= limit)),
                            textSelectionValidity = !isElementTextSelected;
                        return validity1 && validity2 && digitAndCtrlValidity && textSelectionValidity;
                    }

                    /**
                     * @ngdoc method
                     * @name listenToPasteEvent
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Bind method for Paste event on input
                     * If pasted data is more then specified limit then trims the data and updates to model
                     */
                    function listenToPasteEvent() {
                        $timeout(function() {
                            var stringValue = (inputElem.value + '');
                            // Resetting the visible input data
                            inputElem.value = stringValue;
                            // Verifying processed input length
                            // If length is more then limit and trim it to length and update view too
                            if (stringValue.length > limit) {
                                var modifiedInput = stringValue.substring(0, limit);
                                inputElem.value = modifiedInput;
                                updateModelValue(modifiedInput);
                            } else {
                                updateModelValue(inputElem.value);
                            }
                        }, 100);
                    }

                    /**
                     * @ngdoc method
                     * @name listenToSelectEvent
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Bind method for select event on input
                     * If value entered is selected then we are setting boolean value to identify the selection.
                     */
                    function listenToSelectEvent() {
                        $timeout(function() {
                            isElementTextSelected = true;
                        }, 100);
                    }

                    /**
                     * @ngdoc method
                     * @name updateEventdata
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Provides support to unit testing as soft triggered event have two event objects
                     * checks second array object and updates event object with provided data
                     * @param {Object} event Triggered event data
                     * @param {Array} args List of event arguments passed to called function
                     *
                     * @returns {Object} event returns updated Event
                     */
                    function updateEventdata(event, args) {
                        if (args.length > 1) {
                            if (args[1].keyCode) {
                                event.keyCode = args[1].keyCode;
                            }
                            if (args[1].which) {
                                event.which = args[1].which;
                            }
                            if (args[1].shiftKey) {
                                event.shiftKey = args[1].shiftKey;
                            }
                            if (args[1].type) {
                                event.type = args[1].type;
                            }
                        }
                        return event;
                    }


                    /**
                     * @ngdoc method
                     * @name listenToFocusBlurEvent
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Bind method for focus and blur event on input
                     * Updates provided parent scope/context variable to "true" if focused, "false" on blur
                     * @param {Object} event Event object of focus/blur event
                     */
                    function listenToFocusBlurEvent(event) {
                        status = '';
                        event = updateEventdata(event, arguments);

                        if (event.type === 'blur') {
                            if ((inputElem.value + '').length < minLength) {
                                ngModel.$setValidity('minLength', false);
                            } else {
                                ngModel.$setValidity('minLength', true);
                            }
                        }

                        $timeout(function() {
                            if (attrs.activeStatus) {
                                status = $parse(attrs.activeStatus);
                                if (event.type === 'blur') {
                                    status.assign(scope, false);
                                    scope.activeStatus = false;
                                } else {
                                    status.assign(scope, true);
                                    scope.activeStatus = true;
                                }
                            }
                            if (event.type === 'focus') {
                                isElementFocused = true;
                            }
                            // If Valid Data is entered into input the updating data modified validate
                            if (inputElem.value && (inputElem.value + '').length && event.type === 'blur') {
                                ngModel.$setValidity('inputDataModified', true);
                            }


                        }, 100);
                    }

                    /**
                     * @ngdoc method
                     * @name listenToKeyDownEvent
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Bind method for keydown event on input
                     * Reads keyCode from event and if pressed is numeric and new value length is in given limit then updates the model
                     * @param {Object} event Event object of keydown event
                     */
                    function listenToKeyDownEvent(event) {
                        event = updateEventdata(event, arguments);
                        eventData = event;
                        // Reading pressed key-code and verifying if pressed key is numeric or not
                        var key = event.keyCode ? event.keyCode : event.which,
                            enterKeyVal = (key >= 48 && key <= 57) || (key >= 96 && key <= 105),
                            isDigitInput = enterKeyVal && !event.shiftKey;
                        // Preventing event from propagating.
                        if (stopPropagation(key, event, isDigitInput)) {
                            event.preventDefault();
                            return false;
                        }

                        isElementTextSelected = false;
                        // Updating model value after main stack execution completion
                        $timeout(function() {
                            if ((inputElem.value + '').length <= limit) {
                                updateModelValue(inputElem.value);
                            }
                        }, 100);
                    }


                    /**
                     * @ngdoc method
                     * @name maskSpace
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Insert mask value in the string
                     * @param {String} str Value of input as string
                     * @param {Number} index Position/index of the string to insert space in the string
                     * @param {String} value Value(Space/Any String) to be inserted.
                     */
                    function maskSpace(str, index, value) {
                        return str.substr(0, index) + value + str.substr(index);
                    }

                    /**
                     * @ngdoc method
                     * @name maskSpace
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * Apply masking for the entered string
                     * @param {value} str Value of input as string
                     */
                    function updateMaskValue(value) {
                        var indices = [],
                            i,
                            concatString = '',
                            stringValue = '';
                        stringValue = value + '';
                        for (i = 1; i <= mask.length; i++) {
                            if (mask[i] === ' ') {
                                indices.push(i);
                            }
                        }

                        if (indices.indexOf(value.length) > -1 && eventData.keyCode !== 8) {
                            inputElem.value = value + ' ';
                        }

                        for (i = 0; i < stringValue.length; i++) {
                            if (stringValue[i] !== ' ') {
                                concatString += stringValue[i];
                            }
                        }
                        for (i = 0; i < indices.length; i++) {
                            if (concatString.length > indices[i] && concatString[indices[i]] !== ' ') {
                                concatString = maskSpace(concatString, indices[i], ' ');
                                stringValue = concatString;
                                inputElem.value = concatString;
                            } else {
                                inputElem.value = concatString;
                            }
                        }

                        $timeout(function() {
                            inputElem.selectionStart = inputElem.selectionEnd = inputElem.value.length;
                        }, 10);
                    }

                    // If user entered date in non-numeric then clear the input field
                    // If user entered data is more then specified limit in length the trim it to given limit
                    angular.element(inputElem).bind('paste', listenToPasteEvent);

                    // Listening to select event
                    angular.element(inputElem).bind('select', listenToSelectEvent);

                    // Listening to key press events
                    angular.element(inputElem).bind('keydown', listenToKeyDownEvent);

                    // Listening on mousewheel scroll
                    angular.element(inputElem).bind('mousewheel.disableScroll', function(e) {
                        e.preventDefault();
                    });

                    // Listening for Blur/Focus event to update directive scope value
                    angular.element(inputElem).bind('blur focus', listenToFocusBlurEvent);

                    /**
                     * @ngdoc method
                     * @name updateViewValue
                     * @methodOf ui.numericInput:aabNumericInput
                     * @description
                     * When model value is changed applies new value to input in view
                     * @param {Number} value New value provided in model
                     */
                    function updateViewValue(value) {
                        var regex,
                            stringValue;
                        if (mask.length > 0) {
                            regex = new RegExp('^[0-9 ]+$', '');
                        } else {
                            regex = new RegExp('^[0-9]+$', '');
                        }
                        if (regex.test(value)) {
                            stringValue = value + '';
                            if (stringValue.length > limit) {
                                var modifiedInput = stringValue.substring(0, limit);
                                inputElem.value = modifiedInput;
                                updateModelValue(modifiedInput);
                            } else {
                                if (mask.length > 0) {
                                    updateMaskValue(value);
                                } else {
                                    inputElem.value = value;
                                }
                            }
                        } else {
                            stringValue = value + '';
                            if (value) {
                                if (stringValue.length > 0 && value !== '' && value !== undefined) {
                                    if (mask.length > 0) {
                                        stringValue = stringValue.replace(/[^0-9 ]+/g, '');
                                    } else {
                                        stringValue = stringValue.replace(/[^0-9]+/g, '');
                                    }
                                    updateModelValue(stringValue);
                                    inputElem.value = stringValue;
                                } else {
                                    updateModelValue(undefined);
                                    inputElem.value = '';
                                }
                            }
                        }
                    }
                }
            };
        }]);
});
