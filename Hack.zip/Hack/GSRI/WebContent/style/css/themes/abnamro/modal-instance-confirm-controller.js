define('component/ui/modal/modal-instance-confirm-controller', ['angular'], function(angular) {

    angular
        .module('service.modalInstanceConfirm', ['ui.bootstrap'])
        .controller('modalInstanceConfirmController', ['$scope', '$modalInstance', 'content', modalInstanceConfirmController]);

    // Controller responsible for the logic inside the modal template - content can be passed for example in the form of a JSON file from Tridion/ Backbase
    function modalInstanceConfirmController($scope, $modalInstance, content) {

        $scope.title = content.title;
        $scope.text = content.text;

        $scope.ok = function() {
            $modalInstance.close();
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

    }

});
