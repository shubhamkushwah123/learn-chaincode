define('component/ui/step-counter/step-counter', ['angular'], function(angular) {

    function stepCounterController($scope, $state, $rootScope) {
        $rootScope.$on("$stateChangeSuccess", function(event, toState) {
            $scope.currentState = toState.name;
        });

        $scope.currentState = $state.current.name;
    };

            function aabStepCounter() {
                var directive = {
                    restrict: 'EA',
                    require: 'aabWidgetDirective',
                    templateUrl: 'oca/app/components/ui/step-counter/step-counter.html',
                    scope: {
                        steps: '='
                    },
                    controller: stepCounterController
                  };
                  return directive;
    };

                stepCounterController.$inject = ['$scope', '$state', '$rootScope'];

    angular.module('uiComponent.stepCounter', ['pascalprecht.translate', 'widget.stateManager'])

        /**
         * @ngdoc directive
         * @module uiComponent.stepCounter
         * @name uiComponent.stepCounter.aabStepCounter:aabStepCounter
         * @description
         * Creates an horizontal list displaying the active state name
         * @restrict EA
         * @scope
         **/
        .directive('aabStepCounter', aabStepCounter)
        .controller('stepCounterController', stepCounterController);
});
