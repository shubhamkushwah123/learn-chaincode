define('component/ui/pin5/pin5', ['angular', 'component/device/device-detector'], function(angular) {

    'use strict';

    /**
     * @ngdoc method
     * @name checkAndroidVersionAndNativeBrowser
     * @methodOf ui.pin5:aabPin5Input
     * @description
     * This function is used to check android version and native browser.
     * @param {Object} deviceDetector object
     *
     * @returns {Boolean} returns conditional result
     */
    function checkAndroidVersionAndNativeBrowser(deviceDetector) {
        return parseFloat(deviceDetector.getAndroidVersion()) < 4.4 && deviceDetector.checkAndroidNativeBrowser();
    }

    /**
     * @ngdoc method
     * @name getTemplateUrl
     * @methodOf ui.pin5:aabPin5Input
     * @description
     * This function is used to switch the template url based on android version and native browser.
     * If android version greater than 4.4 then we will apply custom design for pin5 field.
     * @param {Object} deviceDetector object
     *
     * @returns {String} returns template url
     */

    function getTemplateUrl(deviceDetector) {
        if (checkAndroidVersionAndNativeBrowser(deviceDetector)) {
            return 'oca/app/components/ui/pin5/pin5-default.html';
        } else {
            return 'oca/app/components/ui/pin5/pin5.html';
        }
    }

    /**
     * @ngdoc method
     * @name pinController
     * @methodOf ui.pin5:aabPin5Input
     * @description
     * This function is controller for pin5.
     * @param {Object} $scope object
     * @param {Object} deviceDetector object
     *
     */

    function pinController($scope, deviceDetector) {
        var i,
            vm = this,
            resetPinState = -1;
        if (!checkAndroidVersionAndNativeBrowser(deviceDetector)) {
            $scope.ngModel = '';

            vm.boxes = [{
                state: false
            }, {
                state: false
            }, {
                state: false
            }, {
                state: false
            }, {
                state: false
            }];


            // start of watch function

            $scope.$watch(function() {
                return $scope.ngModel;
            }, function(newValue, oldValue) {
                var pinLength = $scope.ngModel ? $scope.ngModel.length : 0;
                if (pinLength > 0) {
                    vm.pinStateDefault = false;
                } else if (pinLength === 0 && oldValue !== '') {
                    vm.pinStateDefault = true;
                }
                var ticked = pinLength;
                vm.pinstate = pinLength - 1;
                resetPinState = vm.pinstate;
                for (i = 0; i < vm.boxes.length; i++) {
                    if (i < ticked) {
                        vm.boxes[i].state = true;
                    } else {
                        vm.boxes[i].state = false;
                    }
                }

            });
            // end of watch function
        }

        /**
         * @ngdoc method
         * @name addDefaultClass
         * @methodOf ui.pin5:aabPin5Input
         * @description
         * This function is used to set boolean value to apply styling on focus.
         *
         */
        vm.addDefaultClass = function() {
            if ($scope.ngModel === '') {
                //pinStateDefault is used to show cursor for the first time and when no data
                vm.pinStateDefault = true;
            } else {
                // This condition is used to reset the position of the cursor
                vm.pinstate = resetPinState;
            }
            vm.pinDefault = true;
        };

         /**
         * @ngdoc method
         * @name addDefaultClass
         * @methodOf ui.pin5:aabPin5Input
         * @description
         * This function is used to set boolean value to remove styling on blur.
         *
         */
        vm.removeDefaultClass = function() {
            vm.pinStateDefault = false;
            vm.pinstate = -1;
            vm.pinDefault = false;
        };

        /**
         * @ngdoc method
         * @name hasReadonly
         * @methodOf ui.pin5:aabPin5Input
         * @description
         * Does the inputfield need a readonly attribute? The readonly field is used to work around browsers that
         * try to remember your password
         */
        vm.hasReadonly = function() {
            // We don't want chrome to remember passwords, therefore we enable the readonly trick
            return deviceDetector.isChrome();
        };
    }

    angular.module('ui.pin5', ['deviceDetection'])
        /**
         * @ngdoc directive
         * @name ui.pin5:aabPin5Input
         * @restrict E
         * @requires $timeout
         * @requires $parse
         * @param {scope/context variable} ng-model Input value is binded to this
         * @param {Number} tabindex defines taxindex for Input field
         * @param {scope/context variable =} active-status If this attribute is defined then component attaches
         * focus/blur events to input field and updates given scope/context variable
         * @description
         * Creates a Input box of numeric type which accepts only numeric input and
         * Escapes Alphabets and special characters
         */
        .directive('aabPin5Input', ['$timeout', '$parse', 'deviceDetector', function($timeout, $parse, deviceDetector) {
            //getTemplateUrl will receive template url for corresponding device or desktop.
            var templateUrl = getTemplateUrl(deviceDetector);
            return {
                restrict: 'E',
                replace: true,
                require: 'ngModel',
                scope: {
                    ngModel: '='
                },
                templateUrl: templateUrl,
                controller: pinController,
                controllerAs: 'vm',
                link: function(scope, element, attrs, ngModel) {

                    // Finding  input element within component
                    var inputElem = element[0].querySelectorAll('input')[0],
                        isElementFocused = false;

                    // Stop content paste to input element
                    angular.element(inputElem).bind('copy paste', function(event) {
                        event.preventDefault();
                    });

                    // Assigning tab-index to directive input field
                    // Removing tab-index from directive initializer
                    if (attrs.tabindex) {
                        inputElem.setAttribute('tabindex', attrs.tabindex);
                        inputElem.setAttribute('tabindex', '');
                    }

                    if (attrs.disabled) {
                        inputElem.setAttribute('disabled', 'disabled');
                    }
                    scope.ocfPinStatus = 'ocf-pin-default';
                    // Watching for changes in model value

                    scope.$watch(attrs['ngModel'],
                        function(newValue) {
                            if (!isElementFocused && newValue !== '' && newValue + '' !== 'undefined') {
                                ngModel.$setValidity('inputDataModified', true);
                            }
                            updateViewValue(newValue);
                        });

                    // Listening for Blur/Focus event to update directive scope value
                    angular.element(inputElem).bind('blur focus', listenToFocusBlurEvent);

                    // Listening to key press events
                    angular.element(inputElem).bind('keydown', listenToKeyDownEvent);

                    /**
                     * @ngdoc method
                     * @name listenToFocusBlurEvent
                     * @methodOf ui.pin5:aabPin5Input
                     * @description
                     * Bind method for focus and blur event on input
                     * Updates provided parent scope/context variable to "true" if focused, "false" on blur
                     * @param {Object} event Event object of focus/blur event
                     */
                    function listenToFocusBlurEvent(event) {
                        event = updateEventdata(event, arguments);
                        // This trick is added to disable autofill on password fields.
                        if (angular.element(inputElem).attr('readonly')) {
                            angular.element(inputElem).removeAttr('readonly');
                        }

                        $timeout(function() {
                            if (attrs.activeStatus) {
                                var status = $parse(attrs.activeStatus);
                                if (event.type === 'blur') {
                                    status.assign(scope, false);
                                } else {
                                    status.assign(scope, true);
                                }
                            }

                            if (!checkAndroidVersionAndNativeBrowser(deviceDetector)) {
                                if (event.type === 'focus') {
                                    isElementFocused = true;
                                    var viewportmeta = document.querySelector('meta[name="viewport"]');
                                    if (viewportmeta) {
                                        viewportmeta.content = 'width=device-width, initial-scale=1, user-scalable=no';
                                    }
                                } else if (event.type === 'blur') {
                                    var viewportmeta = document.querySelector('meta[name="viewport"]');
                                    if (viewportmeta) {
                                        viewportmeta.content = 'width=device-width, initial-scale=1';
                                    }
                                }
                            }

                            // If Valid Data is entered into input the updating data modified validate
                            if (inputElem.value && (inputElem.value + '').length && event.type === 'blur') {
                                ngModel.$setValidity('inputDataModified', true);
                            }
                        }, 100);
                    }

                    /**
                     * @ngdoc method
                     * @name listenToKeyDownEvent
                     * @methodOf ui.pin5:aabPin5Input
                     * @description
                     * Bind method for keydown event on input
                     * Reads keyCode from event and if pressed is numeric and new value length is in given limit then
                     * updates the model
                     * @param {Object} event Event object of keydown event
                     */
                    function listenToKeyDownEvent(event) {
                        event = updateEventdata(event, arguments);
                        var key = event.keyCode ? event.keyCode : event.which,
                            enterKeyVal = (key >= 48 && key <= 57) || (key >= 96 && key <= 105),
                            isDigitInput = enterKeyVal && !event.shiftKey;

                        if (stopPropagation(key, event, isDigitInput)) {
                            event.preventDefault();
                            return false;
                        }

                        $timeout(function() {
                            updateModelValue(inputElem.value);
                        }, 100);
                    }

                    /**
                     * @ngdoc method
                     * @name stopPropagation
                     * @methodOf ui.pin5:aabPin5Input
                     * @description
                     * If pressed key is Backspace/Enter/Tab/arrows/Delete/non numeric/exceeding the limit then returns
                     * false else returns true
                     * @param {Number} key keyCode of input key
                     * @param {Object} event keyDown event object
                     * @param {Boolean} isDigitInput Specifies entered key is numeric or not
                     *
                     * @returns {Boolean} returns condition result
                     */
                    function stopPropagation(key, event, isDigitInput) {
                        var validity1 = key !== 8 && key !== 13 && key !== 9,
                            validity2 = key !== 37 && key !== 46 && key !== 39;
                        return validity1 && validity2 && !isDigitInput;
                    }

                    /**
                     * @ngdoc method
                     * @name updateEventdata
                     * @methodOf ui.pin5:aabPin5Input
                     * @description
                     * Provides support to unit testing as soft triggered event have two event objects
                     * checks second array object and updates event object with provided data
                     * @param {Object} event Triggered event data
                     * @param {Array} args List of event arguments passed to called function
                     *
                     * @returns {Object} event returns updated Event
                     */
                    function updateEventdata(event, args) {
                        if (args.length > 1) {
                            if (args[1].keyCode) {
                                event.keyCode = args[1].keyCode;
                            }
                            if (args[1].which) {
                                event.which = args[1].which;
                            }
                            if (args[1].shiftKey) {
                                event.shiftKey = args[1].shiftKey;
                            }
                            if (args[1].type) {
                                event.type = args[1].type;
                            }
                        }
                        return event;
                    }

                    /**
                     * @ngdoc method
                     * @name updateViewValue
                     * @methodOf ui.pin5:aabPin5Input
                     * @description
                     * Updates ng-model value
                     * @param {Number} value New value provided in model
                     */
                    function updateModelValue(value) {
                        ngModel.$setViewValue(value);
                    }

                    /**
                     * @ngdoc method
                     * @name updateViewValue
                     * @methodOf ui.pin5:aabPin5Input
                     * @description
                     * When model value is changed applies new value to input in view
                     * @param {Number} value New value provided in model
                     */
                    function updateViewValue(value) {
                        var regex = new RegExp('^[0-9]+$', ''),
                            limit = 5;
                        if (regex.test(value)) {
                            var stringValue = value + '';
                            if (stringValue.length > limit) {
                                var modifiedInput = stringValue.substring(0, limit);
                                inputElem.value = modifiedInput;
                                updateModelValue(modifiedInput);
                            } else {
                                inputElem.value = value;
                            }
                        } else {
                            inputElem.value = '';
                        }
                    }
                }
            };
        }]);
});
