define('component/ui/accordion/accordion', ['angular'], function() {
    'use strict';

    angular
        .module('ui.accordion', [])
        .directive('aabAccordionLoader', aabAccordionLoader);

    /**

     * @ngdoc directive
     * @module ui.accordion
     * @name ui.accordion.aabAccordionLoader:aabAccordionLoader
     * @restrict EA
     *
     * @description
     * A directive to provide accordion component that allow only one header to be folded out at a time

     * @example
     <pre>
        <aab-accordion-loader></aab-accordion-loader>
        </pre>
     */
    function aabAccordionLoader() {

       return {

            restrict: 'EA',
            replace: false,
            templateUrl: 'oca/app/components/ui/accordion/accordion.html'

        };

    }

});
