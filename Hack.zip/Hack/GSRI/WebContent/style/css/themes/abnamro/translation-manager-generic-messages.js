define('foundation/widget/translation-manager-generic-messages', ["angular"], function (angular) {

    angular
        .module('widget.translationManager.genericMessages', [])
        .constant('errorMessages', {
            'en': {
                errorCodeTechnicalError: 'An unknown error has occurred. Please try again later.',
                errorCodeTechnicalErrorTitle: '',
                'Button-Next': 'next',
                'Button-Back': 'back',
                'Button-Cancel': 'cancel',
                'Radio-No': 'no',
                'Radio-Yes': 'yes'
            },
            'nl': {
                errorCodeTechnicalError: 'Er is een onbekende fout opgetreden. Probeer het aub later nog een keer.',
                errorCodeTechnicalErrorTitle: '',
                'Button-Next': 'volgende',
                'Button-Back': 'terug',
                'Button-Cancel': 'annuleren',
                'Radio-No': 'nee',
                'Radio-Yes': 'ja'
            }
        });
});
