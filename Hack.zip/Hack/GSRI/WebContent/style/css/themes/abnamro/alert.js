define('component/ui/alert/alert', ['angular', 'component/filters/trusted-html/trusted-html'], function(angular) {
    'use strict';

    angular
        .module('ui.alert', ['filter.trustedHtml'])
        .directive('aabAlert', aabAlert);

    /**
     * @ngdoc directive
     * @name ui.alert:aabAlert
     * @restrict EA
     * @scope
     * @description
     * Creates an alert box on the screen, with an optional title and the error message.<br>
     * Options are to show the alert-icon or not, effectively making it a warning message.<br>
     * Both kinds can have button(s) with text, CSS-class and action defined via options.<br>
     *
     *@param {object} error This is the error object used to control the alert message. This is 'watched'.<br>
     *
     * @example
     *
     * <pre>
     * error={
     *    title: 'the title', // will be filtered with "translate" and "aabTrustedHtml"
     *    text: 'the error text', // will be filtered with "translate" and "aabTrustedHtml"
     *    options: {
     *       info: true, // will hide error icon, and will make the alert appear as a warning
     *       button:[
     *          text:'the text for the button', // will be filtered with "translate"
     *          styles:'btn-secondary', // that will be applied on the button, default: 'btn-primary'
     *          action: function(){} //the function to execute when user clicks on button
     *       ]
     *    }
     * }
     *</pre>
     */
    function aabAlert() {

        function link(scope) {
            // if object is provided convert that into array
            // backward compatible with all existing widgets
            if (scope.error && scope.error.options && scope.error.options.button) {
                scope.error.options.button = !angular.isArray(scope.error.options.button) ? [scope.error.options.button] : scope.error.options.button;
            }

            scope.onHandleClick = function(index) {
                scope.error.options.button[index].action();
            };
        }

        var directive = {
            restrict: 'EA',
            scope: {
                error: '='
            },
            templateUrl: 'oca/app/components/ui/alert/alert.html',
            link: link
        };

        return directive;
    }
});
