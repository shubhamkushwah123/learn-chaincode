/**
 * This widget provides the interface between Angulartics and the analytics providers.
 */
define('foundation/widget/widget-analytics',
    [
        'angular',
        'angulartics',
        'foundation/widget/widget-context',
        'foundation/widget/widget-utils',
        'component/analytics/adobe-analytics'
    ],
    function (angular) {

        'use strict';

        function bridgeProvider($analyticsProvider) {

            //Don't track ui.router events
            $analyticsProvider.virtualPageviews(false);

            var self = this;

            this.domainModel = {};
            self.buffering = true;
            self.buffer = [];

            this.domainQuery = function (query) {
                return self.$interpolate(query)(self.domainModel);
            };

            this.eventCallbacks = {};

            this.registerEvent = function (name, callback) {
                self.eventCallbacks[name] = self.eventCallbacks[name] || [];
                self.eventCallbacks[name].push(callback);
            };

            this.eventRouter = function (name) {
                if (self.buffering) {
                    self.buffer.push(name);
                } else {
                    var fns = this.eventCallbacks[name] || [];
                    var i = 0;
                    for (; i < fns.length; i++) {
                        if (typeof fns[i] === 'function') {
                            fns[i]();
                        }
                    }
                }
            };

            this.uiEventHandler = function (name, data) {
                angular.extend(self.domainModel, data);
                self.eventRouter(name);
            };

            this.stateEventHandler = this.uiEventHandler;

            $analyticsProvider.registerEventTrack(this.uiEventHandler);
            $analyticsProvider.registerPageTrack(this.stateEventHandler);

            //Super constructor pattern
            this.setFiringRules = function (analyticsVendorService, analyticsConfiguration) {

                //Some analytics vendors have specific data needed for reporting
                // Instead of gathering this at reporting they find it easier
                //  to have it as part of the tag plan
                angular.extend(self.domainModel, analyticsConfiguration.widget
                    && analyticsConfiguration.widget.data || {});

                return function setFiringRule(rule, name) {

                    // Each of the event names have a specific firing rule
                    // e.g.  name = init:state
                    //       rule = tagPlan --> key,value ; eventPlan --> key, string Array

                    // This API call registeres the event to a specific API call
                    self.registerEvent(name, function () {


                        var state = self.domainQuery('{{state}}');
                        var tagPlanWidgetModule = analyticsConfiguration.widgetModules
                            && analyticsConfiguration.widgetModules[state] || false;

                        // Some analytics providers need to resolve large amounts of custom data
                        // linked to a state
                        // we load that data on demand...
                        if (tagPlanWidgetModule) {
                            angular.extend(self.domainModel, tagPlanWidgetModule.data);
                        }

                        // A tag plan configuration consists out of two parts
                        // A tag plan (i.e. which values needs to be mapped to which keys)
                        var tagPlan = analyticsConfiguration.widget && analyticsConfiguration.widget.tagPlans
                            && analyticsConfiguration.widget.tagPlans[rule.tagPlan] || {};

                        // and an event plan, as in which events need to be triggered on what rule
                        var eventPlan = analyticsConfiguration.widget && analyticsConfiguration.widget.eventPlans
                            && analyticsConfiguration.widget.eventPlans[rule.eventPlan] || {};

                        // for each key in the tagplan we add the tracking
                        // the key is fixed the value of it is passed through the
                        // $interpolator method (wrapped insied the domainQuery method) which can resolve the right
                        // values for a key.
                        angular.forEach(tagPlan, function (value, key) {

                            // Meta keys start with __ this allows us to fire only when required.
                            if (key.substring(0, 2) === '__') {
                                return false;
                            }

                            analyticsVendorService.addTracking(key, self.domainQuery(value));
                        });

                        // We only fire a tracking pixel if explicitly asked by the tagplan ...
                        // other pixel firing rules are part of the adaptor
                        if (tagPlan.__fire) {
                            analyticsVendorService.firePixel();
                        }

                        // event plans are always mapped to a state,
                        // this means that if you add a click event, you need to configure it to belong to a state
                        angular.forEach(eventPlan[state], function (value) {
                            analyticsVendorService.fireEvent(value);
                        });

                    });
                };
            };

            /**
             * @description An analytics configuration can have multiple vendor keys
             *              Each of the vendor keys can be linked to an analytics vendor, if it exists
             *
             * @param analyticsConfiguration
             * @param analyticsVendorServiceName
             */
            this.resolveAnalytics = function (analyticsConfiguration, analyticsVendorServiceName) {
                var analyticsVendorService;
                var analyticsInjector;
                try {
                    analyticsInjector = angular.injector([analyticsVendorServiceName]);
                } catch (e) {
                    console.warn('Configured analytics vendor (' + analyticsVendorServiceName + ') does not exist');
                }
                if (analyticsInjector && analyticsInjector.has(analyticsVendorServiceName)) {
                    analyticsVendorService = analyticsInjector.get(analyticsVendorServiceName);

                    // Widget configuration should have firing rules...
                    // For each of the viring ruels they run the tag plan
                    angular.forEach(analyticsConfiguration.widget.firingRules,
                        self.setFiringRules(analyticsVendorService, analyticsConfiguration));
                }
            };

            this.flushBuffer = function () {
                self.buffering = false;

                for (var i = self.buffer.length - 1; i >= 0; i--) {
                    self.eventRouter(self.buffer[i]);
                };

                self.buffer = [];
            };


            this.$get = function ($interpolate, widgetUtils, configurationManager, widgetContext, widgetModel) {

                self.$interpolate = $interpolate;

                if (angular.isObject(widgetContext.analytics) && angular.isObject(widgetContext.analytics.files)) {
                    // Locations to tridion configuration might have been added
                    var defaults = {
                        files: [],
                        defaultLocation: widgetUtils.getAnalyticsConfigPath(widgetModel)
                    };
                    var _opts = angular.extend({}, defaults, widgetContext.analytics);
                    // Load config
                    configurationManager.initConfigurations(_opts)
                        .then(function(data) {
                            angular.forEach(data, self.resolveAnalytics);
                            self.flushBuffer();
                        }, function() {
                            // Loading failed.
                            self.flushBuffer();
                        });
                } else {
                    // Old scenario where configuration was directly added in widgets
                    angular.forEach(widgetContext.analytics, self.resolveAnalytics);
                    self.flushBuffer();
                }

                return this;
            };
        }

        angular.module('widget.analytics', ['angulartics', 'widget.widgetContext'])
            .provider('bridge', bridgeProvider);

    });
