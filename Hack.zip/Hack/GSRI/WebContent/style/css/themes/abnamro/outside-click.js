define('component/ui/outside-click/outside-click', ["angular"], function (angular) {

 angular
    .module('outsideClick', [])

  // Custom onBlur function for elements which don't have a focus or blur state
    // For instance: i-Text
    .directive('aabOutsideClick', ['$document', '$parse', function($document, $parse) {

        // Callback will determine which function to call on blur
        // TriggerId will exclude the click outside of the element (similar to e.preventDefault)

        //USAGE example
        //<div collapse="collapse" aab-outside-click aab-outside-click-trigger-id="enableTooltip1" aab-outside-click-callback="hideTooltip()"> TEST </div>
        //
        // <button type="button" id="enableTooltip1" ng-click="toggleTooltip()" />

        return {
            link: function($scope, $element, $attributes) {
                onClick = function(event) {
                    var isChild = $element.find(event.target).length > 0;
                    var callback = $attributes.aabOutsideClickCallback;
                    var triggerId = $attributes.aabOutsideClickTriggerId;
                    var elementId = event.target.id;

                    if (!isChild && !(elementId === triggerId)) {
                        $scope.$apply(callback);
                    }
                };

                $document.on('click', onClick);

                $element.on('$destroy', function() {
                    $document.off('click', onClick);
                });
            }
        };
    }]);
});
