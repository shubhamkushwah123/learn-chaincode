define('foundation/widget/widget-module-context', ['angular'], function() {

    'use strict';
    //was 'service.widgetOrchestrator'
    angular
        .module('widget.widgetModuleContext', [])

        /**
         * @ngdoc service
         * @name widget.widgetModuleContext.widgetModuleContext:widgetModuleContext
         * @description
         * widgetModuleContext is state and helper service for the widget module directive. It is cleared when the widget-module-directive object is detroyed
         * The widgetModuleContext communicates with the widget context to exchange information with the widget directive
         **/
        .provider('widgetModuleContext', function(widgetContextProvider) {

            var self = this;

            this.metaData = {};
            this.priv = {};
            this.name = 'widgetModuleContext';

            /**
             * @ngdoc method
             * @methodOf widget.widgetModuleContext.widgetModuleContext:widgetModuleContext
             * @name reportError
             * @description Emits a report error to the widget directive
             * See {@link ui.aabAlert:aabAlert aabAlert} 
             * @param {object} $scope Pass the scope to the WidgetContext
             * @param {string} Title the title of the error/warning, will be translated
             * @param {string} Text the text of the error/warning, will be translated
             * @param {boolean} isRecoverable set the error/warning is recoverable, if set to true, the content of the widget is still visible and the user can interact with it
             * @param {boolean} isWarning set to a warning or an error, if set to true (so it's a warning) you get the UI for a warning
             * @param {array} buttons the buttons, see aab-alert for more info
           
             */
            self.reportError = function($scope, title, text, isRecoverable, isWarning, buttons){
            	//errorTitle, errorText, isRecoverable, isWarning, buttons
                $scope.$emit('aab-widget-handle-error', title, text, isRecoverable, isWarning, buttons);
            };
            
            /**
             * @ngdoc method
             * @methodOf widget.widgetModuleContext.widgetModuleContext:widgetModuleContext
             * @name clearError
             * @description Emits a reset error to the widget directive, effectively resetting the alert message.
             * @param {object} $scope Pass the scope to the WidgetContext
             */
            self.clearError = function($scope){
                $scope.$emit('aab-widget-reset-error');
            };


            this.$get = function(widgetContext) {

                // add changeHeaderSettings here to make sure it is not cleared
                var doNotClear = [
                    'priv',
                    'clear',
                    'reportError',
                    'clearError',
                    'changeHeaderSettings',
                    'setWidgetModuleStateObject',
                    'resetHeaderSettings'];

                return {
                    stateConfig: [],
                    metaData: self.metaData,
                    reportError: self.reportError,
                    clearError: self.clearError,
                    clear: function() {

                        widgetContext.clearWidgetModuleStateObject();
                        widgetContext.resetHeaderSettings();

                        for (var prop in this) {
                            if (doNotClear.indexOf(prop) === -1) {
                                this[prop] = undefined;
                            }
                        }
                    },

                    /**
                    * @ngdoc method
                    * @methodOf widget.widgetModuleContext.widgetModuleContext:widgetModuleContext
                    * @name changeHeaderSettings
                    * @description 
                    * Allows the programmatic changing of the widget header from the widget module. 
                    * <strong>IMPORTANT</strong>: when changing the settings from the widget module, you should first consider if that can be done by defining the modified header settings in the metadata section of the widget module.
                    * @param {json} headerSettings A json object that specifies the new values
                    * @example
                    <pre>
                    {
                        leftButton = {
                    //the translation key for the text of the button
                            text: 'Button-Back',

                    //show or hide the button
                            show: false,
                            
                    //exitPath with a state or substate OR a function inside the controller of the current widget module
                            exitPath: 'back', OR
                            exitFunction: {
                                function: 'cancel',
                                controller: this,
                                params : ['cancelled']
                            },
                            class: 'btn btn-default ocf-btn-back'
                        },
                    //the translation key for the text of the button
                        rightButton = {
                    //the translation key for the text of the button
                            text: 'Button-Cancel',

                    //show or hide the button
                            show: false,

                    //exitPath with a state or substate OR a function inside the controller of the current widget module
                            exitPath: 'next', OR
                            exitFunction: {
                                function: 'cancel',
                                controller: this, 
                                params : ['cancelled']
                            },
                            
                            class: 'btn btn-default ocf-btn-cancel'
                         },
                         general = {
                    //sets the literal value of the title
                            title : '',
                    //provides a translation key to the title so it can be displayed in multiple languages
                            titleKey: 'widget-title'
                         }
                    }
                    </pre>
                    **/

                    changeHeaderSettings: function(changedSettings) {
                        widgetContext.changeHeaderSettings(changedSettings);
                    },

                    setWidgetModuleStateObject: function(stateObject) {
                        widgetContext.setWidgetModuleStateObject(stateObject);
                    }
                };
            };

            /**
             * @name setName
             * @description
             * Sets name to widgetModuleContext.
             *
             * @param {String}  name widgetModuleContext name
             */
            this.setName = function(name) {
                this.name = name;
            };
        });
});
