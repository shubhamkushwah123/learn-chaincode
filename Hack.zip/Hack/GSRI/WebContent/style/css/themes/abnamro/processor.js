
define('component/rest-response-handler/processor', ["angular"],


    function () {

        return function exceptionHandlerMessageProcessor(restType) {

            var restType = restType;

            /*
             * @ngdoc method
             * @name unifyErrorResponse
             * @description return a unified response based on an error response
             */
            var handleResponse = function (response, isError) {
                return priv.handleResponseAndResponseError(response, isError);
            };

            var priv = {

                handleResponseAndResponseError: function (response, isError) {

                    var unifiedResponse = undefined;

                    if (!response.config.errorHandlerConfiguration) {
                        console.error("REST consumer does not contain errorHandlerConfiguration block!!", response.config.url);
                        return response;
                    }

                    var type = priv.determineRestType(response);
                    switch (type) {
                        case restType.bpm:
                            unifiedResponse = priv.getUnifiedBpmResponse(response);
                            break;
                        case restType.mcs:
                            unifiedResponse = priv.getUnifiedMscResponse(response);
                            break;
                        default:
                            unifiedResponse = priv.getDefaultUnifiedResponse(response);
                            break;
                    }

                    unifiedResponse.handleAsError = isError;
                    unifiedResponse.config = response.config;
                    if (unifiedResponse.handleAsError) {
                        unifiedResponse = priv.determineExemtptions(unifiedResponse);
                        if(unifiedResponse.handleAsError){
                            return unifiedResponse;
                        }
                    }

                    //TODO: replace the hardcoded errorKeys with status keys from the response body if they are defined
                    //TODO: send along a flag to indicate id the error is recoverable
                    
                    return unifiedResponse;
                },

                /*
                * @ngdoc method
                * @name determineErrorFromValidResponse
                * @description determines if the error status is valid (status 200) but that is has a 
                *
                */
                determineErrorFromValidResponse: function (unifiedResponse) {
                    return unifiedResponse;
                },
                

               /*
               * @ngdoc method
               * @name determineExemtptions
               * @description determines the type of REST call we are dealing with based in the response
               * TODO: add statusKey to exemption properties
               */
                determineExemtptions: function (unifiedResponse) {
                    
                      if (unifiedResponse.config.errorHandlerConfiguration.exemptions) {
                        for (var i = 0; i < unifiedResponse.config.errorHandlerConfiguration.exemptions.length; i++) {
                            var exemption = unifiedResponse.config.errorHandlerConfiguration.exemptions[i];
                            //var exemptionMessageKey = exemption.messageKey.replace(/^\s+|\s+$/g,"");
                           if (exemption.status === unifiedResponse.status && unifiedResponse.messageKey && exemption.messageKey.indexOf(unifiedResponse.messageKey)> -1) {
                                unifiedResponse.handleAsError = false;
                                return unifiedResponse;
                            }else if(exemption.messageKey === ''&& unifiedResponse.status && exemption.status === unifiedResponse.status){
                                unifiedResponse.handleAsError = false;
                                return unifiedResponse;
                            }else if (exemption.status === '' && unifiedResponse.messageKey && exemption.messageKey.indexOf(unifiedResponse.messageKey)> -1) {
                                 unifiedResponse.handleAsError = false;
                                 return unifiedResponse;
                            }
                        }
                    }
                    return unifiedResponse;
                },


                /*
                 * @ngdoc method
                 * @name determineRestType
                 * @description determines the type of REST call we are dealing with based in the response
                 *
                 */
                determineRestType : function (response) {
                    if (response.data.messages) { //either BPM or MCS
                        if (response.data.messages.hasOwnProperty('message')) {
                            return restType.bpm;
                        } else {
                            return restType.mcs;
                        }
                    } else {
                        return restType.other;
                    }
                },

                /*
                 * 
                 */
                getUnifiedBpmResponse: function (response) {
                    var message = response.data.messages.message[0];

                    return priv.getUnifiedResponse(
                        response.status, 
                        message.messageKey,
                        message.messageType,
                        response.data);
                },


                /*
                 * 
                 */
                getUnifiedMscResponse: function (response) {
                    var message = response.data.messages[0];

                    return priv.getUnifiedResponse(
                        response.status,
                        message.messageKey,
                        message.messageType,
                        response.data);

                },

                /*
                 * 
                 */
                getDefaultUnifiedResponse: function (response) {
                    return priv.getUnifiedResponse(response.status, 'UNKNOWN', 'UNKNOWN', response.data);
                },

                /*
                 * 
                 */
                getUnifiedResponse: function (status, messageKey, messageType, data) {
                    return {
                        status: status,
                        messageKey: messageKey,
                        messageType: messageType,
                        data: data,
                        handleAsError: false
                    }
                }

            }


            return {
                handleResponse: handleResponse,
                __private__ : priv
            };


        };

});