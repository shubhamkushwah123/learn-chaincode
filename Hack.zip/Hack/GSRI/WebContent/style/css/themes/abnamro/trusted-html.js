define('component/filters/trusted-html/trusted-html', ['angular'], function (angular) {
    'use strict';
    angular
        .module('filter.trustedHtml', [])
        .filter('aabTrustedHtml', aabTrustedHtml);

    /**
     * @ngdoc filter
     * @name filter.aabTrustedHtml:aabTrustedHtml
     * @required $sce $sce provides Strict Contextual Escaping service
     * @param {string} text to be trusted
     * @description
     * It is used to tell Angular to trust the HTML we send, to be safe.
     * @returns {string} text as 'real' HTML to be interpreted by the browser.
     */
    function aabTrustedHtml($sce) {
        return function(text) {
            return $sce.trustAsHtml(text);
        };
    }
});
