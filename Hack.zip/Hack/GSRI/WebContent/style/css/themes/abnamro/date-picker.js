/**
 * @description
 * Displays datepicker based on device detection.
 * If it is mobile user will see HTML5 input type date and
 * it will invoke native date picker in mobile.
 * If it is desktop, user will see Angular UI Datepicker.
 * @author Karthik Devaraj
 */
define('component/ui/date-picker/date-picker', ['angular', 'component/device/device-detector'],
    function(angular) {
        'use strict';

        //This function will return template for device or desktop.
        function getTemplateUrl(isMobile) {
            if (isMobile) {
                return 'oca/app/components/ui/date-picker/device-date-picker.html';
            } else {
                return 'oca/app/components/ui/date-picker/desktop-date-picker.html';
            }
        }


        /**
         * @name ui.datePicker.DatePickerController:datePickerController
         * @ngdoc service
         * @module ui.datePicker
         * @description Controller for the aab-date-picker
         * @requires $scope

         */

        //DatePicker Controller is used invoke or set scope value for the view.
        function datePickerController() {

            var vm = this,
                ngModelCtrl = {
                    $setViewValue: angular.noop
                };

            if (!vm.isMobile) {
                vm.open = function($event) {
                    $event.preventDefault();
                    $event.stopPropagation();

                    vm.opened = (vm.opened) ? false : true;
                };
                vm.opened = false;
            }

        }

        /**
         * @ngdoc directive
         * @module ui.datePicker
         * @name ui.datePicker.aabDatePicker:aabDatePicker
         * @description
         * Creates an elements HTML5 type date picker for mobile and type "text" for desktop browser.
         * @restrict EA
         * @example
         <pre>
         <div data-aab-date-picker data-options="options"></div>
         </pre>
         */

        function aabDatePicker(deviceDetector) {
            //The isMobile function is to fetch fetch the device detection.
            //It will true for mobile and false for desktop
            var isMobile = deviceDetector.isMobile();
            //getTemplateUrl will receive template url for corresponding device or desktop.
            var templateUrl = getTemplateUrl(isMobile);
            var datePickerDirective = {
                restrict: 'EA',
                require: ['aabDatePicker', '?^ngModel'],
                scope: {
                    options: '=',
                    disabled: '=',
                    ngModel: '='
                },
                templateUrl: templateUrl,
                controller: datePickerController,
                controllerAs: 'vm',
                replace: true,
                link: function(scope, element, attrs, ctrls) {

                    var datePickerController = ctrls[0],
                        ngModelCtrl = ctrls[1];

                    element.find('input').on('blur', function(){

                        if (!ngModelCtrl) {
                            return;
                        }

                        var selectedDate = new Date(ngModelCtrl.$modelValue).setHours(0, 0, 0, 0);
                        var value = element.find('input').val();

                        // if viewvalue does not return a valid date
                        ngModelCtrl.$setValidity('undefined', angular.isUndefined(ngModelCtrl.$viewValue) ? false : true);

                        // if value does not comply with regex
                        if(!isMobile) {
                            ngModelCtrl.$setValidity('regex', scope.options.regex.test(value));
                        }

                        // if maxdate is set
                        if(scope.options.maxDate) {
                            ngModelCtrl.$setValidity('isMaxDateValid', selectedDate > scope.options.maxDate ? false : true);
                        }

                        // if mindate is set
                        if(scope.options.minDate) {
                            ngModelCtrl.$setValidity('isMinDateValid', selectedDate < scope.options.minDate ? false : true);
                        }

                        // apply the changes in ngModel so that element.$valid is updated
                        scope.$apply();

                    });
                }
            };
            return datePickerDirective;
        }

        angular.module('ui.datePicker', ['deviceDetection'])

        .directive('aabDatePicker', aabDatePicker)
            .controller('DatePickerController', datePickerController);
    });