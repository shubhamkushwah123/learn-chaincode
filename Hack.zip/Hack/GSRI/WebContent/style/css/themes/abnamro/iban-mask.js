/**
 * @description
 * Displays iban mask field.
 */
define('component/ui/mask/iban-mask/iban-mask', ['angular', 'iban', 'component/device/device-detector'],
    function(angular, iban) {
        'use strict';


        function ibanMask($timeout, $parse, deviceDetector) {
            var iBanMaskDirective = {
                replace: true,
                require: '^ngModel',
                restrict: 'EA',
                scope: {
                    disabled: '='
                },
                templateUrl: 'oca/app/components/ui/mask/iban-mask/iban-mask.html',

                link: function(scope, element, attrs, ngModel) {

                    var value = element.val();

                    angular.element(element).bind('keyup', listenToKeyUpEvent);
                    /**
                     * @ngdoc method
                     * @name listenToKeyUpEvent
                     * @methodOf ui.ibanMask:ibanMask
                     * @description
                     * Keyup event handler.
                     * @param {value} value of Input
                     */
                    function listenToKeyUpEvent(event) {
                        value = element.val();
                        if (parseFloat(deviceDetector.getAndroidVersion()) <= 4.4 && deviceDetector.checkAndroidNativeBrowser()) {
                            value = iban.electronicFormat(value);
                        }
                        else {
                            value = iban.printFormat(value);
                        }
                        element.val(value);
                    }

                    var isValidIban, parseIban;
                     /**
                     * @ngdoc method
                     * @name parseIban
                     * @methodOf ui.ibanMask:ibanMask
                     * @description
                     * Parse iban converts the value to uppercase and remove space
                     * @param {value} value of Input
                     */
                    parseIban = function(value) {
                        if (value != null) {
                            return value.toUpperCase().replace(/\s/g, '');
                        } else {
                            return void 0;
                        }
                    };
                     /**
                     * @ngdoc method
                     * @name isValidIban
                     * @methodOf ui.ibanMask:ibanMask
                     * @description
                     * Checks valid iban format.
                     * @param {value} value of Input
                     */
                    isValidIban = function(value) {
                        var ibanValue;
                        if (!(attrs.required || value)) {
                            return true;
                        }
                        ibanValue = parseIban(value);
                        return iban.isValid(ibanValue);
                    };
                    ngModel.$parsers.unshift(function(viewValue) {
                        var parsed, valid;
                        if (viewValue != null) {
                            valid = isValidIban(viewValue);
                            ngModel.$setValidity('iban', valid);
                            if (valid) {
                                parsed = parseIban(viewValue);
                                if (parsed !== viewValue) {
                                    ngModel.$setViewValue(parsed);
                                    ngModel.$render();
                                }
                                return parsed;
                            } else {
                                return void 0;
                            }
                        }
                    });
                }
            };
            return iBanMaskDirective;
        }

        angular.module('ui.ibanMask', ['deviceDetection'])

        /**
         * @ngdoc directive
         * @module ui.ibanMask
         * @name ui.ibanMask.ibanMask:ibanMask
         * @description
         * Creates an iban mask field.
         * @restrict EA
         * @scope
         **/
        .directive('ibanMask', ibanMask);
    });
