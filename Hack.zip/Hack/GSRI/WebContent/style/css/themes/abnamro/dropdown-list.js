/**
 * @description
 * Creates an tiles for  list items
 */
define('component/ui/dropdown-list/dropdown-list', ['angular', 'component/data-access/logos/logo-resource', 'component/ui/outside-click/outside-click'], function(angular) {
    angular
        .module('ui.dropDownList', ['service.logoResource', 'outsideClick'])
        .directive('aabDropDownList', aabaccountslistDropdown)
        .controller('dropDownListController', dropDownListController);

    function aabaccountslistDropdown() {
        var directive = {
            restrict: 'EA',
            require: '?^ngModel',
            templateUrl: 'oca/app/components/ui/dropdown-list/dropdown-list.html',
            scope: {
                items: '=',
                ngModel: '='
            },
            controller: dropDownListController,
            controllerAs: 'vm',
            link: function($scope, element, attr, ngModelCtrl) {
                if ($scope.items.length > 1) {
                    element.find('[ng-attr-data-ng-click]').attr('data-ng-click', '');
                }

                if (ngModelCtrl) {
                    $scope.$watch(function() {


                        ngModelCtrl.$setValidity('selectedAccount', angular.equals('Savings-KiesEenRekening', $scope.selectedName) ? false : true);

                        if (angular.isUndefined($scope.ngModel)) {

                            //if ngModel has no values, then set default values
                            switch ($scope.items.length) {
                                case 0:
                                    // handled in template where this directive is used
                                    break;
                                case 1:
                                    $scope.selectedBalance = $scope.items[0].currentBalance;
                                    $scope.selectedName = $scope.items[0].accountHolderName;
                                    $scope.externalName = $scope.items[0].externalName;
                                    $scope.selectedIBAN = $scope.items[0].ibanNumber;

                                    $scope.ngModel = $scope.items[0]; // attach item to ngModel to make it available in controllers

                                    break;
                                default:
                                    $scope.selectedName = 'Savings-KiesEenRekening';
                            }


                        } else {
                            $scope.selectedBalance = $scope.ngModel.currentBalance;
                            $scope.selectedName = $scope.ngModel.accountHolderName;
                            $scope.externalName = $scope.ngModel.externalName;
                            $scope.selectedIBAN = $scope.ngModel.ibanNumber;
                        }


                    });
                }
            }
        };

        return directive;
    }

    /**
     * @ngdoc controller
     * @module ui.dropDownList
     * @name ui.dropDownList.dropDownListController:dropDownListController
     * @description
     * This ui component  will display accountlist
     *
     * @requires $scope
     * @requires logoResource 
     *
     **/

    dropDownListController.$inject = ['$scope', 'logoResource'];

    function dropDownListController($scope, logoResource) {
        /* jshint validthis:true */

        //only get the logo's that are defined by the user to save calls
        logoResource.getLogoList().then(function(data) {
            if (data.hasOwnProperty('logoList')) {
                if (data.logoList.logos.length) {
                    angular.forEach(data.logoList.logos, function(logoList) {
                        angular.forEach($scope.items, function(item) {
                            if (logoList.id === item.ibanNumber && logoList.userDefined === true) {
                                item.logoListUserId = item.ibanNumber;
                            }
                        });
                    });
                }
            }
        });

        var vm = this;
        vm.showAccountsList = false;
        $scope.toggleList = false;
        $scope.timestamp = (new Date()).getTime();

        vm.toggleDropdown = function(event) {

            if (event === 'hide') {
                $scope.toggleList = false;
                return;
            }

            if (!$scope.toggleList) {
                $scope.toggleList = true;
            } else {
                $scope.toggleList = false;
            }

        };

        vm.updateValues = function(data) {
            $scope.selectedBalance = data.currentBalance;
            $scope.selectedName = data.accountHolderName;
            $scope.externalName = data.externalName;
            $scope.selectedIBAN = data.ibanNumber;
            $scope.ngModel = data;
            vm.toggleDropdown();
        };

    }
});
