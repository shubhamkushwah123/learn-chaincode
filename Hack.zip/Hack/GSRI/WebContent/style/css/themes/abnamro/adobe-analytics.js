/**
 * This widget provides the interface between Angulartics and the analytics providers.
 */
define('component/analytics/adobe-analytics',
    ['angular'],
    function(angular) {

        'use strict';

        function adobeAnalyticsService($window) {

            if (angular.isUndefined($window.s)) {

                if (angular.isUndefined($window.s_gi)) {
                    console.warn('adobe-analytics missing - we are not using Adobe Analytics for analytics');

                } else {

                    var suite = ($window.location.href.indexOf('www.abnamro.nl') !== -1) ?
                        'abnamronl' : 'abnamronl-et';
                    var s = $window.s_gi(suite);

                    /* You may add or alter any code config here. */
                    /* Link Tracking Config */
                    s.trackDownloadLinks = true;
                    s.trackExternalLinks = true;
                    s.trackInlineStats = true;
                    s.linkDownloadFileTypes = 'exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx';
                    //optional: add your internal domain here
                    s.linkInternalFilters = 'javascript:';
                    s.linkLeaveQueryString = false;
                    s.linkTrackVars = 'None';
                    s.linkTrackEvents = 'None';

                    s.usePlugins = true;

                    var s_doPlugins = function(s) {

                    };

                    s.doPlugins = s_doPlugins;

                    /* WARNING: Changing any of the below variables will cause drastic
                     changes to how your visitor data is collected.  Changes should only be
                     made when instructed to do so by your account manager.*/
                    s.trackingServer = 'abnamro.d2.sc.omtrdc.net';
                    s.trackingServerSecure = 'abnamro.d2.sc.omtrdc.net';
                    s.visitorNamespace = 'abnamro';

                    $window.s = s;
                }
            }

            this.fireEvent = function(eventName) {
                /**
                 * Ocassionally on cheap Android devices
                 * calling the tl interface causes an exception.
                 * This exception kills the JavaScript callstack breaking the journey.
                 * Therefore, this is in a try/catch statement.
                 */
                try {
                    $window.s && $window.s.tl(this, 'o', eventName);
                } catch (e) {
                    console.log(e);
                }
            };

            this.addTracking = function(key, value) {
                if ($window.s) {
                    $window.s[key] = value;
                }
            };

            this.firePixel = function() {
                //Send tracking pixel
                try {
                    $window.s && $window.s.t();
                } catch (e) {
                    console.log(e);
                }
            };
        }

        angular.module('adobeAnalytics', ['widget.widgetUtilities'])
            .service('adobeAnalytics', ['$window', adobeAnalyticsService]);

    });
