/**
 * @description
 * This is generic code to detect device, whether it is mobile or desktop.
 * @author Karthik Devaraj
 */
define('component/device/device-detector', ['angular'], function (angular) {
    'use strict';
   // module creation
    angular
        .module('deviceDetection', [])
        /**
         * @name deviceDetection:deviceDetector
         * ngdoc service
         * @module deviceDetection
         * @description
         * deviceDetector is used to detect mobile or desktop.
         */
        .service('deviceDetector', deviceDetector);

    function deviceDetector($window){
        var self = this;
        //It will return true for mobile and false for desktop.
        var isDevice = (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i)
            .test($window.navigator.userAgent || $window.navigator.vendor || $window.opera);
        self.userAgent = $window.navigator.userAgent.toLowerCase();

        /**
         * @ngdoc method
         * @name isMobileDevice
         * @methodOf deviceDetection:deviceDetector
         * @description
         * isMobileDevice function is used to check whether it is mobile device.
         */
        self.isMobileDevice = function () {
            return isDevice;
        };
        /**
         * @ngdoc method
         * @name isMobile
         * @methodOf deviceDetection:deviceDetector
         * @description
         * This method is used to invoke the memorized value.
         */
        self.isMobile = function () {
            return self.isMobileDevice();
        };
        /**
         * @ngdoc method
         * @name getAndroidVersion
         * @methodOf deviceDetection:deviceDetector
         * @description
         * This method is used to fetch android version.
         */
        self.getAndroidVersion = function() {
            var match = self.userAgent.match(/android\s([0-9\.]*)/);
            return match ? match[1] : false;
        };

        /**
         * @ngdoc method
         * @name checkAndroidNativeBrowser
         * @methodOf deviceDetection:deviceDetector
         * @description
         * This method is used to check android native browser.
         */
        self.checkAndroidNativeBrowser = function() {
            var checkAndroid = (self.userAgent.indexOf('mozilla/5.0') > -1 && self.userAgent.indexOf('android ') > -1 && self.userAgent.indexOf('applewebkit') > -1),
                indexChrome = self.userAgent.indexOf('/',self.userAgent.indexOf('chrome')) + 1,
                chromeVersion = self.userAgent.substring(indexChrome, indexChrome+2),
                checkNativeBrowser = (!(self.userAgent.indexOf('chrome') > -1) || chromeVersion <= 28 );
                //Check the chrome version for some samsung devices native browser user agent retuen chrome

            return checkAndroid && checkNativeBrowser;
        };

        /**
         * @ngdoc method
         * @name isChrome
         * @methodOf deviceDetection:deviceDetector
         * @description
         * Returns true if browser is Chrome.
         */
        self.isChrome = function() {
            return self.userAgent.indexOf('chrome') > -1;
        };
    };
});
