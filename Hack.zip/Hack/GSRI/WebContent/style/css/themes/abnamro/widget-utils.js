define('foundation/widget/widget-utils', ['angular', 'foundation/widget/widget-bundle'], function(angular) {
    'use strict';
    angular.module('widget.widgetUtilities', ['ui.router'])
        /**
         * @name widgetUtils
         * @module widget.widgetUtilities
         * @description
         * widgetUtils is service that checks widget's metadata.
         *
         * @returns {Function} checkMetaData Function that checks widget's metadata
         * @returns {Function} throwError Function that throw error to console if metadata not defined
         */
        .provider('widgetUtils', function() {
            var self = this;
            this.targetString = /\/app\/widgets\/.*$/;
            this.hasBackState = function(toState) {
                var view;
                if (toState.views) {
                    for (var viewName in toState.views) {
                        view = toState.views[viewName];
                        break;
                    }
                }
                if (toState.views && view && view.back && view.back.length > 0) {
                    return true;
                } else if (toState.data && toState.data.states && toState.data.states.back && toState.data.states.back.length > 0) {
                    return true;
                } else {
                    return false;
                }
            };

            function getFolder(path) {
                var regex = /[^\/]*$/;
                return path.replace(regex, '');
            }
            this.getTranslationsFolder = function(widgetModel) {
                var path = widgetModel.attributes['src'].nodeValue;
                var folder = getFolder(path);
                return folder + 'translations/';
            };
            this.getAnalyticsConfigPath = function(widgetModel) {
                var path = widgetModel.attributes['src'].nodeValue;
                var folder = getFolder(path);
                return folder + 'analytics/analytics.json';
            };

            function getBaseWidgetBasePath(widgetModel) {
                var replacementString = '/app/';
                var path = widgetModel.attributes['src'].nodeValue;
                return path.replace(self.targetString, replacementString);
            }
            this.resolvePath = function(widgetModel, pathToTarget) {
                if (widgetModel && pathToTarget) {
                    var re = /^\//;
                    //matches /
                    if (pathToTarget.match(re)) {
                        return pathToTarget;
                    } else {
                        return getBaseWidgetBasePath(widgetModel) + pathToTarget;
                    }
                } else {
                    return undefined;
                }
            };
            /**
             * @name checkMetaData
             * @description
             * It checks that states, name and localPath are defined in metaData and that they are valid.
             *
             * @param {Object} metaData Widget metadata that contain information regarding states,
             * widgetModule name and localPath
             * @returns {Boolean} isValid Flag means that states, name and localPath are defined
             * @returns {Undefined} handleStateChange
             */
            this.checkMetaData = function(metaData) {
                /**
                 * @description
                 * checks that metaData states are defined
                 *
                 * @returns {Boolean} isValid Flag means that states are not defined
                 * @returns {String} message Error message
                 */
                if (!metaData.states) {
                    return {
                        isValid: false,
                        message: 'metatData.states are not defined'
                    };
                }
                /**
                 * @description
                 * checks that metaData localPath are defined, localPath length should be more than 0
                 *
                 * @returns {Boolean} isValid Flag means that localPath is not defined
                 * @returns {String} message Error message
                 */
                if (!metaData.localPath || !metaData.localPath.length > 0) {
                    return {
                        isValid: false,
                        message: 'metatData.localPath is not defined'
                    };
                }
                /**
                 * @description
                 * checks that metaData name are defined, name length should be more than 0
                 *
                 * @returns {Boolean} isValid Flag means that name is not defined
                 * @returns {String} message Error message
                 */
                if (!metaData.name || !metaData.name.length > 0) {
                    return {
                        isValid: false,
                        message: 'metatData.name is not defined'
                    };
                }
                return {
                    isValid: true,
                    message: ''
                };
            };
            /**
             * @name throwError
             * @description
             * Function that throw error to console if metadata not defined
             *
             * @returns {Object} new Error Console log message if states, localPath or name are not defined
             */
            this.throwError = function() {
                throw new Error(Array.prototype.slice.call(arguments));
            };
            this.basePath = undefined;
            /**
            retrieves the baseurl that requirejs uses
            **/
            this.fullPath = function(path) {
                if (!this.basePath) {
                    this.basePath = require.toUrl('') || '';
                }
                return this.basePath + path;
            };
            /**
             * @name getWidgetModuleNameFromPath
             * @param {string=} path this is a path
             * @description
             * Function returns new path by merging pats of path in one.
             * It replaces all characters and makes each path upper case
             *
             * @returns {String} path
             */
            this.getWidgetModuleNameFromPath = function(path) {
                return path.replace(/(\/)(.)/g, function($1, $2, $3) {
                    return $3.toUpperCase();
                }).replace(/\./g, '');
            };
            this.getStateDescriptionByPath = function(states, path) {
                if (!states || states.length === 0 || !path) {
                    return undefined;
                }
                for (var i = 0; i < states.length; i++) {
                    var state = states[i];
                    var url = state.templateUrl || '';
                    if (url.indexOf(path, url.length - path.length) !== -1) {
                        return state.name;
                    }
                }
                return undefined;
            };
            /**
             * @name getUrlParameters
             * @param {string=} this is parameters received from the url.
             * @description
             * Function converts the parameter received from the url to a javascript object and returns.
             * @returns {String} path
             */
            this.getUrlParameters = function(urlParameters) {
                var queryString = {};
                var vars = urlParameters.split('&amp;');
                for (var i = 0; i < vars.length; i++) {
                    var pair = vars[i].split('=');
                    // If first entry with this name
                    if (typeof queryString[pair[0]] === 'undefined') {
                        queryString[pair[0]] = decodeURIComponent(pair[1]);
                        // If second entry with this name
                    } else if (typeof queryString[pair[0]] === 'string') {
                        var arr = [queryString[pair[0]], decodeURIComponent(pair[1])];
                        queryString[pair[0]] = arr;
                        // If third or later entry with this name
                    } else {
                        queryString[pair[0]].push(decodeURIComponent(pair[1]));
                    }
                }
                return queryString;
            };
            /**
             * @name getNestedObject
             * @param {Object} this is the deepLinked object
             * @param {string=} this is the key which will be searched in object
             * @param {string=} this is the value of the key received from the url
             * @description
             * Function searches for the parameter passed from the url inside the object array of the
             * deepLinked object it checks for the key passed and changes the value if the key is present in the
             * object and throws an error if the key value is required and it is not passed from the url.
             *
             * @returns {String} path
             */
            this.getNestedObject = function(obj, paramsFromUrl) {
                var i, proto = Object.prototype,
                    ts = proto.toString;
                for (i in obj) {
                    for (var urlParams in paramsFromUrl) {
                        if (proto.hasOwnProperty.call(obj, i)) {
                            if (i === urlParams) {
                                obj[i] = paramsFromUrl[urlParams];
                                break;
                            } else if ('[object Array]' === ts.call(obj[i]) || '[object Object]' === ts.call(obj[i])) {
                                this.getNestedObject(obj[i], paramsFromUrl);
                            }
                        }
                    }
                    // If the required deeplink parameter is not found in URL then throw an error.
                    if (obj[i] === true) {
                        obj[i] = undefined;
                        throw new Error('the required deeplink parameter could not be found');
                    }
                    // If the optional deeplink parameter is not found in URL then assign undefined value.
                    else if (obj[i] === false) {
                        obj[i] = undefined;
                    }
                }
                return obj;
            };

            this.$get = function() {
                return {
                    getTranslationsFolder: self.getTranslationsFolder,
                    getAnalyticsConfigPath: self.getAnalyticsConfigPath,
                    resolvePath: self.resolvePath,
                    fullPath: self.fullPath,
                    getStateDescriptionByPath: self.getStateDescriptionByPath,
                    checkMetaData: self.checkMetaData,
                    throwError: self.throwError,
                    getWidgetModuleNameFromPath: self.getWidgetModuleNameFromPath,
                    hasBackState: self.hasBackState,
                    getNestedObject: self.getNestedObject,
                    getUrlParameters: self.getUrlParameters
                };
            };
        });
});