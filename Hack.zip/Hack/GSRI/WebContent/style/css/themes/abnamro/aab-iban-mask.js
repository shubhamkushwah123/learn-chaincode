/**
 * @description
 * Displays iban mask field.
 */
define('component/ui/mask/aab-iban-mask/aab-iban-mask', ['angular', 'component/ui/numeric-input/numeric-input', 'component/device/device-detector'],
    function(angular) {
        'use strict';

        function iBanMaskController($scope) {
            var vm = this;
        }

        function aabIbanMask($timeout, $parse, deviceDetector) {
            var iBanMaskDirective = {
                replace: true,
                require: '^ngModel',
                restrict: 'E',
                scope: {
                    disabled: '=',
                    maskPrefix: '='
                },
                templateUrl: 'oca/app/components/ui/mask/aab-iban-mask/aab-iban-mask.html',
                controller: iBanMaskController,
                controllerAs: 'vm',
                link: function(scope, element, attrs, ngModel) {
                    var inputElem = element[0]; //.querySelectorAll('input');
                    var ibanFieldPrefix, ibanFieldPostfix, postfixMaskLength, prefixMaskLength,
                        key, limit, inputField, isNotDigitInput, target, exceptKeys, digitAndCtrlValidity,
                        ibanPrefixCountryCode = 'NL',
                        ibanString = '',
                        ibanPrefixBankCode = 'ABNA',
                        mask = '',
                        prefixMask = '',
                        prefixLimit = '',
                        postfixMask = '',
                        postfixLimit = '',
                        isElementTextSelected = false;

                    ibanFieldPrefix = inputElem.querySelectorAll('input')[0];
                    ibanFieldPostfix = inputElem.querySelectorAll('input')[1];
                    //Check elment have mask attribute and android version less than 4.4 with android browser
                    prefixMask = ibanFieldPrefix.getAttribute('data-mask');
                    prefixLimit = prefixMask.length;
                    postfixMask = ibanFieldPostfix.getAttribute('data-mask');
                    postfixLimit = postfixMask.length;
                    //Set the mask based on device detection.
                    //For older android browser disable mask ie., without space
                    if (parseFloat(deviceDetector.getAndroidVersion()) <= 4.4 && deviceDetector.checkAndroidNativeBrowser()) {
                        prefixLimit = (prefixMask.replace(/ /g, '')).length;
                        prefixMask = '';
                        postfixLimit = (postfixMask.replace(/ /g, '')).length;
                        postfixMask = '';
                    }

                    // check if the input element should be auto focused and focus it.
                    if (attrs.hasOwnProperty('autoFocus')) {
                        $timeout(function() {
                            ibanFieldPrefix.focus();
                        }, 0, false);
                    }
                    // Listening to key press events
                    angular.element(inputElem).bind('keypress keyup', listenToKeyUpEvent);
                    angular.element(inputElem).bind('keydown', listenToKeyDownEvent);
                    angular.element(inputElem).bind('paste', function(event) {
                        event.preventDefault();
                        return false;
                    });


                    function updateViewValue() {
                        ibanString = ibanPrefixCountryCode + ibanFieldPrefix.value + ibanPrefixBankCode;
                        ibanString += (ibanFieldPostfix.value).replace(/ /g, '');
                        ngModel.$setViewValue(ibanString);
                    }

                    // Listening for Blur/Focus event to update directive scope value
                    scope.postfixBlurEvent = function(event) {
                        var target = event.target;
                        prefixMaskLength = ibanFieldPrefix.getAttribute('data-mask').length;
                        ibanFieldPrefix = inputElem.querySelectorAll('input')[0];
                        if ((target.value + '').length < target.getAttribute('data-mask').length || (ibanFieldPrefix.value + '').length < prefixMaskLength) {
                            ngModel.$setValidity('invalidIban', false);
                            ngModel.$setViewValue(undefined);
                        } else {
                            ngModel.$setValidity('invalidIban', true);
                        }
                    }

                    scope.prefixBlurEvent = function(event) {
                        var target = event.target;
                        postfixMaskLength = ibanFieldPostfix.getAttribute('data-mask').length;
                        ibanFieldPostfix = inputElem.querySelectorAll('input')[1];
                        if ((target.value + '').length < target.getAttribute('data-mask').length || (ibanFieldPostfix.value + '').length < postfixMaskLength) {
                            ngModel.$setValidity('invalidIban', false);
                            ngModel.$setViewValue(undefined);
                        } else {
                            ngModel.$setValidity('invalidIban', true);
                        }
                    }


                    function updateMask(inputField, mask, key) {
                        var i, indices = [];
                        for (i = 1; i <= mask.length; i++) {
                            if (mask[i] === ' ') {
                                indices.push(i);
                            }
                        }
                        if (indices.indexOf(inputField.value.length) > -1 && key !== 8) {
                            inputField.value = inputField.value + ' ';
                        }
                    }

                    function setFocusInput(event) {
                        target = event.target;
                        inputField = '';
                        limit = '';
                        mask = '';
                        ibanFieldPrefix = inputElem.querySelectorAll('input')[0];
                        ibanFieldPostfix = inputElem.querySelectorAll('input')[1];

                        key = event.keyCode ? event.keyCode : event.which;
                        isNotDigitInput = event.which < 48 || event.which > 57;
                        exceptKeys = key !== 8 && key !== 13 && key !== 9;
                        digitAndCtrlValidity = !event.ctrlKey && !isNotDigitInput;

                        if (target.getAttribute('data-ng-model') === 'ibanprefix') {
                            inputField = ibanFieldPrefix;
                            if ((inputField.value + '').length === 2 && exceptKeys && digitAndCtrlValidity) {
                                if (!parseFloat(deviceDetector.getAndroidVersion()) <= 4.4 && !deviceDetector.checkAndroidNativeBrowser()) {
                                    ibanFieldPostfix.focus();
                                }
                            }
                            limit = prefixLimit;
                            mask = prefixMask;
                        } else if (target.getAttribute('data-ng-model') === 'ibanpostfix') {
                            inputField = ibanFieldPostfix;
                            if (key === 8) {
                                if (inputField.value + '' === '') {
                                    if (!parseFloat(deviceDetector.getAndroidVersion()) <= 4.4 && !deviceDetector.checkAndroidNativeBrowser()) {
                                        ibanFieldPrefix.focus();
                                        if (document.selection) {
                                            var temp = ibanFieldPrefix.value;
                                            ibanFieldPrefix.value = '';
                                            ibanFieldPrefix.value = temp;
                                        }
                                    }
                                }
                            } else {
                                $timeout(function() {
                                    ibanFieldPostfix.selectionStart = ibanFieldPostfix.selectionEnd = ibanFieldPostfix.value.length;
                                }, 10);
                            }
                            limit = postfixLimit;
                            mask = postfixMask;
                        }
                    }


                    function listenToKeyDownEvent(event) {
                        setFocusInput(event);
                    }


                    /**
                     * @ngdoc method
                     * @name listenToKeyDownEvent
                     * @methodOf ui.aabiBanMask:aabIbanMask
                     * @description
                     * Bind method for keydown event on input
                     * Reads keyCode from event and if pressed is numeric and new value length is in given limit then updates the model
                     * @param {Object} event Event object of keydown event
                     */
                    function listenToKeyUpEvent(event) {
                        setFocusInput(event);
                        exceptKeys = key !== 8 && key !== 13 && key !== 9;
                        digitAndCtrlValidity = !event.ctrlKey && ((isNotDigitInput || (inputField.value + '').length >= limit));

                        if (exceptKeys && digitAndCtrlValidity) {
                            event.preventDefault();
                            return false;
                        } else {
                            updateMask(inputField, mask, key);
                            updateViewValue();
                        }
                    }
                }
            };
            return iBanMaskDirective;
        }

        angular.module('ui.aabiBanMask', ['deviceDetection'])

        /**
         * @ngdoc directive
         * @module ui.aabiBanMask
         * @name ui.aabiBanMask.aabIbanMask:aabIbanMask
         * @description
         * Creates an abn iban mask field.
         * @restrict EA
         * @scope
         **/
        .directive('aabIbanMask', aabIbanMask)
            .controller('iBanMaskController', iBanMaskController);
    });
