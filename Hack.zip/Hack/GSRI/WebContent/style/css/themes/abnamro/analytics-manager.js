define('foundation/widget/analytics-manager',
    ['angular',
    'angulartics',
    'foundation/widget/widget-context'
    ],
    function (angular) {
        'use strict';
        var moduleName = 'widget.analyticsManager';

        angular
            .module(moduleName, ['angulartics', 'widget.widgetContext'])
            .config(function ($analyticsProvider) {
                // turn off automatic tracking
                $analyticsProvider.virtualPageviews(false);
            })
            .provider('widgetAnalytics', widgetAnalyticsProvider);


        function widgetAnalyticsProvider() {
            var statisticsProperties = {};

            /* jshint validthis: true */
            this.initAnalytics = function(jsonObject){
                console.warn('analytics-manager is deprecated and will be removed from the OCA with the release of Standards and Guidelines version 1.3');
                statisticsProperties = jsonObject;
            };

            this.$get = sitecatalystService;

            sitecatalystService.$inject = [
                '$window',
                '$rootScope',
                '$analytics',
                'widgetContext'
            ];

            //$analyticsProvider
            function sitecatalystService($window, $rootScope, $analytics, widgetContext) {

                function init() {
                    // if basics aren't added to configuration, no statistic signals should be send
                    if (statisticsProperties.hasOwnProperty('basics')) {
                        var basics = statisticsProperties.basics;
                        setProperties(basics);
                        $rootScope.$on('$stateChangeSuccess', stateSuccess);
                    }
                }

                function stateSuccess(event, toState) {
                    // get name new state
                    if (angular.isUndefined(toState)) {
                        return;
                    }
                    var statename = toState.name;

                    //add analytics properties from widgetcontext.stateconfig to statisticsProperties
                    var stateProperties = {};
                    var eventProperties = [];
                    for(var i=0; i<widgetContext.stateConfig.length; i++){
                        //get pageTrack properties
                        stateProperties[widgetContext.stateConfig[i].name] = widgetContext.stateConfig[i].pageTrack;
                        //get eventTrack properties
                        eventProperties[widgetContext.stateConfig[i].name] = widgetContext.stateConfig[i].eventTrack;
                    }
                    angular.extend(statisticsProperties, stateProperties);

                    // search for corresponding properties in _statSettings
                    if (statisticsProperties.hasOwnProperty(statename) === false){
                        return;
                    }
                    var props = angular.copy(statisticsProperties[statename], {});
                    setProperties(props);
                    trackPage();

                    var events = angular.copy(eventProperties[statename], []);
                    angular.forEach(events, function(value) {
                        $analytics.eventTrack(value);
                    });
                }

                function setProperty(key, value) {
                    key = '' + key; // be sure the key is a string (in case a number is posted)
                    if (angular.isDefined($window.s)) {
                        $window.s[key] = value;
                    }
                }

                function setProperties(pairs) {
                    angular.forEach(pairs, function(value, key) {
                        setProperty(key, value);
                    });
                }

                // todo is this implemented correctly?
                function trackPage() {
                    if (angular.isDefined($window.s)) {
                        $window.s.t();
                    } else{
                        console.error('s_code.js missing');
                    }
                }

                return {
                    start: init
                };
            }
        }


        angular
            .module(moduleName).$inject = ['widgetAnalytics'];

        angular
            .module(moduleName).run(startModule);

        function startModule(widgetAnalytics) {
            // just start the provider here
            widgetAnalytics.start();
        }

        return [moduleName];

    });
