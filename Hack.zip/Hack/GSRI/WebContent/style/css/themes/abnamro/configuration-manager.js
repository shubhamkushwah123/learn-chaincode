define('foundation/widget/configuration-manager', ['angular'],

function(angular) {
    'use strict';

    /**
     * @ngDoc service
     * @name widget.configurationManager.configurationManager:configurationManager
     * @descript_optision
     * Provider to read json files with a fallback mechanism
     */
    function configurationManager() {

        'use strict';


        function ConfigManager($q, $http) {
            this.options = {};

            /**
             * Load json files and return an overall promise. Merges all json objects into one.
             * If a defaultLocation is used, that file is loaded first.
             * Root keys in json object will be overwritten by succeeding files
             *
             * @param  {[options]}
             *   {
             *      files: [] list of files to load
             *      defaultLocation: '' file to load as a fallback mechanism
             *   }
             * @return {[promise]}
             */
            this.initConfigurations = function(options) {

                //set some default in case the options we receive are empty or nonsense
                var defaults = {
                    files: [],
                    defaultLocation: ''
                };

                //merge the options with the defaults
                var _opts = angular.extend({}, defaults, options);

                /**
                 * Add the default config file to the beginning of the array. That way they are processed first.
                 * Any consecutive configuration files will override the default ones
                 */
                if (_opts.defaultLocation.length > 0) {
                    _opts.files.unshift(_opts.defaultLocation);
                }

                this.options = {
                    files: _opts.files
                };

                /**
                 * Check if the options object is set with a files array
                 */
                if (!angular.isArray(this.options.files) || this.options.files.length === 0) {
                    throw new Error('Couldn\'t load static files, no files array specified!');
                }

                return this.loadConfigurationFiles();
            };

            /**
             * Get a requested json bundle through http GET call
             *
             * @param filename
             * @returns {[promise]}
             */
            this.getConfigurationFile = function(filename) {

                /**
                 * Make sure that the file location is set
                 */
                if (!filename || !angular.isString(filename)) {
                    throw new Error('Couldn\'t load static file!');
                }

                var deferred = $q.defer();

                /**
                 * Perform the get call. When something goes wrong, reject the deferred
                 */
                $http.get(filename).success(function(data) {
                    // The bundle has been retrieved successful, resolve the promise and return the data
                    deferred.resolve(data);

                }).error(function() {
                    deferred.resolve({});
                });

                return deferred.promise;
            };

            this.loadConfigurationFiles = function() {
                var deferred = $q.defer(),
                    promises = [];

                // Iterate over all the files given and retrieve them by performing a http GET
                for (var i = 0; i < this.options.files.length; i++) {

                    // Store all the returned promises in order to continue when all the files are retrieved
                    promises.push(this.getConfigurationFile(this.options.files[i]));
                }

                /**
                 * When all the files are requested, and a response has been received, check whether all the calls
                 * succeeded or not.
                 */
                $q.all(promises).then(function(data) {
                    var mergedData = {};

                    for (var i = 0; i < data.length; i++) {
                        for (var key in data[i]) {
                            mergedData[key] = data[i][key];
                        }
                    }
                    deferred.resolve(mergedData);
                }, function(data) {
                    deferred.reject(data);
                });

                return deferred.promise;
            };
        };

        /**
         * @name $get method
         * @description
         *
         * @returns
         */
        this.$get = function($q, $http) {
            return new ConfigManager($q, $http);
        };
    }


    angular.module('widget.configurationManager', [])
        .provider('configurationManager', configurationManager);
});
