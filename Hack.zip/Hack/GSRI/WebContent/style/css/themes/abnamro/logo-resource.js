define('component/data-access/logos/logo-resource', ["angular"], function(angular) {

    angular
        .module('service.logoResource', [])
        .service('logoResource', ["$http", "$q", function($http, $q) {
            var promise;
            var urlService;


            function getLogoList() {
                var deferred = $q.defer();

                urlService = "/logos/user";

                promise = $http.get(urlService)
                    .success(function(data) {
                        deferred.resolve(data);
                    })
                    .error(function(data) {
                        deferred.resolve(data);
                    });

                return deferred.promise;
            }

            function getLogo(type, id) {
                var deferred = $q.defer();

                urlService = "/logos/user/" + type + "/" + id;

                var req = {
                    method: 'GET',
                    url: urlService
                };

                promise = $http(req)
                    .success(function(data) {
                        deferred.resolve(data);
                    })
                    .error(function(data) {
                        deferred.resolve(data);
                    });

                return deferred.promise;
            }

            return {
                "getLogoList": getLogoList,
                "getLogo": getLogo
            };

        }]);
});
