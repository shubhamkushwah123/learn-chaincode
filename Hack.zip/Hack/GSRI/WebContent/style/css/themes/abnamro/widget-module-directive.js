define('foundation/widget/widget-module-directive', ['angular'], function (angular) {
    'use strict';
    angular.module('widget.widgetModule',
        ['ui.router', 'widget.bundle'], function ($rootScopeProvider) {
            $rootScopeProvider.digestTtl(20);
        })
        .controller('widgetModuleController', widgetModuleController)
        .directive('aabWidgetModule', widgetDirective)
        .service('widgetModuleService', widgetModuleService);

    function widgetDirective() {
        return {
            restrict: 'E',
            controller: 'widgetModuleController'
        };
    }

    function widgetModuleController($rootScope, $scope, $state, widget, statesService, widgetUtils, widgetModuleContext, widgetModuleService, eventService, widgetContext) {
      

        var parentState = widgetUtils.getStateDescriptionByPath($state.get(), widgetModuleContext.metaData.localPath);

        /** check the validity of the metaData object of the widgetModule */
        var metaDataCheck = widgetUtils.checkMetaData(widgetModuleContext.metaData);

        //Changes made for deepLinking
        //Check if # is incluwidget,widgetModuleContextded in deeplink url
        if (widget.hasDeepLink && typeof widget.urlParsed === 'undefined') {
            var isDeepLinked = widgetModuleService.getDeepLinkParams(widgetModuleContext, $scope, $state);
            if (isDeepLinked === false) {
                $scope.$emit('aab-widget-handle-error', 'errorCodeTechnicalErrorTitle', 'errorCodeTechnicalError');
            }
        }

        if (!metaDataCheck.isValid) {
            widgetUtils.throwError(metaDataCheck.message, metaDataCheck);
            return;
        }

        //since the widgetModuleContext is a singleton with a lifetime equal to that of
        //the app we need to clear is manually
        $scope.$on('$destroy', function () {
            widgetModuleContext.clear();
        });

        //make the backase portal client available in scope so it is available for widgetModules
        widgetModuleContext.widget = widget;
        /** make the stateObject available in scope **/
        $scope.stateObject = angular.extend({}, $state.params['stateObj'], $scope.stateObject);

        var showBack = widgetUtils.hasBackState($state.current);

        //get the path to the widget module
        var widgetModulePath = widgetUtils.resolvePath(widget.model, widgetModuleContext.metaData.localPath);

        // retrieve the stateDescription that is configured for this widget module
        var stateDescription = statesService.getStateDescriptionByPath(widgetModulePath);

        widgetModuleService.processStateConfig(widgetModuleContext, parentState, stateDescription);

        widgetModuleService.setWidgetHeader(widgetModuleContext, showBack);

        /**
         * @description
         * This widget module expects to be assigned a certain number of stateValues.
         * Show an error if the expected number of state values does not match the actual assigned
         * number of state values
         */

        var stateValidity = statesService.stateIsValid(stateDescription, widgetModuleContext.metaData);

        if (!stateValidity.isValid) {
            widgetUtils.throwError(stateValidity.message, widgetModuleContext.metaData.name, ' state metaData:',
                widgetModuleContext.metaData, 'state definition', stateDescription);
        } else {

            $scope.goToSubModuleState = function (name) {
                statesService.transferToSubState(name, $scope.stateObject);
            };
            
            $scope.transferTo = function(name) {
                statesService.goToExitPath(name, $scope.stateObject);
            };
        }


        if (typeof (widgetModuleContext.onWidgetModuleLoaded) === 'function') {
            widgetModuleContext.onWidgetModuleLoaded();
        }
    }

    /**
     * @name widgetModuleService
     * @description prepare the state object with the deep linking parameters
     */

    function widgetModuleService(statesService, widgetUtils, widget) {
        return {


            processStateConfig: function (widgetModuleContext, parentState, stateDescription) {
                /** if there is any stateConfig add it to UI-router config */

                if (angular.isArray(widgetModuleContext.stateConfig) && parentState) {
                    for (var i = 0, len = widgetModuleContext.stateConfig.length; i < len; i++) {
                        var state = widgetModuleContext.stateConfig[i];
                        if (!statesService.stateExists(parentState + '.' + state.name)) {
                            var views = {};
                            for (var viewname in state.views) {
                                if (viewname && viewname !== '') {

                                    //only add the backkstate if it is actually defined
                                    if(state.views[viewname].back) {
                                         views[viewname] = {
                                            templateUrl: widgetUtils.resolvePath(widget.model, state.views[viewname].templateUrl),
                                            controller: state.views[viewname].controller,
                                            data: stateDescription,
                                            back: state.views[viewname].back
                                        };
                                    } else {
                                         views[viewname] = {
                                            templateUrl: widgetUtils.resolvePath(widget.model, state.views[viewname].templateUrl),
                                            controller: state.views[viewname].controller,
                                            data: stateDescription
                                        };
                                    }
                                }
                            }
                            
                            //the name of the state can be defined with a . prefix. This is to indicate that it is a substate. So we need need to remove the dot
                            if(state.name.indexOf('.') === 0)
                            {
                                  state.name = state.name.substr(1, state.name.length-1);
                            }

                            statesService.addState(parentState +'.'+ state.name, {
                                views: views,
                                parentModule: parentState
                            });

                        }
                    }
                }
            },


            setWidgetHeader: function (widgetModuleContext, showBack) {
                if(widgetModuleContext.metaData.headerSettings){
                    //if alternative header settings are defined then apply them to the header
                    if (widgetModuleContext.metaData.headerSettings.leftButton) {
                        //if an exitpath or exitfunction have been defined then we assume the leftbutton does not have its default back button behavior
                        if(widgetModuleContext.metaData.headerSettings.leftButton.exitPath || widgetModuleContext.metaData.headerSettings.leftButton.exitFunction) {
                            //do nothing
                        } else {
                            angular.extend(widgetModuleContext.metaData.headerSettings.leftButton, { show: showBack});
                        }
                    } else {
                        widgetModuleContext.metaData.headerSettings.leftButton = {show: showBack} ;
                    }
                    widgetModuleContext.changeHeaderSettings(widgetModuleContext.metaData.headerSettings);
                }
                 else {
                    //if there are header settings defined then set the backbutton
                    widgetModuleContext.changeHeaderSettings({leftButton: {show: showBack}});
                }
            },


            getDeepLinkParams: function (widgetModuleContext, $scope, $state) {
                var paramsFromUrl = $state.params['stateObj'].deepLinkURLParams;
                var paramsFromWidgetModule = angular.fromJson(widgetModuleContext.deepLinkParams);
                if (paramsFromWidgetModule) {
                    try {
                        paramsFromWidgetModule = widgetUtils.getNestedObject(paramsFromWidgetModule, paramsFromUrl);
                        $scope.stateObject = paramsFromWidgetModule;
                        widget.urlParsed = true;
                        return true;
                    } catch (e) {
                        widget.urlParsed = false;
                        return false;
                    }
                }
                return false;
            }
        };
    }
});
