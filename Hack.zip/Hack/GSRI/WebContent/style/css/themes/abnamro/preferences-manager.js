define('foundation/widget/preferences-manager', ['angular'], function (angular) {
    'use strict';
    angular
        .module('preferences.manager', [])

        /**
         * @name widgetPreferences
         * @module preferences.manager
         * @description
         * widgetPreferences is service that allows to get access to Backbase widget properties.
         * The widgetPreferences service wraps the Backbase widget object, so it can be accessed
         * later in getProperty function.
         *
         * @param {Object} widget The widget object
         * @returns {Object} getProperty Property object
         */
        .service('widgetPreferences', function(widget) {

            /** assigning widget's object to variable */
            var widgetObject = widget;

            var priv = {

                getPagePreference: function(propertyTitle){
                    var pageObject = priv.getParentPageObject(widgetObject);
                    if(pageObject && pageObject.attributes && pageObject.attributes[propertyTitle]){
                        return pageObject.attributes[propertyTitle].nodeValue;
                    } else {
                        return undefined;
                    }
                },

                getWidgetPreference: function(propertyTitle){
                    return widgetObject.getPreference(propertyTitle);
                },

                getParentPageObject: function(object){
                    if(object.parentNode && object.parentNode.nodeName === 'page'){
                        return object.parentNode;
                    } else {
                        return priv.getParentPageObject(object.parentNode);
                    }
                }
            };

            /**
             * @name getProperty
             * @description
             * Receive property title and if this property exists than check and return its value.
             * If property doesn't exist - send a warning to console and set widgetProperty as an empty string
             *
             * @param {String}  propertyTitle Requested property title
             * @returns {String} property title
             */

            function getProperty(propertyTitle, cascade){

                var propertyValue = priv.getWidgetPreference(propertyTitle);

                if (cascade) {
                    propertyValue = priv.getPagePreference(propertyTitle);
                }

                switch(propertyValue){
                    case undefined: return '';
                    case 'false': return false;
                    case 'true': return true;
                    default: return propertyValue;
                }
            }

            return {
                getProperty: getProperty,
                _private_: priv
            };
        });
});
