define('component/ui/modal/modal-instance-loader-controller', ['angular'], function(angular) {

    angular
        .module('service.modalInstanceLoader', ['ui.bootstrap'])
        .controller('modalInstanceLoaderController', modalInstanceLoaderController);

    // Controller responsible for the logic inside the modal template - content can be passed for example in the form of a JSON file from Tridion/ Backbase
    function modalInstanceLoaderController($scope, $modalInstance, content) {

        $scope.title = content.title;
        $scope.text = content.text;

        // for demo purposes:
        // setTimeout(function(){
        //     $modalInstance.close();
        // }, 15000);
    }
});
