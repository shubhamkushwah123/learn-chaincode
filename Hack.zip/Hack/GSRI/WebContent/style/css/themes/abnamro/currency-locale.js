define('component/filters/currency-locale', ['angular'], function(angular) {
    'use strict';
    angular.module('filter.currencyLocale', [])
        /**
         * @ngdoc filter
         * @name filter.currencyLocal
         * @param {scope/context variable} ng-model Input value and locale argument
         * @param {input=} input value/ng-model value passed as argument
         * @param {locale}  which format you prefer
         * @description
         * Creates filter which accpets input value,and locale as arguments and return back with the requested format
         */
        .filter('currencyLocale', function() {
            return function(input, type) {
                if(angular.isNumber(input)) input = input.toString();
                if (input && type === "locale") {
                    var inputLength = input.split(",").length;
                    if (inputLength) {
                        var temp = parseFloat(input.replace(/,([^,]*)$/, ".$1")).toFixed(2); //  replace and recovert it again
                        return (temp !== "NaN") ? temp.replace(/.([^.]*)$/, ",$1") : '0,00'; // return back with locale format
                    } else {
                        return input;
                    }
                } else if (input && type === "decimals") {
                    var tmpValue = input.replace(/,([^,]*)$/, ".$1");
                    tmpValue = parseFloat(tmpValue).toFixed(2);
                    return tmpValue;
                }

            }
        });
    return ['filter.currencyLocale'];
});
