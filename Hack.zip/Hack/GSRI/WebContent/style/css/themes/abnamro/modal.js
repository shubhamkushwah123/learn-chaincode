/**
 * @description
 * This is a modal service - two types are currently added although one can easily add more different types
 *
 * @author Rogier Konings
 */
define('component/ui/modal/modal', [
    'angular',
    'component/ui/modal/modal-instance-info-controller',
    'component/ui/modal/modal-instance-confirm-controller',
    'component/ui/modal/modal-instance-loader-controller'
    ], function(angular) {


angular
    .module('service.modal', ['service.modalInstanceInfo', 'service.modalInstanceConfirm', 'service.modalInstanceLoader'])
    .factory('modal', modalFactory);

    function modalFactory($modal) {

        // Different types of Modals can be added to this array, combined with a controller and a template
        var modaltypes = {
            'INFO': {
                templateUrl: "oca/app/components/ui/modal/modal-info.html",
                controller: "modalInstanceInfoController"
            },
            'CONFIRM': {
                templateUrl: "oca/app/components/ui/modal/modal-confirm.html",
                controller: "modalInstanceConfirmController"
            },
            'LOADER': {
                templateUrl: "oca/app/components/ui/modal/modal-loader.html",
                controller: "modalInstanceLoaderController"
            }

        };

        // Creates a modal instance by using the standard Angular-ui modal directive, with the template and controller indicated aboven
        function openModal(modaltype, content) {

            return $modal.open({
                templateUrl: modaltypes[modaltype].templateUrl,
                controller: modaltypes[modaltype].controller,
                backdrop: 'static',
                keyboard: (modaltype == 'LOADER') ? false : true,
                resolve: {
                    content: function() {
                        return content;
                    }
                }
            });
        }

        return {
            'openModal': openModal
        };

    }

});


